"""Visual bond inference for generated crystal structures."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import math

from .cif_parser import CartesianAtom
from .elements import COVALENT_RADII, DEFAULT_COVALENT_RADIUS


@dataclass(frozen=True)
class Bond:
    i: int
    j: int
    distance: float


def infer_bonds(atoms: Sequence[CartesianAtom], tolerance: float = 1.15,
                min_distance: float = 0.35,
                pair_overrides: Optional[Dict[Tuple[str, str], Tuple[float, float]]] = None,
                max_distance: Optional[float] = None) -> List[Bond]:
    """Infer visual bonds from covalent radii.

    pair_overrides maps sorted element pairs to explicit (min,max) distances in Å.
    This is intentionally a visualization heuristic, not a chemical bond-order model.
    """
    pair_overrides = pair_overrides or {}
    out: List[Bond] = []
    n = len(atoms)
    for i in range(n):
        ai = atoms[i]
        pi = ai.position
        for j in range(i + 1, n):
            aj = atoms[j]
            pj = aj.position
            dx, dy, dz = pi[0]-pj[0], pi[1]-pj[1], pi[2]-pj[2]
            d2 = dx*dx + dy*dy + dz*dz
            if d2 < min_distance * min_distance:
                continue
            pair = tuple(sorted((ai.element, aj.element)))
            if pair in pair_overrides:
                lo, hi = pair_overrides[pair]
            else:
                ri = COVALENT_RADII.get(ai.element, DEFAULT_COVALENT_RADIUS)
                rj = COVALENT_RADII.get(aj.element, DEFAULT_COVALENT_RADIUS)
                lo, hi = min_distance, (ri + rj) * tolerance
            if max_distance is not None:
                hi = min(hi, max_distance)
            if d2 <= hi * hi and d2 >= lo * lo:
                out.append(Bond(i=i, j=j, distance=math.sqrt(d2)))
    return out
