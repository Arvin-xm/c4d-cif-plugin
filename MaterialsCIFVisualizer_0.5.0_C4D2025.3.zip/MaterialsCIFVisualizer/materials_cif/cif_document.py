"""Small strict CIF 1.x reader. Quoting and data blocks remain distinct."""
from dataclasses import dataclass, field
import gzip
import os

MAX_BYTES = 16 * 1024 * 1024


class CIFError(ValueError):
    pass


@dataclass(frozen=True)
class Token:
    value: str
    quoted: bool = False
    line: int = 0


@dataclass
class CIFBlock:
    name: str
    scalars: dict = field(default_factory=dict)
    loops: list = field(default_factory=list)

    def atom_tables(self):
        return [(h, r) for h, r in self.loops if any(
            key in h for key in ('_atom_site_fract_x', '_atom_site_cartn_x'))]


def tag(value):
    value = value.lower()
    # Only normalize supported category aliases. Flattening every dot would
    # incorrectly merge unrelated tags such as radiation.wavelength_id and
    # radiation_wavelength.id in otherwise valid mmCIF documents.
    categories = ('_cell.', '_atom_site.', '_atom_sites.', '_space_group.',
                  '_space_group_symop.', '_symmetry.', '_chemical.')
    return value.replace('.', '_', 1) if value.startswith(categories) else value


def tokenize(text):
    text = text.lstrip('\ufeff')
    if text.startswith('#\\#CIF_2.0'):
        raise CIFError('CIF 2.0 syntax is not supported. Export a CIF 1.1 structure first.')
    tokens = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith(';'):
            first = i + 1
            value = [line[1:]]
            i += 1
            while i < len(lines) and not lines[i].startswith(';'):
                value.append(lines[i])
                i += 1
            if i == len(lines):
                raise CIFError('Unclosed semicolon text at line {}'.format(first))
            tail = lines[i][1:].strip()
            if tail and not tail.startswith('#'):
                raise CIFError('Unexpected text after closing semicolon at line {}'.format(i+1))
            tokens.append(Token('\n'.join(value), True, first))
        else:
            j = 0
            while j < len(line):
                if line[j].isspace():
                    j += 1
                    continue
                if line[j] == '#':
                    break
                start = j
                if line[j] in "'\"":
                    quote = line[j]
                    j += 1
                    start = j
                    while j < len(line):
                        if line[j] == quote and (j+1 == len(line) or line[j+1].isspace()):
                            break
                        j += 1
                    if j == len(line):
                        raise CIFError('Unclosed quoted value at line {}'.format(i+1))
                    tokens.append(Token(line[start:j], True, i+1))
                    j += 1
                else:
                    while j < len(line) and not line[j].isspace():
                        j += 1
                    tokens.append(Token(line[start:j], False, i+1))
        i += 1
    return tokens


def control(token):
    if token.quoted:
        return False
    value = token.value.lower()
    return value.startswith(('_', 'data_', 'save_')) or value in ('loop_', 'stop_', 'global_')


def read_blocks(text):
    if len(text.encode('utf-8')) > MAX_BYTES:
        raise CIFError('CIF exceeds the 16 MiB import limit.')
    tokens = tokenize(text)
    blocks, block, seen, names = [], None, set(), set()
    i = 0
    while i < len(tokens):
        token = tokens[i]
        value = token.value.lower()
        if not token.quoted and value.startswith('data_'):
            name = token.value[5:]
            if not name or name.lower() in names:
                raise CIFError('Empty or duplicate data block name at line {}'.format(token.line))
            names.add(name.lower())
            block = CIFBlock(name)
            blocks.append(block)
            seen = set()
            i += 1
            continue
        if block is None:
            raise CIFError('Expected data_<name> before CIF tags (line {}).'.format(token.line))
        if not token.quoted and (value.startswith('save_') or value == 'global_'):
            raise CIFError('CIF dictionaries/save frames are not structure imports.')
        if not token.quoted and value == 'loop_':
            headers = []
            i += 1
            while i < len(tokens) and not tokens[i].quoted and tokens[i].value.startswith('_'):
                key = tag(tokens[i].value)
                if key in seen:
                    raise CIFError('Duplicate tag {} in data_{}'.format(key, block.name))
                seen.add(key)
                headers.append(key)
                i += 1
            if not headers:
                raise CIFError('loop_ without headers in data_{}'.format(block.name))
            values = []
            while i < len(tokens) and not control(tokens[i]):
                values.append(tokens[i].value)
                i += 1
            if not values or len(values) % len(headers):
                raise CIFError('Incomplete loop rows in data_{}: {} columns, {} values.'.format(
                    block.name, len(headers), len(values)))
            block.loops.append((headers, [values[j:j+len(headers)] for j in range(0, len(values), len(headers))]))
            if i < len(tokens) and not tokens[i].quoted and tokens[i].value.lower() == 'stop_':
                i += 1
            continue
        if not token.quoted and value.startswith('_'):
            key = tag(token.value)
            if key in seen:
                raise CIFError('Duplicate tag {} in data_{}'.format(key, block.name))
            if i+1 == len(tokens) or control(tokens[i+1]):
                raise CIFError('Missing value for {}'.format(key))
            seen.add(key)
            block.scalars[key] = tokens[i+1].value
            i += 2
            continue
        raise CIFError('Unexpected token {!r} at line {}'.format(token.value, token.line))
    if not blocks:
        raise CIFError('No CIF data blocks found.')
    return blocks


def read_file(path):
    opener = gzip.open if str(path).lower().endswith('.gz') else open
    with opener(path, 'rb') as stream:
        data = stream.read(MAX_BYTES+1)
    if len(data) > MAX_BYTES:
        raise CIFError('Uncompressed CIF exceeds the 16 MiB import limit.')
    try:
        text = data.decode('utf-8-sig')
    except UnicodeDecodeError as exc:
        raise CIFError('CIF text must be UTF-8. Re-export it as CIF 1.1/UTF-8.') from exc
    return read_blocks(text)


def structure_blocks(blocks):
    return [block for block in blocks if block.atom_tables()]


def select_block(blocks, name=None):
    candidates = structure_blocks(blocks)
    if name is not None:
        for block in candidates:
            if block.name == name:
                return block
        raise CIFError('No coordinate structure named {!r}.'.format(name))
    if len(candidates) != 1:
        if not candidates:
            raise CIFError('No fractional or Cartesian atom coordinate table found.')
        raise CIFError('Multiple structures found. Select a data block: ' + ', '.join(b.name for b in candidates))
    return candidates[0]
