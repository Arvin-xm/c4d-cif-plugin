"""Conservative structure checks; unsupported disorder never becomes a full atom model."""
from collections import Counter, defaultdict
from itertools import product
import math
import re

from .cif_document import CIFError
from .symmetry import compile_op


def simple_formula(text):
    compact = ''.join(text.split())
    if not compact:
        return None
    matches = list(re.finditer(r'([A-Z][a-z]?)([0-9]+(?:\.[0-9]+)?)?', compact))
    if ''.join(m.group(0) for m in matches) != compact:
        return None
    counts = Counter()
    for match in matches:
        counts[match.group(1)] += float(match.group(2) or 1)
    return counts


def close_pairs(sites, lattice, cutoff=0.35):
    """Periodic spatial bins and an exact cutoff-bounded image search.

    Reciprocal-vector norms bound fractional components of any Cartesian vector
    shorter than cutoff, including skewed cells. Stop if the check is too large.
    """
    from .cif_parser import _vcross, _vdot, _vnorm, fract_to_cart
    a, b, c = lattice
    volume = abs(_vdot(a, _vcross(b, c)))
    bounds = [cutoff*_vnorm(v)/volume for v in (_vcross(b, c), _vcross(c, a), _vcross(a, b))]
    if max(bounds) > 1.5:
        raise CIFError('Cell is too skewed/thin for the supported overlap check. Reduce the cell basis first.')
    sizes = [max(1, int(1/max(v, 1e-12))) for v in bounds]
    buckets = defaultdict(list)
    checked = 0
    overlaps = []
    for i, site in enumerate(sites):
        key = tuple(int((site.fract[k] % 1)*sizes[k]) % sizes[k] for k in range(3))
        neighbors = {tuple((key[k]+shift[k]) % sizes[k] for k in range(3)) for shift in product((-1,0,1), repeat=3)}
        for neighbor in neighbors:
            for j in buckets.get(neighbor, ()):
                checked += 1
                if checked > 2000000:
                    raise CIFError('Overlap check exceeds its work limit; reduce/simplify the input cell.')
                delta = [site.fract[k]-sites[j].fract[k] for k in range(3)]
                shifts = [range(math.ceil(-delta[k]-bounds[k]-1e-10), math.floor(-delta[k]+bounds[k]+1e-10)+1) for k in range(3)]
                for shift in product(*shifts):
                    vector = fract_to_cart(tuple(delta[k]+shift[k] for k in range(3)), lattice)
                    distance = _vnorm(vector)
                    if distance < cutoff - 1e-9:
                        overlaps.append((sites[j].label, site.label, distance))
                        break
                if len(overlaps) >= 8:
                    return overlaps
        buckets[key].append(i)
    return overlaps


def validate_structure(structure):
    from .cif_parser import expand_site, _vdot, _vcross, fract_to_cart
    from .elements import COVALENT_RADII
    errors, notes = [], list(structure.warnings)
    expanded = structure.expanded_sites()
    lattice = structure.lattice_vectors()
    for site in structure.sites:
        images = expand_site(site, structure.symmetry_ops, lattice=lattice, merge_notes=notes)
        if abs(site.occupancy-1) > 1e-8:
            errors.append('Partial occupancy: {} = {}. Choose/export an ordered configuration before building.'.format(site.label, site.occupancy))
        if site.disorder:
            errors.append('Disorder group/assembly on {}: {}. Export one resolved configuration.'.format(site.label, site.disorder))
        if site.multiplicity is not None:
            actual = len(images)
            if actual != site.multiplicity:
                errors.append('Multiplicity mismatch for {}: CIF {}, expanded {}.'.format(site.label, site.multiplicity, actual))
    # Check that declared rotations preserve the supplied lattice metric.
    metric = [[_vdot(a, b) for b in lattice] for a in lattice]
    for operation in structure.symmetry_ops:
        matrix, translation = compile_op(operation)
        axes = [fract_to_cart(tuple(matrix[i][j] for i in range(3)), lattice) for j in range(3)]
        if any(abs(_vdot(axes[i], axes[j])-metric[i][j]) > 0.002*math.sqrt(metric[i][i]*metric[j][j]) for i in range(3) for j in range(3)):
            errors.append('Symmetry rotations conflict with cell lengths/angles; verify the axis setting.')
            break
    overlaps = close_pairs(expanded, lattice)
    if overlaps:
        details = '; '.join('{} / {}: {:.4g} A'.format(a,b,d) for a,b,d in overlaps)
        errors.append('Atoms are closer than 0.35 A under periodic boundaries: ' + details)
    counts = Counter()
    for site in expanded:
        counts[site.element] += site.occupancy
    formula = simple_formula(structure.formula_sum)
    z = structure.formula_units_z
    if z is not None and (z <= 0 or not float(z).is_integer()):
        errors.append('Formula units Z must be a positive integer.')
    if formula:
        if set(formula) != set(counts):
            errors.append('Formula elements do not match the occupied atom table: formula {}, sites {}.'.format(dict(formula), dict(counts)))
        elif z is not None and z > 0:
            if any(abs(counts[e]-n*z) > max(0.02, abs(n*z)*0.001) for e,n in formula.items()):
                if all(abs(counts[e]-n) <= max(0.02, abs(n)*0.001) for e,n in formula.items()):
                    notes.append('Formula/Z metadata disagree: _chemical_formula_sum already matches the full expanded cell, but Z={}. Atom coordinates were not changed; verify this exporter convention.'.format(z))
                else:
                    errors.append('Atom counts disagree with formula x Z: formula {}, Z {}, weighted counts {}.'.format(dict(formula), z, dict(counts)))
        else:
            ratios = [counts[e]/n for e,n in formula.items() if n > 0]
            if len(ratios) != len(formula) or max(ratios)-min(ratios) > max(ratios)*0.002:
                errors.append('Element ratios disagree with the declared chemical formula.')
            notes.append('Z is absent: formula ratios checked; absolute formula-unit count cannot be verified.')
    elif structure.formula_sum:
        notes.append('Complex chemical formula syntax was not checked: ' + structure.formula_sum)
    else:
        notes.append('No _chemical_formula_sum: formula/atom-count consistency cannot be verified.')
    volume = abs(_vdot(lattice[0], _vcross(lattice[1], lattice[2])))
    if structure.declared_volume is not None:
        if structure.declared_volume <= 0:
            errors.append('Declared cell volume must be positive.')
        elif abs(volume-structure.declared_volume) > max(0.01, volume*0.001):
            errors.append('Declared cell volume disagrees with the supplied lengths/angles.')
    fallback = sorted({s.element for s in expanded if s.element not in COVALENT_RADII})
    if fallback:
        notes.append('Generic bond radius used for {}; inferred bonds are only a visual aid.'.format(', '.join(fallback)))
    structure.errors = list(dict.fromkeys(errors))
    structure.warnings = list(dict.fromkeys(notes))
    return structure


def validation_report(structure):
    lines = [structure.name, 'Symmetry: ' + structure.symmetry_source,
             'Status: ' + ('BUILD BLOCKED' if structure.errors else 'Supported checks passed')]
    lines.extend('ERROR: ' + message for message in structure.errors)
    lines.extend('NOTE: ' + message for message in structure.warnings)
    lines.append('This is an import consistency check, not a full crystallographic refinement validation.')
    return '\n'.join(lines)
