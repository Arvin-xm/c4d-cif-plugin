"""Shared preview axes and orthographic camera fitting, without C4D."""
import math
from .display_geometry import dot,cross


def unit(v):
    n=math.sqrt(dot(v,v))
    if not math.isfinite(n) or n<1e-12:
        raise ValueError('视角方向无效。')
    return tuple(x/n for x in v)


def view_frame(yaw=35.0,pitch=40.0):
    """C4D camera local +Z is forward; local X/Y map to right/up."""
    if not all(math.isfinite(x) for x in (yaw,pitch)):
        raise ValueError('视角必须为有限数。')
    cy,sy=math.cos(math.radians(yaw)),math.sin(math.radians(yaw))
    cp,sp=math.cos(math.radians(pitch)),math.sin(math.radians(pitch))
    return ((cy,-sy,0.),(cp*sy,cp*cy,-sp),(sp*sy,sp*cy,cp))


def preview_coordinates(point,frame):
    # Negative forward distance sorts far objects before near ones.
    right,up,forward=frame
    return dot(point,right),dot(point,up),-dot(point,forward)


def axis_directions(built=None,kind='XYZ',yaw=35.,pitch=40.):
    if kind not in ('XYZ','ABC'):
        raise ValueError('Unknown axis mode.')
    vectors=((1.,0,0),(0,1.,0),(0,0,1.)) if kind=='XYZ' else built.cell_vectors
    frame=view_frame(yaw,pitch)
    return [dict(label=label,color=color,vector=unit(vector),
                 projected=preview_coordinates(unit(vector),frame))
            for label,color,vector in zip(kind,((.96,.3,.3),(.36,.87,.43),(.35,.61,1.)),vectors)]


def paper_layout(built,scene_scale=20.,atom_margin=2.,include_cell=False,
                 yaw=35.,pitch=40.,padding=.12,model_transform=None):
    if not built.atoms:
        raise ValueError('没有可出图的原子。')
    if not all(math.isfinite(v) for v in (scene_scale,atom_margin,padding)) or scene_scale<=0 or atom_margin<0 or not 0<=padding<.45:
        raise ValueError('出图倍率、半径或留白无效。')
    off,columns=model_transform or ((0.,0,0),((1.,0,0),(0,1.,0),(0,0,1.)))
    if not all(math.isfinite(v) for p in (off,*columns) for v in p):
        raise ValueError('模型变换无效。')
    def vector(v):
        return tuple(sum(columns[j][k]*v[j] for j in range(3)) for k in range(3))
    def point(p):
        q=vector(tuple(v*scene_scale for v in p))
        return tuple(q[k]+off[k] for k in range(3))
    local=view_frame(yaw,pitch)
    right=unit(vector(local[0]))
    forward=unit(cross(right,vector(local[1])))
    up=unit(cross(forward,right))
    frame=(right,up,forward)
    points=[point(a.position) for a in built.atoms]
    if include_cell:
        from .preview import cell_edges
        points += [point(p) for edge in cell_edges(built) for p in edge]
    lengths=[math.sqrt(dot(v,v)) for v in columns]
    orthogonal=all(abs(dot(columns[i],columns[j]))<1e-7*lengths[i]*lengths[j] for i in range(3) for j in range(i))
    bound=max(lengths) if orthogonal else math.sqrt(sum(v*v for v in lengths))
    radius=atom_margin*scene_scale*bound
    projections=[tuple(dot(p,v) for v in frame) for p in points]
    low=[min(p[k] for p in projections) for k in range(3)]
    high=[max(p[k] for p in projections) for k in range(3)]
    mid=[(a+b)/2 for a,b in zip(low,high)]
    target=tuple(sum(mid[j]*frame[j][k] for j in range(3)) for k in range(3))
    field=max(high[0]-low[0]+2*radius,high[1]-low[1]+2*radius,1.)/(1-2*padding)
    distance=max(field,high[2]-low[2]+2*radius,10.)*2
    eye=tuple(target[k]-forward[k]*distance for k in range(3))
    return dict(frame=frame,target=target,eye=eye,field=field,zoom=1024./field,
                points=points,radius=radius,padding=padding)
