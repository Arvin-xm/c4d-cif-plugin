"""Cinema 4D scene builder for Materials CIF Visualizer.

This module is imported only inside Cinema 4D. The core CIF parser remains
independent so it can be tested with normal CPython.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Sequence, Tuple

import c4d
from c4d import utils

from .cif_parser import BuiltStructure, CartesianAtom
from .bonds import Bond
from .elements import ELEMENT_COLORS, VISUAL_RADII, DEFAULT_COLOR, DEFAULT_VISUAL_RADIUS


Vec3 = Tuple[float, float, float]


def _cv(v: Vec3) -> c4d.Vector:
    return c4d.Vector(float(v[0]), float(v[1]), float(v[2]))


def _sub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]-b[0], a[1]-b[1], a[2]-b[2])


def _add(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]+b[0], a[1]+b[1], a[2]+b[2])


def _mul(a: Vec3, s: float) -> Vec3:
    return (a[0]*s, a[1]*s, a[2]*s)


def _dot(a: Vec3, b: Vec3) -> float:
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def _cross(a: Vec3, b: Vec3) -> Vec3:
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _norm(a: Vec3) -> float:
    return math.sqrt(_dot(a, a))


def _unit(a: Vec3) -> Vec3:
    n = _norm(a)
    if n < 1e-12:
        return (0.0, 1.0, 0.0)
    return _mul(a, 1.0/n)


def _material(doc, name: str, rgb: Tuple[float,float,float]) -> c4d.BaseMaterial:
    """Create/reuse a plain Cinema 4D material as a renderer-neutral fallback."""
    wanted = "MCV_" + name
    mat = doc.GetFirstMaterial()
    while mat:
        if mat.GetName() == wanted:
            return mat
        mat = mat.GetNext()
    mat = c4d.BaseMaterial(c4d.Mmaterial)
    mat.SetName(wanted)
    mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(*rgb)
    mat[c4d.MATERIAL_USE_REFLECTION] = False
    doc.InsertMaterial(mat)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, mat)
    return mat


def _assign_material(obj: c4d.BaseObject, mat: c4d.BaseMaterial) -> None:
    tag = c4d.TextureTag()
    tag.SetMaterial(mat)
    obj.InsertTag(tag)


def _make_cylinder(name: str, p1: Vec3, p2: Vec3, radius: float,
                   segments: int = 16) -> Optional[c4d.BaseObject]:
    delta = _sub(p2, p1)
    length = _norm(delta)
    if length < 1e-9:
        return None
    yaxis = _unit(delta)
    helper = (1.0, 0.0, 0.0) if abs(yaxis[0]) < 0.85 else (0.0, 0.0, 1.0)
    xaxis = _unit(_cross(helper, yaxis))
    zaxis = _unit(_cross(xaxis, yaxis))
    mid = _mul(_add(p1, p2), 0.5)

    obj = c4d.BaseObject(c4d.Ocylinder)
    obj.SetName(name)
    obj[c4d.PRIM_CYLINDER_RADIUS] = radius
    obj[c4d.PRIM_CYLINDER_HEIGHT] = length
    if hasattr(c4d, "PRIM_CYLINDER_SEG"):
        obj[c4d.PRIM_CYLINDER_SEG] = segments
    if hasattr(c4d, "PRIM_CYLINDER_CAPS"):
        obj[c4d.PRIM_CYLINDER_CAPS] = True
    obj.SetMg(c4d.Matrix(_cv(mid), _cv(xaxis), _cv(yaxis), _cv(zaxis)))
    return obj


def _group(name: str, parent: c4d.BaseObject) -> c4d.BaseObject:
    g = c4d.BaseObject(c4d.Onull)
    g.SetName(name)
    g.InsertUnder(parent)
    return g


def build_scene(doc: c4d.documents.BaseDocument,
                built: BuiltStructure,
                bonds: Sequence[Bond],
                name: str,
                scene_scale: float = 20.0,
                atom_scale: float = 0.70,
                bond_radius_angstrom: float = 0.08,
                make_atoms: bool = True,
                make_bonds: bool = True,
                make_cell: bool = False) -> c4d.BaseObject:
    """Build the model and return the root null."""
    doc.StartUndo()
    try:
        root = c4d.BaseObject(c4d.Onull)
        root.SetName("MCV_" + (name or "Structure"))
        doc.InsertObject(root)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, root)

        atoms_g = _group("ATOMS", root)
        bonds_g = _group("BONDS", root)
        cell_g = _group("UNIT_CELL", root)
        materials: Dict[str, c4d.BaseMaterial] = {}

        if make_atoms:
            for idx, atom in enumerate(built.atoms):
                sphere = c4d.BaseObject(c4d.Osphere)
                sphere.SetName(f"{atom.element}_{idx:04d}")
                radius = VISUAL_RADII.get(atom.element, DEFAULT_VISUAL_RADIUS) * atom_scale * scene_scale
                sphere[c4d.PRIM_SPHERE_RAD] = radius
                if hasattr(c4d, "PRIM_SPHERE_SUB"):
                    sphere[c4d.PRIM_SPHERE_SUB] = 24
                sphere.SetRelPos(_cv(_mul(atom.position, scene_scale)))
                sphere.InsertUnder(atoms_g)
                if atom.element not in materials:
                    materials[atom.element] = _material(doc, atom.element, ELEMENT_COLORS.get(atom.element, DEFAULT_COLOR))
                _assign_material(sphere, materials[atom.element])

        if make_bonds and bonds:
            bond_mat = _material(doc, "Bond", (0.42, 0.45, 0.50))
            rr = bond_radius_angstrom * scene_scale
            for k, bond in enumerate(bonds):
                p1 = _mul(built.atoms[bond.i].position, scene_scale)
                p2 = _mul(built.atoms[bond.j].position, scene_scale)
                cyl = _make_cylinder(f"Bond_{k:05d}", p1, p2, rr)
                if cyl is None:
                    continue
                cyl.InsertUnder(bonds_g)
                _assign_material(cyl, bond_mat)

        if make_cell:
            cell_mat = _material(doc, "UnitCell", (0.30, 0.34, 0.38))
            o = _mul(built.center_shift, scene_scale)
            a = _mul(built.cell_vectors[0], scene_scale)
            b = _mul(built.cell_vectors[1], scene_scale)
            c = _mul(built.cell_vectors[2], scene_scale)
            corners = [
                o, _add(o,a), _add(o,b), _add(o,c),
                _add(_add(o,a),b), _add(_add(o,a),c), _add(_add(o,b),c),
                _add(_add(_add(o,a),b),c),
            ]
            edges = [(0,1),(0,2),(0,3),(1,4),(1,5),(2,4),(2,6),(3,5),(3,6),(4,7),(5,7),(6,7)]
            rr = max(scene_scale * 0.025, 0.5)
            for k,(i,j) in enumerate(edges):
                cyl = _make_cylinder(f"CellEdge_{k:02d}", corners[i], corners[j], rr, 10)
                if cyl:
                    cyl.InsertUnder(cell_g)
                    _assign_material(cyl, cell_mat)

        # Hide empty organizational groups when their feature is disabled.
        if not make_atoms:
            atoms_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            atoms_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF
        if not make_bonds:
            bonds_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            bonds_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF
        if not make_cell:
            cell_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            cell_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF

        c4d.EventAdd()
        return root
    finally:
        doc.EndUndo()


def _look_at(obj: c4d.BaseObject, target: c4d.Vector) -> None:
    direction = target - obj.GetAbsPos()
    obj.SetAbsRot(utils.VectorToHPB(direction))


def setup_paper_scene(doc: c4d.documents.BaseDocument,
                      built: BuiltStructure,
                      scene_scale: float = 20.0) -> None:
    """Create a renderer-neutral scientific camera/light rig.

    This deliberately does not switch render engines or construct renderer-
    specific node materials. It can serve as a starting point for V-Ray while
    remaining safe across different V-Ray/C4D versions.
    """
    if not built.atoms:
        return
    doc.StartUndo()
    try:
        pts = [_mul(a.position, scene_scale) for a in built.atoms]
        xs, ys, zs = [p[0] for p in pts], [p[1] for p in pts], [p[2] for p in pts]
        extent = max(max(xs)-min(xs), max(ys)-min(ys), max(zs)-min(zs), 100.0)

        rig = c4d.BaseObject(c4d.Onull)
        rig.SetName("MCV_PAPER_SCENE")
        doc.InsertObject(rig)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, rig)

        cam = c4d.BaseObject(c4d.Ocamera)
        cam.SetName("MCV_Camera_Orthographic")
        cam[c4d.CAMERA_PROJECTION] = c4d.Pparallel
        if hasattr(c4d, "CAMERA_ZOOM"):
            # Empirical conservative default. User can adjust interactively.
            cam[c4d.CAMERA_ZOOM] = max(0.05, min(2.0, 900.0 / (extent + 1.0)))
        cam.SetAbsPos(c4d.Vector(extent*0.95, -extent*1.35, extent*0.95))
        _look_at(cam, c4d.Vector(0.0, 0.0, 0.0))
        cam.InsertUnder(rig)

        # Two large native area lights: compatible as a generic base rig and
        # easy to replace/convert in V-Ray if desired.
        key = c4d.BaseObject(c4d.Olight)
        key.SetName("MCV_Key_Area")
        key[c4d.LIGHT_TYPE] = c4d.LIGHT_TYPE_AREA
        key[c4d.LIGHT_BRIGHTNESS] = 0.85
        key[c4d.LIGHT_COLOR] = c4d.Vector(1.0, 0.98, 0.96)
        key[c4d.LIGHT_SHADOWTYPE] = c4d.LIGHT_SHADOWTYPE_AREA
        key.SetAbsPos(c4d.Vector(-extent*0.7, -extent*0.6, extent*1.8))
        _look_at(key, c4d.Vector(0.0, 0.0, 0.0))
        key.InsertUnder(rig)

        fill = c4d.BaseObject(c4d.Olight)
        fill.SetName("MCV_Fill_Area")
        fill[c4d.LIGHT_TYPE] = c4d.LIGHT_TYPE_AREA
        fill[c4d.LIGHT_BRIGHTNESS] = 0.35
        fill[c4d.LIGHT_COLOR] = c4d.Vector(0.95, 0.98, 1.0)
        fill[c4d.LIGHT_SHADOWTYPE] = c4d.LIGHT_SHADOWTYPE_NONE
        fill.SetAbsPos(c4d.Vector(extent*1.2, extent*0.6, extent*0.9))
        _look_at(fill, c4d.Vector(0.0, 0.0, 0.0))
        fill.InsertUnder(rig)

        rd = doc.GetActiveRenderData()
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, rd)
        rd[c4d.RDATA_XRES] = 3000
        rd[c4d.RDATA_YRES] = 3000
        rd[c4d.RDATA_ALPHACHANNEL] = True

        # Set viewport/render camera when possible.
        bd = doc.GetActiveBaseDraw()
        if bd is not None:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, bd)
            bd.SetSceneCamera(cam)
        c4d.EventAdd()
    finally:
        doc.EndUndo()
