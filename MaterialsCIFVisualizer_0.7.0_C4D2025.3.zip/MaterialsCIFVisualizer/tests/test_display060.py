"""Independent periodic-image oracle and slab selection regressions."""
from itertools import product
import math
from pathlib import Path
import unittest

from materials_cif import parse_cif_file,build_supercell
from materials_cif.cif_parser import CartesianAtom,BuiltStructure
from materials_cif.bonds import infer_bonds
from materials_cif.display_geometry import display_structure,slab_normal,dot

ROOT=Path(__file__).resolve().parent.parent


def sample(name='MoS2',dims=(1,1,1)):
    return build_supercell(parse_cif_file(str(ROOT/'examples'/(name+'.cif'))),*dims,'AUTO')


def crystal(vectors,points):
    return BuiltStructure([CartesianAtom('C',str(i),p) for i,p in enumerate(points)],
                          vectors,vectors,None,(0,0,0))


class Display060Tests(unittest.TestCase):
    def test_defaults_keep_both_original_samples_exactly(self):
        for name,count in (('MoS2',28),('PdSe2',29)):
            base=sample(name,(1,2,2))
            r=display_structure(base)
            self.assertEqual(r.built.atoms,base.atoms)
            self.assertEqual(r.bonds,infer_bonds(base.atoms))
            self.assertEqual(len(r.bonds),count)
            self.assertEqual(r.image_count,0)

    def test_fully_periodic_mos2_has_six_neighbors_per_mo(self):
        r=display_structure(sample(),periodic_axes=(True,True,True),
                            bond_options={'allowed_pairs':[('Mo','S')],'tolerance':1.18})
        degree=[0]*r.selected_count
        for b in r.bonds:
            if b.i<r.selected_count: degree[b.i]+=1
            if b.j<r.selected_count: degree[b.j]+=1
        self.assertTrue(r.image_count>0)
        self.assertEqual([degree[i] for i,a in enumerate(r.built.atoms[:r.selected_count]) if a.element=='Mo'],[6,6])
        self.assertTrue(all(b.i<r.selected_count or b.j<r.selected_count for b in r.bonds))
        self.assertEqual(len({(a.element,tuple(round(x,8) for x in a.position)) for a in r.built.atoms}),len(r.built.atoms))

    def test_skew_cell_and_long_cutoff_match_independent_brute_oracle(self):
        vectors=((2.,0,0),(1.85,.6,0),(.3,.2,5.))
        base=crystal(vectors,[(.11,.08,.3),(1.41,.35,.7)])
        r=display_structure(base,periodic_axes=(True,True,True),
                            bond_options={'pair_overrides':{('C','C'):(.35,2.5)}})
        actual=set()
        for b in r.bonds:
            for i,j in ((b.i,b.j),(b.j,b.i)):
                if i<r.selected_count:
                    a=r.built.atoms[j]
                    actual.add((i,a.label.split(' [')[0],a.periodic_image))
        expected=set()
        for i,a in enumerate(base.atoms):
            for image in product(range(-7,8),range(-7,8),range(-2,3)):
                for b in base.atoms:
                    p=tuple(b.position[k]+sum(image[h]*vectors[h][k] for h in range(3)) for k in range(3))
                    distance=math.dist(a.position,p)
                    if .35<=distance<=2.5:
                        expected.add((i,b.label,image))
        self.assertEqual(actual,expected)
        self.assertTrue(any(max(abs(k) for k in a.periodic_image)>1 for a in r.built.atoms))

    def test_periodic_axes_flags_are_respected(self):
        base=crystal(((1.,0,0),(0,1.,0),(0,0,1.)),[(0,0,0)])
        r=display_structure(base,periodic_axes=(True,False,False),
                            bond_options={'pair_overrides':{('C','C'):(.35,1.01)}})
        self.assertEqual(r.image_count,2)
        self.assertEqual({a.periodic_image for a in r.built.atoms},{(0,0,0),(-1,0,0),(1,0,0)})
        self.assertEqual(len(r.bonds),2)

    def test_disabled_pairs_or_bonds_do_not_add_unconnected_images(self):
        for extra in ({'make_bonds':False},{'bond_options':{'allowed_pairs':[]}},
                      {'bond_options':{'pair_overrides':{('Mo','S'):(.35,1.0)},'allowed_pairs':[('Mo','S')]}}):
            r=display_structure(sample(),periodic_axes=(True,True,True),**extra)
            self.assertEqual(r.image_count,0)
            self.assertEqual(r.bonds,[])

    def test_mos2_single_layer_preserves_stoichiometry(self):
        base=sample(dims=(2,2,2))
        for layer in (1,2,3,4):
            r=display_structure(base,crop='layer',normal='C',layer=layer,layer_gap=2.5)
            self.assertEqual(r.layer_count,4)
            self.assertEqual(r.selected_count,12)
            self.assertEqual(sum(a.element=='Mo' for a in r.built.atoms),4)
            self.assertEqual(sum(a.element=='S' for a in r.built.atoms),8)
        self.assertEqual(len(base.atoms),48)

    def test_periodic_single_layer_does_not_restore_other_layers(self):
        base=sample(dims=(2,2,2))
        r=display_structure(base,crop='layer',normal='C',layer=2,layer_gap=2.5,
                            periodic_axes=(True,True,True),bond_options={'allowed_pairs':[('Mo','S')]})
        n=slab_normal(base,'C')
        heights=[dot(a.position,n) for a in r.built.atoms[:r.selected_count]]
        self.assertTrue(r.image_count>0)
        self.assertTrue(all(min(heights)-1e-7<=dot(a.position,n)<=max(heights)+1e-7 for a in r.built.atoms))
        degree=[0]*r.selected_count
        for b in r.bonds:
            if b.i<r.selected_count: degree[b.i]+=1
            if b.j<r.selected_count: degree[b.j]+=1
        self.assertEqual([degree[i] for i,a in enumerate(r.built.atoms[:r.selected_count]) if a.element=='Mo'],[6]*4)

    def test_thickness_in_angstroms_includes_exact_endpoints(self):
        base=crystal(((10,0,0),(0,10,0),(0,0,10)),[(0,0,-1),(0,0,0),(0,0,1),(0,0,2)])
        r=display_structure(base,crop='thickness',center=0,thickness=2)
        self.assertEqual([a.position[2] for a in r.built.atoms],[-1,0,1])
        self.assertEqual(r.built.cell_vectors,base.cell_vectors)
        self.assertEqual(r.built.center_shift,base.center_shift)
        self.assertTrue(all(b.j<len(r.built.atoms) for b in r.bonds))

    def test_crystal_plane_normal_uses_reciprocal_not_lattice_direction(self):
        base=crystal(((3.,1.,1.),(1.,4.,0.),(.5,0.,5.)),[(0,0,0)])
        for k,axis in enumerate('ABC'):
            n=slab_normal(base,axis)
            self.assertAlmostEqual(dot(n,n),1.)
            for j,v in enumerate(base.cell_vectors):
                if j!=k: self.assertAlmostEqual(dot(n,v),0.)
            self.assertGreater(dot(n,base.cell_vectors[k]),0)

    def test_palladium_selenide_periodic_contacts_are_rule_limited(self):
        base=sample('PdSe2',(1,2,2))
        r=display_structure(base,periodic_axes=(True,True,True),
                            bond_options={'allowed_pairs':[('Pd','Se'),('Se','Se')]})
        self.assertGreater(r.image_count,0)
        self.assertTrue(all(tuple(sorted((r.built.atoms[b.i].element,r.built.atoms[b.j].element))) in
                            {('Pd','Se'),('Se','Se')} for b in r.bonds))
        self.assertTrue(all(abs(math.dist(r.built.atoms[b.i].position,r.built.atoms[b.j].position)-b.distance)<1e-10 for b in r.bonds))

    def test_empty_crop_invalid_layer_and_nonfinite_values_explain_failure(self):
        for kwargs in ({'crop':'thickness','center':1000,'thickness':.1},
                       {'crop':'thickness','thickness':0},
                       {'crop':'thickness','center':math.nan},
                       {'crop':'layer','layer':99},{'crop':'layer','layer_gap':0},
                       {'periodic_axes':(True,False)},
                       {'periodic_axes':(True,True,True),'bond_options':{'pair_overrides':{('Mo','S'):(5,1)}}}):
            with self.assertRaises(ValueError): display_structure(sample(),**kwargs)

    def test_atom_limit_counts_periodic_images(self):
        with self.assertRaisesRegex(ValueError,'上限'):
            display_structure(sample(),periodic_axes=(True,True,True),max_atoms=6)

    def test_large_skew_periodic_search_fails_explicitly_instead_of_hanging(self):
        base=crystal(((1.,0,0),(.999,.0001,0),(0,0,1.)),[(0,0,0)])
        with self.assertRaisesRegex(ValueError,'范围过大'):
            display_structure(base,periodic_axes=(True,True,True))

    def test_no_input_atom_mutation_or_recentring(self):
        base=sample()
        before=[vars(a).copy() for a in base.atoms]
        display_structure(base,periodic_axes=(True,True,True))
        self.assertEqual([vars(a) for a in base.atoms],before)


if __name__=='__main__': unittest.main()
