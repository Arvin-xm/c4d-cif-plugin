$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# This installer touches only the two verified copies of this plugin.
# All old files are preserved outside Cinema 4D's plugin search directories.
$packagePath = Join-Path $PSScriptRoot 'MaterialsCIFVisualizer'
$installRoot = 'E:\C4D_Plugins'
$installPath = Join-Path $installRoot 'MaterialsCIFVisualizer'
$prefsPath = Join-Path $env:APPDATA 'Maxon\Maxon Cinema 4D 2025_B76FCBE4\plugins\MaterialsCIFVisualizer'
$backupRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Codex\MaterialsCIFVisualizer_Backups'
$backupPath = Join-Path $backupRoot ((Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0,8))
$stagePath = Join-Path $installRoot ('.MaterialsCIFVisualizer_stage_' + [guid]::NewGuid().ToString('N'))

function Get-MCVSHA256([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}

function Assert-ExactPath([string]$actual, [string]$expected) {
    if ([IO.Path]::GetFullPath($actual).TrimEnd('\') -ine [IO.Path]::GetFullPath($expected).TrimEnd('\')) {
        throw "Unexpected path: $actual"
    }
}

function Assert-NoLinks([string]$path) {
    if (Test-Path -LiteralPath $path) {
        $items = @((Get-Item -LiteralPath $path)) + @(Get-ChildItem -LiteralPath $path -Recurse -Force)
        if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count -gt 0) {
            throw "Linked files/directories are not supported: $path"
        }
    }
}

if (@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -in @('Cinema 4D','c4dpy') }).Count -gt 0) {
    throw 'Save your work and close Cinema 4D, then run Install.cmd again.'
}
if (-not (Test-Path -LiteralPath 'E:\' -PathType Container)) { throw 'Drive E: was not found.' }
Assert-ExactPath $installPath 'E:\C4D_Plugins\MaterialsCIFVisualizer'
Assert-ExactPath $prefsPath (Join-Path $env:APPDATA 'Maxon\Maxon Cinema 4D 2025_B76FCBE4\plugins\MaterialsCIFVisualizer')
Assert-NoLinks $packagePath
Assert-NoLinks $installRoot
Assert-NoLinks (Split-Path -Parent $prefsPath)

$manifestPath = Join-Path $packagePath 'MANIFEST.sha256.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'Missing package manifest.' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
foreach ($entry in $manifest.files) {
    $filePath = [IO.Path]::GetFullPath((Join-Path $packagePath $entry.path))
    $packagePrefix = [IO.Path]::GetFullPath($packagePath).TrimEnd('\') + '\'
    if (-not $filePath.StartsWith($packagePrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid manifest path.' }
    if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) { throw "Missing file: $($entry.path)" }
    if ((Get-MCVSHA256 $filePath) -ine $entry.sha256) { throw "File verification failed: $($entry.path)" }
}
foreach ($required in @('MaterialsCIFVisualizer.pyp','res\c4d_symbols.h','materials_cif\ui.py')) {
    if (-not (Test-Path -LiteralPath (Join-Path $packagePath $required))) { throw "Missing file: $required" }
}
New-Item -ItemType Directory -Path $installRoot -Force | Out-Null
New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
$moved = @()
$committed = $false
try {
    # Copy and verify before moving either existing installation.
    Copy-Item -LiteralPath $packagePath -Destination $stagePath -Recurse
    foreach ($entry in $manifest.files) {
        if ((Get-MCVSHA256 (Join-Path $stagePath $entry.path)) -ine $entry.sha256) { throw 'Staging verification failed.' }
    }
    foreach ($item in @(
        @{ source = $installPath; label = 'E_external_plugins' },
        @{ source = $prefsPath; label = 'C4D_preferences_plugins' }
    )) {
        if (Test-Path -LiteralPath $item.source) {
            $savedPath = Join-Path $backupPath $item.label
            Assert-ExactPath $savedPath (Join-Path $backupPath $item.label)
            Move-Item -LiteralPath $item.source -Destination $savedPath
            $moved += @{ original = $item.source; saved = $savedPath }
        }
    }
    # Recheck in case the user opened Cinema 4D during installation.
    if (@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -in @('Cinema 4D','c4dpy') }).Count -gt 0) {
        throw 'Cinema 4D was started during installation; restoring old plugin files.'
    }
    Assert-ExactPath $stagePath (Join-Path $installRoot (Split-Path -Leaf $stagePath))
    Move-Item -LiteralPath $stagePath -Destination $installPath
    $committed = $true
    foreach ($entry in $manifest.files) {
        if ((Get-MCVSHA256 (Join-Path $installPath $entry.path)) -ine $entry.sha256) { throw 'Installed file verification failed.' }
    }
    $priorLog = Join-Path ([IO.Path]::GetTempPath()) 'MaterialsCIFVisualizer.log'
    if (Test-Path -LiteralPath $priorLog) {
        try { Move-Item -LiteralPath $priorLog -Destination (Join-Path $backupPath 'previous_plugin_log.txt') } catch { Write-Warning 'Could not archive the previous diagnostic log.' }
    }
    "Installed version 0.4.0: $installPath"
    "Old installations preserved: $backupPath"
    'Start Cinema 4D. Open Extensions > Materials CIF Visualizer > Self-test.'
    'Diagnostic log: %TEMP%\MaterialsCIFVisualizer.log'
    @("Installed: $installPath", "Backups: $backupPath") | Set-Content -LiteralPath (Join-Path $backupPath 'installation.txt') -Encoding UTF8
} catch {
    $failure = $_
    if (Test-Path -LiteralPath $stagePath) {
        Assert-ExactPath $stagePath (Join-Path $installRoot (Split-Path -Leaf $stagePath))
        # Keep an incomplete package outside the search path, so it cannot load.
        Move-Item -LiteralPath $stagePath -Destination (Join-Path $backupPath 'failed_staging')
    }
    if ($committed -and (Test-Path -LiteralPath $installPath)) {
        Assert-ExactPath $installPath 'E:\C4D_Plugins\MaterialsCIFVisualizer'
        Move-Item -LiteralPath $installPath -Destination (Join-Path $backupPath 'failed_new_installation')
    }
    for ($index = $moved.Count - 1; $index -ge 0; $index--) {
        $item = $moved[$index]
        if ((Test-Path -LiteralPath $item.saved) -and -not (Test-Path -LiteralPath $item.original)) {
            Move-Item -LiteralPath $item.saved -Destination $item.original
        }
    }
    throw $failure
}
