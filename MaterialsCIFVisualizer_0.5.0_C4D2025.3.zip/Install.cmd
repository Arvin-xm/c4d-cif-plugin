@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
if errorlevel 1 (
  echo Installation did not complete. Read the error above.
) else (
  echo Installation completed. Start Cinema 4D and run Self-test.
)
pause
