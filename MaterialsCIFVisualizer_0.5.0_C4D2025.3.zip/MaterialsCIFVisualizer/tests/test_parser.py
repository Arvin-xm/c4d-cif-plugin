import os
import unittest

from materials_cif import parse_cif_file, structure_summary, build_supercell, infer_bonds

ROOT = os.path.dirname(os.path.dirname(__file__))


class CIFParserTests(unittest.TestCase):
    def test_pdse2(self):
        s = parse_cif_file(os.path.join(ROOT, 'examples', 'PdSe2.cif'))
        info = structure_summary(s)
        self.assertEqual(info['space_group'], 'P 21/c')
        self.assertEqual(info['expanded_atoms'], 6)
        self.assertEqual(info['elements'], {'Pd': 2, 'Se': 4})
        self.assertEqual(info['detected_vacuum_axis'], 'A')
        built = build_supercell(s, 1, 1, 1, 'AUTO')
        self.assertEqual(len(built.atoms), 6)
        # Slab should be unwrapped together along the detected vacuum axis.
        z = [a.position[2] for a in built.atoms]
        self.assertLess(max(z) - min(z), 2.0)

    def test_mos2(self):
        s = parse_cif_file(os.path.join(ROOT, 'examples', 'MoS2.cif'))
        info = structure_summary(s)
        self.assertEqual(info['space_group'], 'P6_3/mmc')
        self.assertEqual(info['expanded_atoms'], 6)
        self.assertEqual(info['elements'], {'Mo': 2, 'S': 4})
        # A long c axis alone is not sufficient evidence for explicit vacuum.
        self.assertIsNone(info['detected_vacuum_axis'])
        built = build_supercell(s, 2, 2, 1, 'AUTO')
        self.assertEqual(len(built.atoms), 24)
        self.assertEqual({a.element for a in built.atoms}, {'Mo', 'S'})

    def test_bond_inference_runs(self):
        s = parse_cif_file(os.path.join(ROOT, 'examples', 'PdSe2.cif'))
        built = build_supercell(s, 1, 2, 2, 'AUTO')
        bonds = infer_bonds(built.atoms, tolerance=1.20)
        self.assertGreater(len(bonds), 0)
        self.assertTrue(all(b.distance > 0 for b in bonds))


if __name__ == '__main__':
    unittest.main()
