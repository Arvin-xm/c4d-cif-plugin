import math
from pathlib import Path
import unittest

from materials_cif import parse_cif_file, parse_cif_text, build_supercell
from materials_cif.bonds import infer_bonds
from materials_cif.preview import PreviewData, cell_edges

ROOT=Path(__file__).resolve().parent.parent


class Preview050Tests(unittest.TestCase):
    def sample(self,name='MoS2',dims=(1,2,2)):
        return build_supercell(parse_cif_file(str(ROOT/'examples'/(name+'.cif'))),*dims,'AUTO')

    def test_all_atoms_and_colored_bond_halves_are_present(self):
        for name in ('MoS2','PdSe2'):
            built=self.sample(name)
            bonds=infer_bonds(built.atoms,tolerance=1.18)
            data=PreviewData(built,bonds,make_cell=True)
            primitives,scale=data.project(700,500)
            atoms=[p for p in primitives if p['kind']=='atom']
            self.assertEqual(len(atoms),len(built.atoms))
            self.assertEqual({p['index'] for p in atoms},set(range(len(built.atoms))))
            expected=sum(1 if built.atoms[b.i].element==built.atoms[b.j].element else 2 for b in bonds)
            self.assertEqual(sum(p['kind']=='bond' for p in primitives),expected)
            self.assertEqual(sum(p['kind']=='cell' for p in primitives),12)
            self.assertGreater(scale,0)

    def test_fit_contains_ball_silhouettes_at_several_views(self):
        data=PreviewData(self.sample(),[])
        for yaw,pitch in ((35,40),(0,0),(0,90),(90,90),(180,-30)):
            primitives,_=data.project(440,340,yaw,pitch)
            for p in primitives:
                if p['kind']=='atom':
                    x,y=p['center']; r=p['radius']
                    self.assertGreaterEqual(x-r,19)
                    self.assertLessEqual(x+r,421)
                    self.assertGreaterEqual(y-r,29)
                    self.assertLessEqual(y+r,311)

    def test_top_projection_relative_distances_and_zoom(self):
        data=PreviewData(self.sample(),[])
        p,scale=data.project(440,340,0,0)
        spheres={item['index']:item for item in p if item['kind']=='atom'}
        for i,j in ((0,1),(2,3)):
            a,b=data.built.atoms[i].position,data.built.atoms[j].position
            actual=math.dist(spheres[i]['center'],spheres[j]['center'])
            self.assertAlmostEqual(actual,math.hypot(a[0]-b[0],a[1]-b[1])*scale)
        self.assertAlmostEqual(data.project(440,340,0,0,2)[1],scale*2)

    def test_style_snapshot_is_not_changed_by_later_edits(self):
        styles={'Mo':{'color':(1,0,0),'radius':1.5}}
        data=PreviewData(self.sample(),[],styles,atom_scale=.8)
        styles['Mo']['color']=(0,1,0)
        styles['Mo']['radius']=.2
        self.assertEqual(data.color('Mo'),(1,0,0))
        self.assertAlmostEqual(data.radius('Mo'),1.2)

    def test_visibility_flags_match_requested_geometry(self):
        data=PreviewData(self.sample(),[],make_atoms=False,make_bonds=False,make_cell=True)
        p,_=data.project(440,340)
        self.assertEqual(len(p),12)
        self.assertTrue(all(item['kind']=='cell' for item in p))

    def test_cells_have_expected_supercell_edge_vectors(self):
        built=self.sample('PdSe2')
        edges=cell_edges(built)
        self.assertEqual(len(edges),12)
        for edge,vector in zip(edges[:3],built.cell_vectors):
            for start,end,want in zip(*edge,vector):
                self.assertAlmostEqual(end-start,want)

    def test_10000_atoms_are_not_sampled_or_truncated(self):
        from materials_cif.cif_parser import CartesianAtom
        built=self.sample()
        built.atoms=[CartesianAtom('C','C',(i*.8,0,0)) for i in range(10000)]
        p,_=PreviewData(built,[]).project(440,340)
        self.assertEqual(len(p),10000)

    def test_new_arbitrary_element_cif_uses_its_own_positions_and_palette(self):
        text='''data_new
_cell_length_a 8
_cell_length_b 9
_cell_length_c 10
_cell_angle_alpha 90
_cell_angle_beta 90
_cell_angle_gamma 90
_space_group_name_H-M_alt 'P 1'
loop_
_atom_site_type_symbol
_atom_site_label
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
Fe Fe1 .1 .2 .3
O O1 .3 .2 .3
'''
        built=build_supercell(parse_cif_text(text))
        data=PreviewData(built,infer_bonds(built.atoms))
        self.assertEqual({a.element for a in data.built.atoms},{'Fe','O'})
        self.assertEqual(len(data.bonds),1)
        self.assertNotEqual(data.color('Fe'),data.color('O'))

    def test_visible_bonds_start_at_ball_surfaces_not_inside_centers(self):
        from materials_cif.cif_parser import CartesianAtom
        from materials_cif.bonds import Bond
        built=self.sample()
        built.atoms=[CartesianAtom('C','C',(0,0,0)),CartesianAtom('O','O',(4,0,0))]
        styles={'C':{'radius':1},'O':{'radius':.5}}
        data=PreviewData(built,[Bond(0,1,4)],styles,atom_scale=1)
        p,scale=data.project(440,340,0,0)
        balls={item['index']:item for item in p if item['kind']=='atom'}
        pieces=[item for item in p if item['kind']=='bond']
        self.assertAlmostEqual(pieces[0]['start'][0]-balls[0]['center'][0],scale)
        self.assertAlmostEqual(balls[1]['center'][0]-pieces[1]['end'][0],scale*.5)
        self.assertEqual(pieces[0]['end'],pieces[1]['start'])
        data.make_atoms=False
        p,_=data.project(440,340,0,0)
        pieces=[item for item in p if item['kind']=='bond']
        self.assertEqual(pieces[0]['start'],balls[0]['center'])
        self.assertEqual(pieces[1]['end'],balls[1]['center'])

    def test_overlapping_balls_occlude_bond_without_changing_bond_data(self):
        from materials_cif.cif_parser import CartesianAtom
        from materials_cif.bonds import Bond
        built=self.sample()
        built.atoms=[CartesianAtom('C','C',(0,0,0)),CartesianAtom('O','O',(1,0,0))]
        data=PreviewData(built,[Bond(0,1,1)],{'C':{'radius':1},'O':{'radius':1}},atom_scale=1)
        p,_=data.project(440,340,0,0)
        self.assertTrue(all(item['hidden'] for item in p if item['kind']=='bond'))
        self.assertEqual(len(data.bonds),1)


if __name__=='__main__':
    unittest.main()
