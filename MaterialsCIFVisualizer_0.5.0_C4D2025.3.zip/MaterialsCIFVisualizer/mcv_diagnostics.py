"""Standard-library-only diagnostics available before C4D/UI imports."""
import datetime
import os
import tempfile
import traceback

LOG_PATH = os.path.join(tempfile.gettempdir(), 'MaterialsCIFVisualizer.log')


def log(stage, detail=''):
    line = '[MaterialsCIFVisualizer] {} pid={} {} {}'.format(
        datetime.datetime.now().isoformat(timespec='seconds'), os.getpid(), stage, detail)
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        with open(LOG_PATH, 'a', encoding='utf-8') as stream:
            stream.write(line + '\n')
    except OSError:
        pass  # A log error must never prevent registration.


def log_exception(stage):
    log(stage, traceback.format_exc())
