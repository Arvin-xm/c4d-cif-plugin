"""Cinema 4D GeDialog UI for Materials CIF Visualizer."""
from __future__ import annotations

import os
import c4d
from mcv_diagnostics import log, log_exception, LOG_PATH

from . import parse_cif_file, structure_summary, build_supercell, infer_bonds
from .c4d_builder import build_scene, setup_paper_scene


class MaterialsCIFDialog(c4d.gui.GeDialog):
    ID_PATH = 1001
    ID_BROWSE = 1002
    ID_SUMMARY = 1003
    ID_NX = 1010
    ID_NY = 1011
    ID_NZ = 1012
    ID_ATOMS = 1020
    ID_BONDS = 1021
    ID_CELL = 1022
    ID_ATOM_SCALE = 1030
    ID_BOND_RADIUS = 1031
    ID_BOND_TOL = 1032
    ID_SCENE_SCALE = 1033
    ID_AXIS = 1040
    ID_BUILD = 1050
    ID_PAPER = 1051
    ID_RELOAD = 1052
    ID_SELFTEST = 1053

    def __init__(self):
        super().__init__()
        self.structure = None
        self.built = None
        self.last_path = ""

    def CreateLayout(self):
        log('LAYOUT_START')
        self.SetTitle("Materials CIF Visualizer")

        if self.GroupBegin(2000, c4d.BFH_SCALEFIT, 1, 0, "CIF Structure"):
            if self.GroupBegin(2001, c4d.BFH_SCALEFIT, 2, 1, ""):
                self.AddEditText(self.ID_PATH, c4d.BFH_SCALEFIT)
                self.AddButton(self.ID_BROWSE, c4d.BFH_RIGHT, name="Browse…")
            self.GroupEnd()
            self.AddStaticText(self.ID_SUMMARY, c4d.BFH_SCALEFIT, name="No CIF loaded")
        self.GroupEnd()

        if self.GroupBegin(2100, c4d.BFH_SCALEFIT, 6, 1, "Supercell"):
            self.AddStaticText(2101, c4d.BFH_LEFT, name="Nx")
            self.AddEditNumberArrows(self.ID_NX, c4d.BFH_LEFT)
            self.AddStaticText(2102, c4d.BFH_LEFT, name="Ny")
            self.AddEditNumberArrows(self.ID_NY, c4d.BFH_LEFT)
            self.AddStaticText(2103, c4d.BFH_LEFT, name="Nz")
            self.AddEditNumberArrows(self.ID_NZ, c4d.BFH_LEFT)
        self.GroupEnd()

        if self.GroupBegin(2200, c4d.BFH_SCALEFIT, 3, 1, "Geometry"):
            self.AddCheckbox(self.ID_ATOMS, c4d.BFH_LEFT, 0, 0, "Atoms")
            self.AddCheckbox(self.ID_BONDS, c4d.BFH_LEFT, 0, 0, "Bonds")
            self.AddCheckbox(self.ID_CELL, c4d.BFH_LEFT, 0, 0, "Unit Cell")
        self.GroupEnd()

        if self.GroupBegin(2300, c4d.BFH_SCALEFIT, 2, 0, "Style"):
            self.AddStaticText(2301, c4d.BFH_LEFT, name="Atom scale")
            self.AddEditNumberArrows(self.ID_ATOM_SCALE, c4d.BFH_SCALEFIT)
            self.AddStaticText(2302, c4d.BFH_LEFT, name="Bond radius (Å)")
            self.AddEditNumberArrows(self.ID_BOND_RADIUS, c4d.BFH_SCALEFIT)
            self.AddStaticText(2303, c4d.BFH_LEFT, name="Bond tolerance")
            self.AddEditNumberArrows(self.ID_BOND_TOL, c4d.BFH_SCALEFIT)
            self.AddStaticText(2304, c4d.BFH_LEFT, name="Scene units / Å")
            self.AddEditNumberArrows(self.ID_SCENE_SCALE, c4d.BFH_SCALEFIT)
        self.GroupEnd()

        if self.GroupBegin(2400, c4d.BFH_SCALEFIT, 2, 1, "2D alignment"):
            self.AddStaticText(2401, c4d.BFH_LEFT, name="Vacuum / out-of-plane axis")
            self.AddComboBox(self.ID_AXIS, c4d.BFH_SCALEFIT)
            self.AddChild(self.ID_AXIS, 0, "Auto (atomic-gap detection)")
            self.AddChild(self.ID_AXIS, 1, "A → Z")
            self.AddChild(self.ID_AXIS, 2, "B → Z")
            self.AddChild(self.ID_AXIS, 3, "C → Z")
            self.AddChild(self.ID_AXIS, 4, "None / raw Cartesian")
        self.GroupEnd()

        if self.GroupBegin(2500, c4d.BFH_SCALEFIT, 4, 1, ""):
            self.AddButton(self.ID_RELOAD, c4d.BFH_LEFT, name="Reload CIF")
            self.AddButton(self.ID_BUILD, c4d.BFH_SCALEFIT, name="BUILD MODEL")
            self.AddButton(self.ID_PAPER, c4d.BFH_RIGHT, name="Paper Scene")
            self.AddButton(self.ID_SELFTEST, c4d.BFH_RIGHT, name="Self-test")
        self.GroupEnd()
        log('LAYOUT_OK')
        return True

    def InitValues(self):
        self.SetInt32(self.ID_NX, 1, min=1, max=50, step=1)
        self.SetInt32(self.ID_NY, 1, min=1, max=50, step=1)
        self.SetInt32(self.ID_NZ, 1, min=1, max=50, step=1)
        self.SetBool(self.ID_ATOMS, True)
        self.SetBool(self.ID_BONDS, True)
        self.SetBool(self.ID_CELL, False)
        self.SetFloat(self.ID_ATOM_SCALE, 0.70, min=0.05, max=3.0, step=0.05)
        self.SetFloat(self.ID_BOND_RADIUS, 0.08, min=0.01, max=1.0, step=0.01)
        self.SetFloat(self.ID_BOND_TOL, 1.18, min=0.5, max=2.5, step=0.01)
        self.SetFloat(self.ID_SCENE_SCALE, 20.0, min=0.1, max=1000.0, step=1.0)
        self.SetInt32(self.ID_AXIS, 0)
        log('INIT_VALUES_OK')
        return True

    def _axis_value(self):
        return {0: "AUTO", 1: "A", 2: "B", 3: "C", 4: "NONE"}.get(self.GetInt32(self.ID_AXIS), "AUTO")

    def _load(self, path):
        try:
            log('CIF_LOAD_START', path)
            self.structure = parse_cif_file(path)
            self.built = None
            self.last_path = path
            self.SetString(self.ID_PATH, path)
            info = structure_summary(self.structure)
            elem = ", ".join(f"{k}:{v}" for k,v in sorted(info['elements'].items()))
            cell = info['cell']
            vac = info['detected_vacuum_axis'] or "none"
            summary = (
                f"{info['name']} | SG: {info['space_group'] or '?'} | "
                f"atoms/cell: {info['expanded_atoms']} ({elem}) | "
                f"a,b,c = {cell[0]:.4g}, {cell[1]:.4g}, {cell[2]:.4g} Å | "
                f"α,β,γ = {cell[3]:.3g}, {cell[4]:.3g}, {cell[5]:.3g}° | auto vacuum: {vac}"
            )
            self.SetString(self.ID_SUMMARY, summary)
            log('CIF_LOAD_OK', summary)
            return True
        except Exception as exc:
            self.structure = None
            self.built = None
            self.SetString(self.ID_SUMMARY, 'CIF load failed')
            c4d.gui.MessageDialog("CIF load failed:\n" + str(exc))
            log_exception('CIF_LOAD_FAILED')
            return False

    def _ensure_loaded(self):
        path = self.GetString(self.ID_PATH).strip()
        if not path or not os.path.isfile(path):
            c4d.gui.MessageDialog("Please select a valid CIF file first.")
            return False
        if self.structure is None or path != self.last_path:
            return self._load(path)
        return True

    def Command(self, cid, msg):
        if cid == self.ID_SELFTEST:
            try:
                from mcv_selftest import run_selftest
                result = run_selftest(os.path.dirname(os.path.dirname(__file__)))
                log('SELFTEST_OK', result)
                c4d.gui.MessageDialog(result + '\n\nLog: ' + LOG_PATH)
            except Exception as exc:
                log_exception('SELFTEST_FAILED')
                c4d.gui.MessageDialog('Self-test failed:\n' + str(exc) + '\nLog: ' + LOG_PATH)
            return True

        if cid == self.ID_BROWSE:
            path = c4d.storage.LoadDialog(title="Select CIF file", flags=c4d.FILESELECT_LOAD,
                                          force_suffix="cif")
            if path:
                self._load(path)
            return True

        if cid == self.ID_RELOAD:
            path = self.GetString(self.ID_PATH).strip()
            if path:
                self._load(path)
            return True

        if cid == self.ID_BUILD:
            if not self._ensure_loaded():
                return True
            try:
                nx, ny, nz = self.GetInt32(self.ID_NX), self.GetInt32(self.ID_NY), self.GetInt32(self.ID_NZ)
                projected_atoms = len(self.structure.expanded_sites()) * nx * ny * nz
                if projected_atoms > 10000:
                    c4d.gui.MessageDialog(
                        f"This build would create about {projected_atoms} atoms.\n"
                        "Please reduce the supercell size (V1 safety limit: 10,000 atoms)."
                    )
                    return True
                if projected_atoms > 2500 and self.GetBool(self.ID_BONDS):
                    c4d.gui.MessageDialog(
                        f"This build would create about {projected_atoms} atoms and bond inference is expensive.\n"
                        "Reduce the supercell or disable Bonds for a lighter scene."
                    )
                    return True
                log('BUILD_START', 'cells={}x{}x{}'.format(nx, ny, nz))
                built = build_supercell(self.structure, nx, ny, nz, self._axis_value(), center=True)
                bonds = infer_bonds(built.atoms, tolerance=self.GetFloat(self.ID_BOND_TOL)) if self.GetBool(self.ID_BONDS) else []
                doc = c4d.documents.GetActiveDocument()
                build_scene(
                    doc, built, bonds, self.structure.name,
                    scene_scale=self.GetFloat(self.ID_SCENE_SCALE),
                    atom_scale=self.GetFloat(self.ID_ATOM_SCALE),
                    bond_radius_angstrom=self.GetFloat(self.ID_BOND_RADIUS),
                    make_atoms=self.GetBool(self.ID_ATOMS),
                    make_bonds=self.GetBool(self.ID_BONDS),
                    make_cell=self.GetBool(self.ID_CELL),
                )
                self.built = built
                log('BUILD_OK', 'atoms={} bonds={}'.format(len(built.atoms), len(bonds)))
                c4d.gui.MessageDialog(
                    f"Built {len(self.built.atoms)} atoms and {len(bonds)} visual bonds.\n"
                    f"Out-of-plane axis: {self.built.vacuum_axis or 'raw/none'}"
                )
            except Exception as exc:
                c4d.gui.MessageDialog("Build failed:\n" + str(exc) + "\n\nSee Console for traceback.")
                log_exception('BUILD_FAILED')
            return True

        if cid == self.ID_PAPER:
            try:
                if not self._ensure_loaded():
                    return True
                dims = [self.GetInt32(i) for i in (self.ID_NX, self.ID_NY, self.ID_NZ)]
                if len(self.structure.expanded_sites()) * dims[0] * dims[1] * dims[2] > 10000:
                    c4d.gui.MessageDialog('Reduce the supercell size (10,000 atom limit).')
                    return True
                # Use current controls; a previously built model may use another CIF/size.
                self.built = build_supercell(
                    self.structure,
                    *dims,
                    self._axis_value(), center=True,
                )
                log('PAPER_START')
                setup_paper_scene(c4d.documents.GetActiveDocument(), self.built,
                                  scene_scale=self.GetFloat(self.ID_SCENE_SCALE))
                log('PAPER_OK')
                c4d.gui.MessageDialog(
                    "Paper scene created. The current render engine is unchanged.\n"
                    "For V-Ray, keep this camera/composition or replace the native lights/materials with your preferred V-Ray equivalents."
                )
            except Exception as exc:
                c4d.gui.MessageDialog("Paper Scene failed:\n" + str(exc))
                log_exception('PAPER_FAILED')
            return True

        return True
