"""Run deterministic checks on the two supplied CIF files, without C4D."""
import os
from materials_cif import parse_cif_file, structure_summary, build_supercell, infer_bonds


def run_selftest(root=None):
    root = root or os.path.dirname(__file__)
    lines = []
    for filename, elements, axis in (
        ('PdSe2.cif', {'Pd': 2, 'Se': 4}, 'A'),
        ('MoS2.cif', {'Mo': 2, 'S': 4}, None),
    ):
        structure = parse_cif_file(os.path.join(root, 'examples', filename))
        info = structure_summary(structure)
        if info['elements'] != elements or info['expanded_atoms'] != 6:
            raise ValueError('{}: unexpected atom counts {}'.format(filename, info))
        if info['detected_vacuum_axis'] != axis:
            raise ValueError('{}: unexpected vacuum axis'.format(filename))
        built = build_supercell(structure, 1, 2, 2, 'AUTO')
        if len(built.atoms) != 24:
            raise ValueError('{}: unexpected supercell size'.format(filename))
        bonds = infer_bonds(built.atoms, tolerance=1.18)
        if not bonds or any(b.distance <= 0 for b in bonds):
            raise ValueError('{}: invalid visual bonds'.format(filename))
        lines.append('{} PASS: {} / cell, 24 / supercell, {} bonds, vacuum={}'.format(
            filename, elements, len(bonds), axis))
    return '\n'.join(lines)


if __name__ == '__main__':
    print(run_selftest())
