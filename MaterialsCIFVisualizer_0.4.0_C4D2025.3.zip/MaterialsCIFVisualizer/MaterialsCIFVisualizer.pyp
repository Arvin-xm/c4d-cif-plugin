"""Materials CIF Visualizer 0.4.0: independently loadable command entry."""
import os
import sys

# C4D's plugin loader does not guarantee this directory is on sys.path.
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
if PLUGIN_DIR not in sys.path:
    sys.path.insert(0, PLUGIN_DIR)

from mcv_diagnostics import log, log_exception, LOG_PATH
log('ENTRY', 'version=0.4.0 file={} name={}'.format(__file__, __name__))

try:
    import c4d
    from c4d import plugins, gui
    log('C4D_IMPORT_OK', 'c4d={} python={}'.format(c4d.GetC4DVersion(), sys.version))
except Exception:
    log_exception('C4D_IMPORT_FAILED')
    raise

# Existing local development ID; ownership has NOT been verified.
# Public distribution must use an ID allocated to this plugin by Maxon.
PLUGIN_ID = 1067894
PLUGIN_NAME = "Materials CIF Visualizer"


class MaterialsCIFCommand(plugins.CommandData):
    def __init__(self):
        super().__init__()
        self.dialog = None

    def _get_dialog(self):
        if self.dialog is None:
            log('UI_IMPORT_START')
            from materials_cif.ui import MaterialsCIFDialog
            self.dialog = MaterialsCIFDialog()
            log('UI_IMPORT_OK')
        return self.dialog

    def Execute(self, doc):
        try:
            ok = self._get_dialog().Open(
                dlgtype=c4d.DLG_TYPE_ASYNC, pluginid=PLUGIN_ID,
                defaultw=760, defaulth=600)
            log('DIALOG_OPEN', 'ok={}'.format(ok))
            return bool(ok)
        except Exception as exc:
            log_exception('DIALOG_FAILED')
            gui.MessageDialog('Materials CIF Visualizer could not open:\n{}\n\nLog: {}'.format(exc, LOG_PATH))
            return False

    def RestoreLayout(self, sec_ref):
        try:
            return self._get_dialog().Restore(pluginid=PLUGIN_ID, secret=sec_ref)
        except Exception:
            log_exception('RESTORE_FAILED')
            return False

    def GetState(self, doc):
        return c4d.CMD_ENABLED


if __name__ == '__main__':
    try:
        existing = plugins.FindPlugin(PLUGIN_ID, c4d.PLUGINTYPE_ANY)
        if existing is not None:
            raise RuntimeError('Plugin ID {} is already registered by {!r}; remove duplicate copies or assign a Maxon-issued ID.'.format(
                PLUGIN_ID, existing.GetName()))
        log('REGISTER_START', 'id={}'.format(PLUGIN_ID))
        ok = plugins.RegisterCommandPlugin(
            id=PLUGIN_ID, str=PLUGIN_NAME, info=0, icon=None,
            help='Import CIF crystal structures and build editable atom models.',
            dat=MaterialsCIFCommand())
        if not ok:
            raise RuntimeError('RegisterCommandPlugin returned False (ID={})'.format(PLUGIN_ID))
        log('REGISTER_OK', 'id={} log={}'.format(PLUGIN_ID, LOG_PATH))
    except Exception:
        log_exception('REGISTER_FAILED')
        raise
