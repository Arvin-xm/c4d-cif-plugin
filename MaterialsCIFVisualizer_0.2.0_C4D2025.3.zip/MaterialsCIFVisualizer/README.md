# Materials CIF Visualizer 0.2.0 — C4D 2025.3 修复版

适用目标：Windows 11、Cinema 4D 2025.3.0、已安装的 V-Ray for Cinema 4D。

本版本补齐原包缺失的资源结构，修复复选框调用，将最小命令注册与 CIF/建模模块导入分开，并增加持久日志。实际 C4D 菜单加载、窗口和 V-Ray 渲染仍待你在主程序中验证；本轮 c4dpy 辅助进程崩溃，未产生原生 API 测试结果。

## 安装（推荐）

1. 保存场景，关闭 Cinema 4D。不要运行 c4dpy。
2. 将整个新 zip 解压到普通文件夹，例如桌面 `MCV_0.2.0`。双击包根目录的 `Install.cmd`。
3. 看到 `Installation completed` 后启动 C4D，在“扩展”中打开 **Materials CIF Visualizer**。

安装程序固定使用日志已确认扫描的路径：

```text
E:\C4D_Plugins\MaterialsCIFVisualizer\
├── MaterialsCIFVisualizer.pyp
├── mcv_diagnostics.py
├── mcv_selftest.py
├── materials_cif\
├── examples\PdSe2.cif
├── examples\MoS2.cif
└── res\
    ├── c4d_symbols.h
    ├── strings_en-US\c4d_strings.str
    └── strings_zh-CN\c4d_strings.str
```

无需重新添加 `E:\C4D_Plugins` 搜索路径，也不要把入口改成 `.py`。

你电脑上已找到两处会被扫描的旧副本：上面的 E 盘路径，以及
`%APPDATA%\Maxon\Maxon Cinema 4D 2025_B76FCBE4\plugins\MaterialsCIFVisualizer`。
安装程序会先校验包、将两份旧目录移至 `Documents\Codex\MaterialsCIFVisualizer_Backups\时间戳`，再放入一份新版；备份保留完整原文件。失败时尝试还原旧目录。安装程序在 C4D 运行时会退出，不会结束你的 C4D 进程。无须管理员运行。

`Install.cmd` 只对本次 PowerShell 进程设置脚本执行参数，不修改系统执行策略。如果安装报错，请回传窗口中的错误文字。不要在 C4D 扫描目录内保存旧插件备份。

## 验证（一次即可）

打开窗口后点 **Self-test**，应显示两行 PASS：

- PdSe2：每晶胞 2 Pd + 4 Se；1×2×2 超胞 24 原子、29 条视觉键；自动真空轴 A。
- MoS2：每晶胞 2 Mo + 4 S；1×2×2 超胞 24 原子、28 条视觉键；自动真空轴 None。

Self-test 在 C4D 的 Python 中运行解析与超胞测试，不修改场景。然后点 **Browse…** 选择桌面的任一 CIF，保持 1×1×1，点 **BUILD MODEL**。应生成 `MCV_...` 根对象、ATOMS 和 BONDS 分组，ATOMS 中有 6 个球体。用第二个 CIF 再点 BUILD MODEL 时会创建另一个根对象。

`Paper Scene` 可选，会加入正交相机和原生灯光，设置 3000×3000 与 Alpha。它使用当前 CIF/超胞设置，不会切换渲染器。球体和圆柱是原生可编辑参数对象，材质为标准 C4D 材质；没有创建 V-Ray 专属节点材质。V-Ray 的材质、灯光转换与最终渲染效果尚未实测。

## 如果仍异常，只需回传一份文件

双击 zip 解压目录的 `CollectLogs.cmd`，回传同目录生成的 **MCV_diagnostics.txt**。它只收集本插件两处目录的文件列表、入口哈希、C4D 进程信息和插件日志末尾 300 行。

日志也可直接找到：`%TEMP%\MaterialsCIFVisualizer.log`，本机通常为
`C:\Users\wangy\AppData\Local\Temp\MaterialsCIFVisualizer.log`。

正常阶段依次包括 `ENTRY`、`C4D_IMPORT_OK`、`REGISTER_OK`；打开窗口后有 `UI_IMPORT_OK`、`LAYOUT_OK`、`INIT_VALUES_OK`；解析和建模后有 `CIF_LOAD_OK`、`BUILD_OK`。日志包含版本、实际入口路径、进程 ID 和失败 traceback。

如果诊断文件显示 **No log exists** 且菜单仍没有插件，再补发 C4D 的 Python 控制台启动错误文字；只有这一种情况需要额外日志。普通模块扫描日志没有插件名，并不能单独证明入口没有执行。

## 功能与测试范围

CIF 解析无 NumPy、ASE、pymatgen、gemmi 或 V-Ray Python 模块依赖。支持分数坐标、带氧化态的元素名、显式空间群操作展开与去重、非正交晶胞、超胞、真空轴对齐和薄层重组。视觉键使用有限超胞内的共价半径阈值，不代表化学键级，也不会连接超胞外的周期镜像。

本包原样包含你桌面提供的两个 CIF，SHA256 已匹配。9 项解析/几何回归通过；11 项使用本机 SDK 参数定义的离线检查通过。这些检查不等同于 C4D 原生加载或 V-Ray 渲染测试。

原插件 ID `1067894` 为已有开发用 ID，未核验 Maxon 所有权。新版不随机更换 ID；如果被其他插件占用，会明确报告对方名称。正式对外发布前必须申请属于本插件的唯一 ID，并同步更新入口。

可在普通 Python 中复现解析测试：

```text
python -m unittest discover -s tests -v
python mcv_selftest.py
```

参考：[Maxon 2025.3 插件结构](https://developers.maxon.net/docs/py/2025_3_0/misc/pluginstructure.html)、[GeDialog API](https://developers.maxon.net/docs/py/2025_3_0/modules/c4d.gui/GeDialog/index.html)、[CommandData API](https://developers.maxon.net/docs/py/2025_3_0/modules/c4d.plugins/BaseData/CommandData/index.html)。
