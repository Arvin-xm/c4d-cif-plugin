"""Visual bond inference for generated crystal structures."""
from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict
from itertools import combinations_with_replacement, product
import math

from .cif_parser import CartesianAtom
from .elements import COVALENT_RADII, DEFAULT_COVALENT_RADIUS


@dataclass(frozen=True)
class Bond:
    i: int
    j: int
    distance: float


def default_cutoff(pair, tolerance=1.18):
    return sum(COVALENT_RADII.get(e, DEFAULT_COVALENT_RADIUS) for e in pair) * tolerance


def infer_bonds(atoms, tolerance=1.15, min_distance=0.35, pair_overrides=None,
                max_distance=None, allowed_pairs=None, excluded_pairs=None,
                max_bonds=30000, stats=None):
    """Spatial bins find each contact once, across internal cell boundaries too.

    Pairs are unordered. allowed_pairs=None means all; an empty set means none.
    Overrides are inclusive (min, max) Angstrom ranges, independent of ball size.
    No wrapping/phantom endpoints outside the finite generated supercell.
    These are distance contacts, not chemical bond orders.
    """
    if not math.isfinite(tolerance) or tolerance <= 0:
        raise ValueError('Bond tolerance must be finite and positive.')
    if not math.isfinite(min_distance) or min_distance < 0:
        raise ValueError('Minimum bond distance must be finite and nonnegative.')
    if max_distance is not None and (not math.isfinite(max_distance) or max_distance <= 0):
        raise ValueError('Maximum bond distance must be finite and positive.')
    overrides = {tuple(sorted(k)): v for k, v in (pair_overrides or {}).items()}
    allowed = None if allowed_pairs is None else {tuple(sorted(p)) for p in allowed_pairs}
    excluded = {tuple(sorted(p)) for p in (excluded_pairs or ())}
    limits = {}
    elements = sorted({a.element for a in atoms})
    for pair in combinations_with_replacement(elements, 2):
        if pair in excluded or (allowed is not None and pair not in allowed):
            continue
        lo, hi = overrides.get(pair, (min_distance, default_cutoff(pair, tolerance)))
        if not all(math.isfinite(v) for v in (lo, hi)) or lo < 0 or hi < lo:
            raise ValueError('Invalid bond range for {}-{}.'.format(*pair))
        lo = max(lo, min_distance)
        hi = min(hi, max_distance) if max_distance is not None else hi
        if hi > 0 and hi >= lo:
            limits[pair] = (lo * lo, hi * hi, hi)
    if stats is not None:
        stats.update(distance_checks=0, atoms=len(atoms), bonds=0)
    if not limits:
        return []
    size = max(v[2] for v in limits.values())
    bins = defaultdict(list)
    out, checks = [], 0
    offsets = tuple(product((-1, 0, 1), repeat=3))
    for j, atom in enumerate(atoms):
        p = atom.position
        if not all(math.isfinite(v) for v in p):
            raise ValueError('Atom coordinates must be finite.')
        cell = tuple(math.floor(v / size) for v in p)
        for offset in offsets:
            neighbor = tuple(cell[k] + offset[k] for k in range(3))
            for i in bins.get(neighbor, ()):
                other = atoms[i]
                limit = limits.get(tuple(sorted((atom.element, other.element))))
                if limit is None:
                    continue
                checks += 1
                if checks > 5000000:
                    raise ValueError('Bond search is too dense. Reduce distances or supercell size.')
                d2 = sum((p[k] - other.position[k]) ** 2 for k in range(3))
                if limit[0] <= d2 <= limit[1] and d2 > 1e-18:
                    out.append(Bond(i, j, math.sqrt(d2)))
                    if len(out) > max_bonds:
                        raise ValueError('More than {} visual bonds. Reduce ranges or supercell size.'.format(max_bonds))
        bins[cell].append(j)
    out.sort(key=lambda b: (b.i, b.j))
    if stats is not None:
        stats.update(distance_checks=checks, bonds=len(out))
    return out


def bond_report(atoms, bonds):
    distances = defaultdict(list)
    for bond in bonds:
        pair = tuple(sorted((atoms[bond.i].element, atoms[bond.j].element)))
        distances[pair].append(bond.distance)
    lines = ['Visual distance contacts: {} total'.format(len(bonds))]
    for pair, ds in sorted(distances.items()):
        lines.append('{}-{}: {} bonds, {:.4f} - {:.4f} A'.format(*pair, len(ds), min(ds), max(ds)))
    lines.append('Finite supercell only; no chemical bond order or automatic valence assignment.')
    return '\n'.join(lines)
