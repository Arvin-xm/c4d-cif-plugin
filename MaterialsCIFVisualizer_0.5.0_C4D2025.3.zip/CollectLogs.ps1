$ErrorActionPreference = 'Continue'
function Get-MCVSHA256([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}
$reportPath = Join-Path $PSScriptRoot 'MCV_diagnostics.txt'
$pluginPaths = @(
    'E:\C4D_Plugins\MaterialsCIFVisualizer',
    (Join-Path $env:APPDATA 'Maxon\Maxon Cinema 4D 2025_B76FCBE4\plugins\MaterialsCIFVisualizer')
)
$lines = @('MaterialsCIFVisualizer diagnostics', ('Time: ' + (Get-Date -Format o)))
$lines += 'This report reads only this plugin, its log, and Cinema 4D process metadata.'
foreach ($path in $pluginPaths) {
    $lines += ''; $lines += ('Directory: ' + $path)
    if (Test-Path -LiteralPath $path) {
        $lines += @(Get-ChildItem -LiteralPath $path -Recurse -File | Where-Object { $_.Extension -ne '.pyc' } | ForEach-Object {
            '{0} bytes={1}' -f $_.FullName, $_.Length
        })
        $entry = Join-Path $path 'MaterialsCIFVisualizer.pyp'
        if (Test-Path -LiteralPath $entry) { $lines += ('Entry SHA256: ' + (Get-MCVSHA256 $entry)) }
    } else { $lines += 'Not present.' }
}
$lines += ''; $lines += 'Cinema 4D processes:'
$lines += @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -in @('Cinema 4D','c4dpy') } | ForEach-Object { '{0} PID={1} Path={2}' -f $_.ProcessName, $_.Id, $_.Path })
$logPath = Join-Path ([IO.Path]::GetTempPath()) 'MaterialsCIFVisualizer.log'
$lines += ''; $lines += ('Plugin log: ' + $logPath)
if (Test-Path -LiteralPath $logPath) { $lines += @(Get-Content -LiteralPath $logPath -Tail 300) }
else { $lines += 'No log exists: the entry point may not have been executed.' }
$lines | Set-Content -LiteralPath $reportPath -Encoding UTF8
Write-Host "Report saved: $reportPath"
