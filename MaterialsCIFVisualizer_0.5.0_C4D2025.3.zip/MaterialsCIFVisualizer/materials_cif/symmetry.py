"""Exact affine symmetry validation and setting-aware Gemmi-derived lookup."""
import ast
from fractions import Fraction
from functools import lru_cache
import json
import os

from .cif_document import CIFError


def _affine(node):
    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return (Fraction(0), Fraction(0), Fraction(0), Fraction(str(node.value)))
    if isinstance(node, ast.Name) and node.id in ('x', 'y', 'z'):
        return tuple(Fraction(int(i == 'xyz'.index(node.id))) for i in range(4))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        values = _affine(node.operand)
        return tuple(-v for v in values) if isinstance(node.op, ast.USub) else values
    if isinstance(node, ast.BinOp):
        a, b = _affine(node.left), _affine(node.right)
        if isinstance(node.op, ast.Add): return tuple(x+y for x, y in zip(a, b))
        if isinstance(node.op, ast.Sub): return tuple(x-y for x, y in zip(a, b))
        if isinstance(node.op, ast.Mult):
            if not any(a[:3]): return tuple(a[3]*v for v in b)
            if not any(b[:3]): return tuple(b[3]*v for v in a)
        if isinstance(node.op, ast.Div) and not any(b[:3]) and b[3] != 0:
            return tuple(v/b[3] for v in a)
    raise CIFError('Symmetry expressions must be linear in x, y, z with numeric translations.')


def determinant(m):
    a, b, c = m
    return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])


@lru_cache(maxsize=4096)
def compile_op(text):
    if len(text) > 192:
        raise CIFError('Symmetry operation is too long.')
    parts = text.lower().strip().split(',')
    if len(parts) != 3:
        raise CIFError('Symmetry operation must have three components: ' + text)
    try:
        rows = [_affine(ast.parse(p.strip(), mode='eval').body) for p in parts]
    except (SyntaxError, ValueError, ZeroDivisionError, OverflowError, RecursionError) as exc:
        raise CIFError('Invalid symmetry operation: ' + text) from exc
    if any(v.denominator != 1 or abs(v) > 6 for row in rows for v in row[:3]):
        raise CIFError('Symmetry rotations must use small integer coefficients: ' + text)
    matrix = tuple(tuple(int(v) for v in row[:3]) for row in rows)
    if abs(determinant(matrix)) != 1:
        raise CIFError('Singular/non-crystallographic symmetry operation: ' + text)
    translation = tuple(row[3] % 1 for row in rows)
    return matrix, translation


def compose(a, b):
    ma, ta = a
    mb, tb = b
    return (tuple(tuple(sum(ma[i][k]*mb[k][j] for k in range(3)) for j in range(3)) for i in range(3)),
            tuple((sum(ma[i][k]*tb[k] for k in range(3))+ta[i]) % 1 for i in range(3)))


@lru_cache(maxsize=128)
def validate_ops(operations):
    if not operations or len(operations) > 384:
        raise CIFError('Expected 1 to 384 ordinary 3D symmetry operations.')
    group = frozenset(compile_op(op) for op in operations)
    identity = compile_op('x,y,z')
    if identity not in group:
        raise CIFError('Symmetry operations are missing the identity x,y,z.')
    # Generate closure using only generators needed so far. This validates
    # complete groups without all n*n pair compositions for high-symmetry cells.
    generated = {identity}
    generators = []
    for candidate in group:
        if candidate in generated:
            continue
        generators.append(candidate)
        queue = list(generated)
        while queue:
            value = queue.pop()
            for generator in generators:
                new = compose(value, generator)
                if new not in group:
                    raise CIFError('Incomplete/inconsistent symmetry operation list (not a closed group).')
                if new not in generated:
                    generated.add(new)
                    queue.append(new)
    return group


@lru_cache(maxsize=1)
def table():
    path = os.path.join(os.path.dirname(__file__), 'spacegroups.json')
    with open(path, 'r', encoding='utf-8') as stream:
        return json.load(stream)['settings']


def hm_key(value):
    return ''.join(value.lower().replace('_', '').split())


def candidates(hm='', hall='', number=None, setting=''):
    entries = table()
    if hall:
        key = ' '.join(hall.split())
        selected = [e for e in entries if ' '.join(e['hall'].split()) == key]
    elif hm:
        key = hm_key(hm)
        selected = [e for e in entries if key in [hm_key(n) for n in e['aliases']]]
    elif number is not None:
        selected = [e for e in entries if e['number'] == number]
    else:
        return []
    if number is not None and selected:
        selected = [e for e in selected if e['number'] == number]
        if not selected:
            raise CIFError('Space-group name/Hall symbol conflicts with the IT number.')
    if hm and hall and selected:
        matches = [e for e in entries if hm_key(hm) in [hm_key(n) for n in e['aliases']]]
        if matches and selected[0]['number'] not in {e['number'] for e in matches}:
            raise CIFError('Hall and H-M symbols describe different space groups.')
    if setting and selected:
        selected = [e for e in selected if setting.lower() in (e['ext'].lower(), e['qualifier'].lower())]
    return selected


def resolve(operations, hm='', hall='', number=None, setting=''):
    found = candidates(hm, hall, number, setting)
    notes = []
    if operations:
        operations = list(dict.fromkeys(op.strip() for op in operations))
        actual = validate_ops(tuple(operations))
        if found and not any(actual == frozenset(compile_op(op) for op in e['operations']) for e in found):
            raise CIFError('Explicit operations conflict with the declared space group/setting. Re-export with a consistent setting, or as P1 with all atoms.')
        if (hm or hall or number is not None) and not found:
            notes.append('Space-group setting is not in the bundled table; validated explicit operations are used.')
        if not (hm or hall or number is not None):
            notes.append('No space-group name is declared; explicit operations are used.')
        return operations, 'explicit CIF operations', notes
    if not found:
        raise CIFError('No usable symmetry operations or recognized space-group setting. Export explicit operations (or a full P1 cell).')
    unique = {}
    for entry in found:
        key = frozenset(compile_op(op) for op in entry['operations'])
        unique.setdefault(key, entry)
    if len(unique) != 1:
        examples = ', '.join(e['xhm'] for e in list(unique.values())[:8])
        raise CIFError('Ambiguous space-group setting: {}. Supply explicit operations, a Hall symbol, or an origin/axis setting.'.format(examples))
    entry = next(iter(unique.values()))
    notes.append('Missing operations were supplied from the Gemmi 0.7.5 table: ' + entry['xhm'])
    return entry['operations'], 'Gemmi table: ' + entry['xhm'], notes
