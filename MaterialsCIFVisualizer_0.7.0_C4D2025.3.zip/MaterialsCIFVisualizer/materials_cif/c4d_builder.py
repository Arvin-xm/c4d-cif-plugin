"""Cinema 4D scene builder for Materials CIF Visualizer.

This module is imported only inside Cinema 4D. The core CIF parser remains
independent so it can be tested with normal CPython.
"""
from __future__ import annotations

import math
import json
import uuid
from typing import Dict, List, Optional, Sequence, Tuple

import c4d
from c4d import utils

from .cif_parser import BuiltStructure, CartesianAtom
from .bonds import Bond
from .elements import ELEMENT_COLORS, VISUAL_RADII, DEFAULT_COLOR, DEFAULT_VISUAL_RADIUS


Vec3 = Tuple[float, float, float]
RIG_MARKER_ID = 1067894
RIG_MARKER = 'MaterialsCIFVisualizer.paper.040'
MODEL_MARKER = 'MaterialsCIFVisualizer.model.060'
GROUP_MARKER = 'MaterialsCIFVisualizer.geometry.060'


def model_root(doc, obj):
    """Only persisted plugin ownership marks authorize a model update."""
    while obj is not None:
        if obj.GetDocument() != doc:
            return None
        if obj.GetDataInstance()[RIG_MARKER_ID] == MODEL_MARKER:
            return obj
        obj = obj.GetUp()
    return None


def _cv(v: Vec3) -> c4d.Vector:
    return c4d.Vector(float(v[0]), float(v[1]), float(v[2]))


def _sub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]-b[0], a[1]-b[1], a[2]-b[2])


def _add(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]+b[0], a[1]+b[1], a[2]+b[2])


def _mul(a: Vec3, s: float) -> Vec3:
    return (a[0]*s, a[1]*s, a[2]*s)


def _dot(a: Vec3, b: Vec3) -> float:
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def _cross(a: Vec3, b: Vec3) -> Vec3:
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _norm(a: Vec3) -> float:
    return math.sqrt(_dot(a, a))


def _unit(a: Vec3) -> Vec3:
    n = _norm(a)
    if n < 1e-12:
        return (0.0, 1.0, 0.0)
    return _mul(a, 1.0/n)


def _material(doc, name, rgb, renderer='native', staged=None, owner=''):
    # Per-build sharing: editing a new palette must not recolor earlier models.
    signature = json.dumps([owner,name,renderer,list(rgb)],sort_keys=True)
    if staged is not None and owner:
        previous = doc.GetFirstMaterial()
        while previous is not None:
            if previous.GetDataInstance()[RIG_MARKER_ID] == signature:
                return previous
            previous = previous.GetNext()
    if renderer == 'vray':
        from .vray_adapter import create_material
        mat = create_material(rgb)
    else:
        mat = c4d.BaseMaterial(c4d.Mmaterial)
        mat[c4d.MATERIAL_USE_COLOR] = True
        mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(*rgb)
        mat[c4d.MATERIAL_USE_REFLECTION] = False
    mat.SetName('MCV_' + name + ('_Vray' if renderer == 'vray' else ''))
    mat.GetDataInstance()[RIG_MARKER_ID] = signature
    if staged is None:
        doc.InsertMaterial(mat)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, mat)
    else:
        staged.append(mat)
    return mat


def _assign_material(obj: c4d.BaseObject, mat: c4d.BaseMaterial) -> None:
    tag = c4d.TextureTag()
    tag.SetMaterial(mat)
    obj.InsertTag(tag)


def _smooth(obj, angle_limit=False):
    tag = c4d.BaseTag(c4d.Tphong)
    tag[c4d.PHONGTAG_PHONG_ANGLELIMIT] = angle_limit
    tag[c4d.PHONGTAG_PHONG_ANGLE] = math.radians(40.0)
    obj.InsertTag(tag)


def _display_color(obj, rgb):
    obj[c4d.ID_BASEOBJECT_USECOLOR] = c4d.ID_BASEOBJECT_USECOLOR_ALWAYS
    obj[c4d.ID_BASEOBJECT_COLOR] = _cv(rgb)


def _make_cylinder(name: str, p1: Vec3, p2: Vec3, radius: float,
                   segments: int = 24) -> Optional[c4d.BaseObject]:
    delta = _sub(p2, p1)
    length = _norm(delta)
    if length < 1e-9:
        return None
    yaxis = _unit(delta)
    helper = (1.0, 0.0, 0.0) if abs(yaxis[0]) < 0.85 else (0.0, 0.0, 1.0)
    xaxis = _unit(_cross(helper, yaxis))
    zaxis = _unit(_cross(xaxis, yaxis))
    mid = _mul(_add(p1, p2), 0.5)

    obj = c4d.BaseObject(c4d.Ocylinder)
    obj.SetName(name)
    obj[c4d.PRIM_CYLINDER_RADIUS] = radius
    obj[c4d.PRIM_CYLINDER_HEIGHT] = length
    if hasattr(c4d, "PRIM_CYLINDER_SEG"):
        obj[c4d.PRIM_CYLINDER_SEG] = segments
    if hasattr(c4d, "PRIM_CYLINDER_CAPS"):
        obj[c4d.PRIM_CYLINDER_CAPS] = True
    obj.SetMg(c4d.Matrix(_cv(mid), _cv(xaxis), _cv(yaxis), _cv(zaxis)))
    _smooth(obj, angle_limit=True)
    return obj


def _group(name: str, parent: c4d.BaseObject) -> c4d.BaseObject:
    g = c4d.BaseObject(c4d.Onull)
    g.SetName(name)
    g.InsertUnder(parent)
    return g


def build_scene(doc: c4d.documents.BaseDocument,
                built: BuiltStructure,
                bonds: Sequence[Bond],
                name: str,
                scene_scale: float = 20.0,
                atom_scale: float = 0.70,
                bond_radius_angstrom: float = 0.08,
                make_atoms: bool = True,
                make_bonds: bool = True,
                make_cell: bool = False, sphere_segments=64,
                instance_mode='render', element_styles=None,
                renderer='native', target=None) -> c4d.BaseObject:
    """Stage geometry first; commit one undo transaction, preserving target root.

    Hand-added root children and the root's tags/name/transform survive updates.
    Generated groups are regenerated. Old palette materials are retained since
    users can share them elsewhere; identical settings reuse owned materials.
    """
    if target is not None and model_root(doc,target) != target:
        raise ValueError('请选择 0.6.0 生成的模型根对象或其子对象。旧版模型请先新建。')
    if instance_mode not in ('render', 'standard', 'off'):
        raise ValueError('Unknown atom instance mode.')
    if renderer not in ('native', 'vray'):
        raise ValueError('Unknown material renderer.')
    sphere_segments = max(16, min(128, int(sphere_segments)))
    styles = element_styles or {}
    if renderer == 'vray':
        from .vray_adapter import preflight
        preflight()
    staged_materials = []
    owner = target.GetDataInstance()[RIG_MARKER_ID+1] if target is not None else str(uuid.uuid4())
    if not owner:
        raise ValueError('模型所有权标记损坏，请新建模型。')
    try:
        root = c4d.BaseObject(c4d.Onull)
        root.SetName("MCV_" + (name or "Structure"))
        root.GetDataInstance()[RIG_MARKER_ID] = MODEL_MARKER
        root.GetDataInstance()[RIG_MARKER_ID+1] = owner

        atoms_g = _group("ATOMS", root)
        bonds_g = _group("BONDS", root)
        cell_g = _group("UNIT_CELL", root)
        for group in (atoms_g,bonds_g,cell_g):
            group.GetDataInstance()[RIG_MARKER_ID] = GROUP_MARKER
        materials: Dict[str, c4d.BaseMaterial] = {}

        def style(element):
            custom = styles.get(element, {})
            return (custom.get('color', ELEMENT_COLORS.get(element, DEFAULT_COLOR)),
                    custom.get('radius', VISUAL_RADII.get(element, DEFAULT_VISUAL_RADIUS)))

        def material(element):
            if element not in materials:
                materials[element] = _material(doc, element, style(element)[0], renderer, staged_materials, owner)
            return materials[element]

        if make_atoms:
            sources = {}
            for idx, atom in enumerate(built.atoms):
                rgb, visual_radius = style(atom.element)
                if instance_mode != 'off' and atom.element in sources:
                    sphere = c4d.BaseObject(c4d.Oinstance)
                    sphere[c4d.INSTANCEOBJECT_LINK] = sources[atom.element]
                    sphere[c4d.INSTANCEOBJECT_RENDERINSTANCE_MODE] = (
                        c4d.INSTANCEOBJECT_RENDERINSTANCE_MODE_SINGLEINSTANCE
                        if instance_mode == 'render' else c4d.INSTANCEOBJECT_RENDERINSTANCE_MODE_NONE)
                    sphere.SetName(f'{atom.element}_{idx:04d}_instance')
                else:
                    sphere = c4d.BaseObject(c4d.Osphere)
                    sphere.SetName(f'{atom.element}_{idx:04d}_source')
                    sphere[c4d.PRIM_SPHERE_RAD] = visual_radius * atom_scale * scene_scale
                    sphere[c4d.PRIM_SPHERE_SUB] = sphere_segments
                    sphere[c4d.PRIM_SPHERE_TYPE] = c4d.PRIM_SPHERE_TYPE_STANDARD
                    _smooth(sphere)
                    sources[atom.element] = sphere
                if atom.periodic_image != (0,0,0):
                    sphere.SetName(sphere.GetName()+'_PERIODIC')
                sphere.SetRelPos(_cv(_mul(atom.position, scene_scale)))
                sphere.InsertUnder(atoms_g)
                _assign_material(sphere, material(atom.element))
                _display_color(sphere, rgb)

        if make_bonds and bonds:
            rr = bond_radius_angstrom * scene_scale
            for k, bond in enumerate(bonds):
                p1 = _mul(built.atoms[bond.i].position, scene_scale)
                p2 = _mul(built.atoms[bond.j].position, scene_scale)
                a, b = built.atoms[bond.i].element, built.atoms[bond.j].element
                midpoint = _mul(_add(p1, p2), 0.5)
                # Same-element contacts need one cylinder; others meet exactly at midpoint.
                pieces = [(p1, p2, a)] if a == b else [(p1, midpoint, a), (midpoint, p2, b)]
                for half, (start, end, element) in enumerate(pieces):
                    cyl = _make_cylinder(f'Bond_{k:05d}_{half}_{element}', start, end, rr)
                    if cyl is not None:
                        cyl.InsertUnder(bonds_g)
                        _assign_material(cyl, material(element))
                        _display_color(cyl, style(element)[0])

        if make_cell:
            cell_mat = _material(doc, "UnitCell", (0.30, 0.34, 0.38), renderer, staged_materials, owner)
            o = _mul(built.center_shift, scene_scale)
            a = _mul(built.cell_vectors[0], scene_scale)
            b = _mul(built.cell_vectors[1], scene_scale)
            c = _mul(built.cell_vectors[2], scene_scale)
            corners = [
                o, _add(o,a), _add(o,b), _add(o,c),
                _add(_add(o,a),b), _add(_add(o,a),c), _add(_add(o,b),c),
                _add(_add(_add(o,a),b),c),
            ]
            edges = [(0,1),(0,2),(0,3),(1,4),(1,5),(2,4),(2,6),(3,5),(3,6),(4,7),(5,7),(6,7)]
            rr = max(scene_scale * 0.025, 0.5)
            for k,(i,j) in enumerate(edges):
                cyl = _make_cylinder(f"CellEdge_{k:02d}", corners[i], corners[j], rr, 10)
                if cyl:
                    cyl.InsertUnder(cell_g)
                    _assign_material(cyl, cell_mat)

        # Hide empty organizational groups when their feature is disabled.
        if not make_atoms:
            atoms_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            atoms_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF
        if not make_bonds:
            bonds_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            bonds_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF
        if not make_cell:
            cell_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            cell_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF

        # No document mutation above: allocation/parameter failures keep the
        # existing model and materials intact. Undo is opened only at commit.
        if doc.StartUndo() is False:
            raise RuntimeError('无法开始撤销事务；模型未改变。')
        def record_new(node):
            if doc.AddUndo(c4d.UNDOTYPE_NEWOBJ,node) is False:
                node.Remove()
                raise RuntimeError('无法记录撤销；已取消更新。')
        try:
            for mat in staged_materials:
                doc.InsertMaterial(mat)
                record_new(mat)
            if target is None:
                doc.InsertObject(root)
                record_new(root)
                target = root
            else:
                for old in list(target.GetChildren()):
                    if old.GetDataInstance()[RIG_MARKER_ID] == GROUP_MARKER:
                        if doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, old) is False:
                            raise RuntimeError('无法记录旧模型撤销；已取消更新。')
                        old.Remove()
                for group in (atoms_g,bonds_g,cell_g):
                    group.Remove()
                    doc.InsertObject(group,parent=target)
                    record_new(group)
            doc.SetActiveObject(target,c4d.SELECTION_NEW)
        except Exception:
            has_undo = doc.GetUndoPtr() is not None
            doc.EndUndo()
            if has_undo:
                doc.DoUndo()
            c4d.EventAdd()
            raise
        else:
            doc.EndUndo()
        c4d.EventAdd()
        return target
    except Exception:
        # Detached staging objects are released; a native commit error remains
        # a single undo transaction so the user can restore the previous model.
        raise


def _look_at(obj: c4d.BaseObject, target: c4d.Vector) -> None:
    direction = target - obj.GetAbsPos()
    obj.SetAbsRot(utils.VectorToHPB(direction))


def setup_paper_scene(doc: c4d.documents.BaseDocument,
                      built: BuiltStructure,
                      scene_scale=20.0, renderer='native',
                      output_path=None, resolution=3000,
                      atom_margin_angstrom=2.0, include_cell=False,
                      yaw=35.0, pitch=40.0, padding=.12,
                      light_multiplier=1.0, softness=1.25,
                      background='transparent', model_transform=None):
    """Stage a fitted camera, neutral soft lights and explicit background.

    View frame is shared with the preview; C4D camera +Z points toward target.
    Model root transforms participate in bounds and light/camera placement.
    Only previously marked plugin rigs are replaced. No ground plane is added.
    """
    from .view_math import paper_layout
    from .vray_adapter import BACKGROUNDS
    if not built.atoms:
        return
    if background not in BACKGROUNDS:
        raise ValueError('Unknown background mode.')
    if not all(math.isfinite(x) and x>0 for x in (light_multiplier,softness)):
        raise ValueError('灯光倍率和柔光程度必须为正数。')
    layout=paper_layout(built,scene_scale,atom_margin_angstrom,include_cell,
                        yaw,pitch,padding,model_transform)
    if renderer == 'vray':
        from .vray_adapter import preflight,create_light,enable_renderer,create_environment,render_values
        preflight(lights=True,background=background)
        # Validate the existing renderer before replacing a rig.
        post=doc.GetActiveRenderData().GetFirstVideoPost()
        while post is not None and post.GetType()!=1053272:
            post=post.GetNext()
        if post is not None:
            for pid,value in render_values(background):
                if post[pid] is None:
                    raise RuntimeError('V-Ray render parameter {} is unavailable.'.format(pid))
    elif renderer != 'native':
        raise ValueError('Unknown renderer.')

    target,frame,field=layout['target'],layout['frame'],layout['field']
    def in_frame(offset):
        return tuple(target[k]+field*sum(offset[j]*frame[j][k] for j in range(3)) for k in range(3))
    def aim(obj,position):
        z=_unit(_sub(target,position))
        hint=frame[1]
        if abs(_dot(hint,z))>.98: hint=frame[0]
        x=_unit(_cross(hint,z)); y=_unit(_cross(z,x))
        obj.SetMg(c4d.Matrix(_cv(position),_cv(x),_cv(y),_cv(z)))
    rig=c4d.BaseObject(c4d.Onull)
    rig.SetName('MCV_PAPER_SCENE')
    rig.GetDataInstance()[RIG_MARKER_ID]=RIG_MARKER
    cam=c4d.BaseObject(c4d.Ocamera)
    cam.SetName('MCV_Camera_Orthographic')
    cam[c4d.CAMERA_PROJECTION]=c4d.Pparallel
    cam[c4d.CAMERA_ZOOM]=layout['zoom']
    cam[c4d.CAMERAOBJECT_TARGETDISTANCE]=_norm(_sub(target,layout['eye']))
    cam.SetMg(c4d.Matrix(_cv(layout['eye']),*[_cv(v) for v in frame]))
    cam.InsertUnder(rig)

    for name,offset,size,power,shadow in (
        ('MCV_Key_Area',(-.65,.85,-1.15),.70,4.0,True),
        ('MCV_Fill_Area',(.85,.25,-.85),.90,2.0,False),
        ('MCV_Rim_Area',(.20,.65,.90),.60,1.5,False)):
        light=(create_light(field*size*softness,power*light_multiplier,(1.,1.,1.),shadows=shadow)
               if renderer=='vray' else c4d.BaseObject(c4d.Olight))
        light.SetName(name)
        if renderer!='vray':
            light[c4d.LIGHT_TYPE]=c4d.LIGHT_TYPE_AREA
            light[c4d.LIGHT_BRIGHTNESS]=power*.20*light_multiplier
            light[c4d.LIGHT_COLOR]=c4d.Vector(1.,1.,1.)
            light[c4d.LIGHT_SHADOWTYPE]=c4d.LIGHT_SHADOWTYPE_AREA if shadow else c4d.LIGHT_SHADOWTYPE_NONE
            light[c4d.LIGHT_AREADETAILS_SIZEX]=field*size*softness
            light[c4d.LIGHT_AREADETAILS_SIZEY]=field*size*softness
        aim(light,in_frame(offset))
        light.InsertUnder(rig)

    environment=None
    bg_material=None
    if renderer=='vray':
        environment=create_environment(background)
        environment.SetName('MCV_Environment_'+background)
        environment.InsertUnder(rig)
    elif background!='transparent':
        bg_material=c4d.BaseMaterial(c4d.Mmaterial)
        bg_material.SetName('MCV_Background_'+background)
        bg_material[c4d.MATERIAL_USE_COLOR]=False
        bg_material[c4d.MATERIAL_USE_REFLECTION]=False
        bg_material[c4d.MATERIAL_USE_LUMINANCE]=True
        bg_material[c4d.MATERIAL_LUMINANCE_COLOR]=c4d.Vector(*BACKGROUNDS[background])
        bg_material[c4d.MATERIAL_LUMINANCE_BRIGHTNESS]=1.
        bg=c4d.BaseObject(c4d.Obackground)
        bg.SetName('MCV_Background')
        _assign_material(bg,bg_material)
        bg.InsertUnder(rig)

    if doc.StartUndo() is False:
        raise RuntimeError('无法开始出图撤销事务。')
    try:
        previous=doc.GetFirstObject()
        while previous is not None:
            following=previous.GetNext()
            if previous.GetDataInstance()[RIG_MARKER_ID]==RIG_MARKER:
                doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ,previous)
                previous.Remove()
            previous=following
        doc.InsertObject(rig)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ,rig)
        if bg_material is not None:
            doc.InsertMaterial(bg_material)
            doc.AddUndo(c4d.UNDOTYPE_NEWOBJ,bg_material)
        rd=doc.GetActiveRenderData()
        doc.AddUndo(c4d.UNDOTYPE_CHANGE,rd)
        for pid,value in ((c4d.RDATA_XRES,resolution),(c4d.RDATA_YRES,resolution),
                          (c4d.RDATA_FILMASPECT,1.),(c4d.RDATA_PIXELASPECT,1.),
                          (c4d.RDATA_FORMAT,c4d.FILTER_PNG),(c4d.RDATA_FORMATDEPTH,c4d.RDATA_FORMATDEPTH_8),
                          (c4d.RDATA_ALPHACHANNEL,background=='transparent'),
                          (c4d.RDATA_STRAIGHTALPHA,True),(c4d.RDATA_SEPARATEALPHA,False)):
            rd[pid]=value
        if output_path:
            rd[c4d.RDATA_SAVEIMAGE]=True; rd[c4d.RDATA_PATH]=output_path
        if renderer=='vray':
            enable_renderer(doc,output_path,background,environment)
        else:
            rd[c4d.RDATA_RENDERENGINE]=c4d.RDATA_RENDERENGINE_STANDARD
        bd=doc.GetActiveBaseDraw()
        if bd is not None:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE,bd)
            bd.SetSceneCamera(cam)
    except Exception:
        has_undo=doc.GetUndoPtr() is not None
        doc.EndUndo()
        if has_undo: doc.DoUndo()
        c4d.EventAdd()
        raise
    else:
        doc.EndUndo()
    c4d.EventAdd()
    from mcv_diagnostics import log
    log('PAPER_LAYOUT','background={} yaw={:.2f} pitch={:.2f} field={:.3f} padding={} lights={} softness={}'.format(
        background,yaw,pitch,field,padding,light_multiplier,softness))
