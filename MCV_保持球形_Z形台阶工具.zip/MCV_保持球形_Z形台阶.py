# -*- coding: utf-8 -*-
"""Run in Cinema 4D Script Manager; creates an undoable smooth Z-step copy.

Only MaterialsCIFVisualizer's original ATOMS/BONDS geometry is accepted.
Atoms are translated, never deformed. Bond cross sections are rigidly rotated;
their end separation changes while radius, materials, and connectivity remain.
This is a standalone shaping tool, not an installed plugin update.
"""
import itertools
import json
import math
import re
import traceback
from pathlib import Path

try:
    import c4d
except ImportError:
    c4d = None  # Pure geometry functions can be checked outside Cinema 4D.

MARKER_ID = 1067894
MODEL_MARKER = 'MaterialsCIFVisualizer.model.060'
GROUP_MARKER = 'MaterialsCIFVisualizer.geometry.060'
SHAPED_MARKER = 'MaterialsCIFVisualizer.shaping.step.002'
OLD_SHAPED_MARKER = 'MaterialsCIFVisualizer.shaping.ridge.001'
STATE_ID = 1067896
REPORT_PATH = Path.home()/'Documents'/'Codex'/'MCV_Z形台阶_运行结果.json'
DEFAULTS = dict(bend_axis=0, lift_axis=2, height_percent=5., width_percent=40., center_percent=50., high_side=0)


def save_report(report):
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')


def add(a, b): return tuple(x+y for x, y in zip(a, b))
def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def mul(a, s): return tuple(x*s for x in a)
def dot(a, b): return sum(x*y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def norm(a): return math.sqrt(dot(a, a))
def unit(a):
    length = norm(a)
    if length <= 1e-12: raise ValueError('发现零长度化学键，无法造型。')
    return mul(a, 1./length)


def step_mapper(positions, options):
    """Two flat plateaus connected by a monotone C2 smooth ramp, with no return."""
    axis, lift = options['bend_axis'], options['lift_axis']
    if type(axis) is not int or type(lift) is not int or axis not in (0, 1, 2) or lift not in (0, 1, 2) or axis == lift:
        raise ValueError('展开方向和抬起方向必须是两个不同的轴。')
    high_side = options.get('high_side', 0)
    if type(high_side) is not int or high_side not in (0, 1):
        raise ValueError('请选择正向或负向平台抬高。')
    if not positions:
        raise ValueError('模型没有可用的原子位置。')
    if any(len(point) != 3 or not all(math.isfinite(value) for value in point) for point in positions):
        raise ValueError('原子位置包含无效坐标。')
    height, width, center = [float(options[k]) for k in ('height_percent', 'width_percent', 'center_percent')]
    if not all(math.isfinite(x) for x in (height, width, center)):
        raise ValueError('请输入有限数字。')
    if not -20 <= height <= 20 or not 5 <= width <= 90 or not 0 <= center <= 100:
        raise ValueError('高度差范围 -20～20%；斜坡长度 5～90%；中心 0～100%。')
    low, high = min(p[axis] for p in positions), max(p[axis] for p in positions)
    span = high-low
    if span <= 1e-9: raise ValueError('展开方向没有足够长度，请换一个轴。')
    start_percent, end_percent = center-width/2., center+width/2.
    if start_percent < 5.-1e-9 or end_percent > 95.+1e-9:
        raise ValueError('斜坡两侧各需至少保留 5% 的平台。请缩短斜坡或将中心移向 50%。')
    start = low + span*start_percent/100.
    end = low + span*end_percent/100.
    amplitude = span*height/100.
    def mapper(point):
        t = min(1., max(0., (point[axis]-start)/(end-start)))
        # Zero first/second derivative at both joins, so the ends remain flat.
        amount = t*t*t*(10.+t*(-15.+6.*t))
        if high_side == 1:
            amount = 1.-amount
        result = list(point)
        result[lift] += amplitude*amount
        return tuple(result)
    return mapper, dict(span=span, height=amplitude, ramp_start=start, ramp_end=end,
                        ramp_length=end-start, start_percent=start_percent, end_percent=end_percent,
                        high_side='positive' if high_side == 0 else 'negative',
                        profile='smooth_z_step', low_platform_offset=0., high_platform_offset=amplitude)


def rotation_between(old_axis, new_axis):
    """A proper shortest rotation; never scales or shears cross sections."""
    a, b = unit(old_axis), unit(new_axis)
    v = cross(a, b)
    cosine = max(-1., min(1., dot(a, b)))
    if cosine > 1.-1e-14:
        return lambda point: tuple(point)
    if cosine < -1.+1e-12:
        helper = (1., 0., 0.) if abs(a[0]) < .8 else (0., 1., 0.)
        axis = unit(cross(a, helper))
        return lambda point: sub(mul(axis, 2.*dot(axis, point)), point)
    def rotate(point):
        first = cross(v, point)
        return add(add(point, first), mul(cross(v, first), 1./(1.+cosine)))
    return rotate


class AtomLookup:
    def __init__(self, positions):
        self.positions = positions
        extent = max(max(p[k] for p in positions)-min(p[k] for p in positions) for k in range(3))
        self.tolerance = max(extent*1e-7, 1e-7)
        self.grid = {}
        for index, point in enumerate(positions):
            if self.find(point) is not None:
                raise ValueError('有原子中心重合或过于接近，不能可靠识别化学键。')
            self.grid.setdefault(self.key(point), []).append(index)

    def key(self, point): return tuple(int(math.floor(x/self.tolerance)) for x in point)

    def find(self, point):
        key = self.key(point)
        matches = []
        for offset in itertools.product((-1, 0, 1), repeat=3):
            for index in self.grid.get(tuple(a+b for a, b in zip(key, offset)), ()):
                if norm(sub(self.positions[index], point)) <= self.tolerance:
                    matches.append(index)
        if len(matches) > 1: raise ValueError('化学键端点对应多个原子，停止造型。')
        return matches[0] if matches else None

    def endpoints(self, start, end, moved):
        """Heteroelement halves meet at the NEW full-bond midpoint, without kinks."""
        first, second = self.find(start), self.find(end)
        if first is not None and second is not None:
            if first == second: raise ValueError('发现连接同一原子的零长度键。')
            return moved[first], moved[second], tuple(sorted((first, second)))
        if first is not None:
            opposite = self.find(sub(mul(end, 2.), start))
            if opposite is not None and opposite != first:
                return moved[first], mul(add(moved[first], moved[opposite]), .5), tuple(sorted((first, opposite)))
        if second is not None:
            opposite = self.find(sub(mul(start, 2.), end))
            if opposite is not None and opposite != second:
                return mul(add(moved[second], moved[opposite]), .5), moved[second], tuple(sorted((second, opposite)))
        raise ValueError('无法将键端点与原子中心对应。请使用刚生成、尚未手动移动原子的模型。')


def reshape_piece(points, new_start, new_end, segments=24):
    if len(points) != 2*segments+2: raise ValueError('化学键网格布局不匹配。')
    start, end = points[-2:]
    rotate = rotation_between(sub(end, start), sub(new_end, new_start))
    result = [add(new_start, rotate(sub(point, start))) for point in points[:segments]]
    result += [add(new_end, rotate(sub(point, end))) for point in points[segments:2*segments]]
    return result + [new_start, new_end]


def topology(segments=24):
    faces = []
    for i in range(segments):
        j = (i+1) % segments
        faces += [(i, i+segments, j+segments, j), (2*segments, i, j, j),
                  (2*segments+1, j+segments, i+segments, i+segments)]
    return faces


def xyz(vector): return (float(vector.x), float(vector.y), float(vector.z))
def cv(point): return c4d.Vector(*point)


def uniform_matrix(matrix, name):
    """Reject pre-existing shear/nonuniform scale to make roundness meaningful."""
    axes = [xyz(matrix.v1), xyz(matrix.v2), xyz(matrix.v3)]
    sizes = [norm(axis) for axis in axes]
    if min(sizes) <= 1e-10 or max(sizes)-min(sizes) > max(sizes)*1e-6:
        raise ValueError(name + ' 已有不均匀缩放。请先在未缩放的原始模型上运行。')
    if any(abs(dot(axes[a], axes[b])) > sizes[a]*sizes[b]*1e-6 for a, b in ((0,1),(0,2),(1,2))):
        raise ValueError(name + ' 的坐标存在剪切，不能保证圆球和等粗键。')


def collect(root):
    groups = {}
    for group in root.GetChildren():
        if group.GetDataInstance()[MARKER_ID] == GROUP_MARKER:
            if group.GetName() in groups: raise ValueError('模型分组名称重复，请使用原始插件模型。')
            groups[group.GetName()] = group
    if 'ATOMS' not in groups or 'BONDS' not in groups:
        raise ValueError('没有找到插件的 ATOMS / BONDS 分组。')
    atoms = groups['ATOMS'].GetChildren()
    if not atoms: raise ValueError('模型没有原子，请先生成包含原子的模型。')
    allowed = (c4d.Osphere, c4d.Oinstance)
    if any(obj.GetType() not in allowed or obj.GetChildren() for obj in atoms):
        raise ValueError('原子分组不是插件原始球体/实例布局；不处理已经转换或嵌套的原子。')
    if len({obj.GetName() for obj in atoms}) != len(atoms): raise ValueError('原子名称重复。')
    atom_names = {obj.GetName() for obj in atoms}
    for atom in atoms:
        if atom.GetType() == c4d.Oinstance:
            reference = atom[c4d.INSTANCEOBJECT_LINK]
            if reference is None or reference.GetName() not in atom_names or reference.GetType() != c4d.Osphere:
                raise ValueError('原子实例没有引用本模型中的原始球体。')
    # Active deformers/expressions could override the carefully staged positions.
    def inspect(obj):
        if obj.GetInfo() & c4d.OBJECT_MODIFIER and obj.GetDeformMode():
            raise ValueError('模型内有已启用的变形器。请在未加入 FFD 的模型上运行。')
        if obj.GetCTracks(): raise ValueError('模型内有动画轨道。请先使用静态模型。')
        if any(tag.GetInfo() & c4d.TAG_EXPRESSION for tag in obj.GetTags()):
            raise ValueError('模型内有表达式标签，会覆盖造型结果。请使用无表达式的副本。')
        for child in obj.GetChildren(): inspect(child)
    inspect(root)
    return groups, atoms


def create_shaped_copy(root, options):
    """Compute and validate everything on detached geometry before document edits."""
    groups, atoms = collect(root)
    uniform_matrix(root.GetMg(), '晶体根对象')
    root_inverse = ~root.GetMg()
    def relative(obj): return root_inverse * obj.GetMg()
    for obj in list(groups.values()) + atoms:
        uniform_matrix(relative(obj), obj.GetName())
    atom_matrices = [relative(atom) for atom in atoms]
    positions = [xyz(matrix.off) for matrix in atom_matrices]
    mapper, dimensions = step_mapper(positions, options)
    moved = [mapper(point) for point in positions]
    lookup = AtomLookup(positions)
    bond_changes = []
    pairs = set()
    for obj in groups['BONDS'].GetChildren():
        matrix = relative(obj)
        uniform_matrix(matrix, obj.GetName())
        if obj.GetChildren(): raise ValueError('不支持嵌套的化学键对象。')
        if obj.GetType() == c4d.Opolygon:
            match = re.fullmatch(r'Bonds_([A-Za-z]+)_\d+_(\d+)pieces', obj.GetName())
            if not match: raise ValueError('不是插件生成的合并化学键：'+obj.GetName())
            count = int(match.group(2))
            if count <= 0 or obj.GetPointCount() != count*50 or obj.GetPolygonCount() != count*72:
                raise ValueError('化学键网格已改变，请重新生成模型。')
            faces = topology()
            for i in range(obj.GetPolygonCount()):
                polygon = obj.GetPolygon(i)
                actual = (polygon.a, polygon.b, polygon.c, polygon.d)
                expected = tuple(n + (i//72)*50 for n in faces[i%72])
                if actual != expected: raise ValueError('化学键网格拓扑与原始模型不一致。')
            points = [xyz(matrix*point) for point in obj.GetAllPoints()]
            inverse = ~matrix
            reshaped = []
            for i in range(count):
                piece = points[i*50:(i+1)*50]
                start, end, pair = lookup.endpoints(piece[-2], piece[-1], moved)
                pairs.add(pair)
                reshaped.extend(inverse*cv(point) for point in reshape_piece(piece, start, end))
            bond_changes.append(('mesh', obj.GetName(), reshaped, None))
        elif obj.GetType() == c4d.Ocylinder:
            if not re.fullmatch(r'Bond_\d+_[01]_[A-Za-z]+', obj.GetName()):
                raise ValueError('不是插件生成的独立化学键。')
            if obj[c4d.PRIM_AXIS] != c4d.PRIM_AXIS_YP:
                raise ValueError('独立化学键不再沿局部 Y 轴，请重新生成模型。')
            height = float(obj[c4d.PRIM_CYLINDER_HEIGHT])
            half = mul(xyz(matrix.v2), height*.5)
            start, end = sub(xyz(matrix.off), half), add(xyz(matrix.off), half)
            new_start, new_end, pair = lookup.endpoints(start, end, moved)
            pairs.add(pair)
            rotate = rotation_between(sub(end, start), sub(new_end, new_start))
            new_matrix = c4d.Matrix(cv(mul(add(new_start,new_end),.5)),
                                    cv(rotate(xyz(matrix.v1))), cv(rotate(xyz(matrix.v2))), cv(rotate(xyz(matrix.v3))))
            parent_inverse = ~relative(obj.GetUp())
            new_height = height*norm(sub(new_end,new_start))/norm(sub(end,start))
            bond_changes.append(('cylinder', obj.GetName(), parent_inverse*new_matrix, new_height))
        else:
            raise ValueError('化学键分组包含未知对象：'+obj.GetName())
    clone = root.GetClone(c4d.COPYFLAGS_NONE)
    if clone is None: raise MemoryError('无法创建晶体副本。')
    clone_groups = {obj.GetName(): obj for obj in clone.GetChildren()
                    if obj.GetDataInstance()[MARKER_ID] == GROUP_MARKER}
    # Original groups may already be hidden after the previous ridge tool run.
    for name in ('ATOMS', 'BONDS'):
        clone_groups[name].SetEditorMode(c4d.MODE_UNDEF)
        clone_groups[name].SetRenderMode(c4d.MODE_UNDEF)
    clone_atoms = {obj.GetName(): obj for obj in clone_groups['ATOMS'].GetChildren()}
    parent_inverse = ~relative(groups['ATOMS'])
    for old, matrix, point in zip(atoms, atom_matrices, moved):
        new = clone_atoms[old.GetName()]
        matrix.off = cv(point)
        new.SetMl(parent_inverse*matrix)  # Basis/scale of every atom stays the same.
        if old.GetType() == c4d.Oinstance:
            new[c4d.INSTANCEOBJECT_LINK] = clone_atoms[old[c4d.INSTANCEOBJECT_LINK].GetName()]
    clone_bonds = {obj.GetName(): obj for obj in clone_groups['BONDS'].GetChildren()}
    if len(clone_bonds) != len(groups['BONDS'].GetChildren()): raise ValueError('化学键名称重复。')
    for kind, name, value, height in bond_changes:
        obj = clone_bonds[name]
        if kind == 'mesh': obj.SetAllPoints(value)
        else:
            obj.SetMl(value)
            obj[c4d.PRIM_CYLINDER_HEIGHT] = height
        obj.Message(c4d.MSG_UPDATE)
    # Only copy generated crystal geometry; hand-added substrate/electrodes stay
    # in the original hierarchy and must not be hidden or duplicated.
    for child in clone.GetChildren():
        if child.GetName() not in ('ATOMS','BONDS','UNIT_CELL') or child.GetDataInstance()[MARKER_ID] != GROUP_MARKER:
            child.Remove()
    if 'UNIT_CELL' in clone_groups:
        clone_groups['UNIT_CELL'].SetEditorMode(c4d.MODE_OFF)
        clone_groups['UNIT_CELL'].SetRenderMode(c4d.MODE_OFF)
    clone.SetName(root.GetName()+'_Z形台阶')
    clone.GetDataInstance()[MARKER_ID] = SHAPED_MARKER
    # A curved sheet has no valid periodic generation recipe. Make it explicit
    # that this detached copy is not a model for the plugin's Update command.
    clone.GetDataInstance()[STATE_ID] = json.dumps(dict(tool='step.002', options=options), ensure_ascii=False)
    clone.SetEditorMode(c4d.MODE_UNDEF)
    clone.SetRenderMode(c4d.MODE_UNDEF)
    changes = []
    for a, b in sorted(pairs):
        before, after = norm(sub(positions[b],positions[a])), norm(sub(moved[b],moved[a]))
        changes.append((after/before-1.)*100.)
    report = dict(status='PREPARED', source=root.GetName(), atom_count=len(atoms),
                  bond_count=len(pairs), bond_piece_objects=len(bond_changes), options=options,
                  dimensions=dimensions, max_abs_bond_length_change_percent=max(map(abs, changes), default=0.),
                  atom_shapes='unchanged', bond_cross_sections='rigidly rotated, unchanged radius',
                  connectivity='unchanged', materials='shared originals',
                  note='原子位置和键长/键角会改变；本工具不是力学计算。')
    return clone, groups, report


def commit_copy(doc, root, clone, groups):
    """One undo step; hide generated groups, not hand-added root children."""
    old_active = doc.GetActiveObject()
    hidden = list(groups.values())
    old_modes = [(obj, obj.GetEditorMode(), obj.GetRenderMode()) for obj in hidden]
    registered = False
    doc.StartUndo()
    try:
        for obj in hidden:
            if not doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj): raise RuntimeError('无法记录撤销。')
            registered = True
        doc.InsertObject(clone, parent=root.GetUp(), pred=root)
        if not doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, clone): raise RuntimeError('无法记录副本撤销。')
        for obj in hidden:
            obj.SetEditorMode(c4d.MODE_OFF)
            obj.SetRenderMode(c4d.MODE_OFF)
        doc.SetActiveObject(clone, c4d.SELECTION_NEW)
    except Exception:
        doc.EndUndo()
        if registered: doc.DoUndo()
        if clone.GetDocument() is doc: clone.Remove()
        for obj, editor, render in old_modes:
            obj.SetEditorMode(editor)
            obj.SetRenderMode(render)
        if old_active is not None: doc.SetActiveObject(old_active,c4d.SELECTION_NEW)
        c4d.EventAdd()
        raise
    else:
        doc.EndUndo()
        c4d.EventAdd()


if c4d is not None:
    class StepDialog(c4d.gui.GeDialog):
        def CreateLayout(self):
            self.SetTitle('MCV 保持球形：Z形台阶 0.2')
            self.GroupBegin(100, c4d.BFH_SCALEFIT, cols=2, rows=0)
            self.GroupBorderSpace(12,12,12,12)
            for label, pid in [('展开方向（模型局部轴）',101),('抬起方向（模型局部轴）',102)]:
                self.AddStaticText(0,c4d.BFH_LEFT,name=label)
                self.AddComboBox(pid,c4d.BFH_SCALEFIT,initw=180)
                for i, axis in enumerate('XYZ'): self.AddChild(pid,i,axis)
            self.AddStaticText(0,c4d.BFH_LEFT,name='抬高哪一端（展开轴方向）')
            self.AddComboBox(109,c4d.BFH_SCALEFIT,initw=180)
            self.AddChild(109,0,'正向端（+X / +Y / +Z）')
            self.AddChild(109,1,'负向端（-X / -Y / -Z）')
            for label,pid in [('平台高度差 / 展开长度（%，建议 3～6）',103),
                              ('斜坡长度 / 展开长度（%，建议 30～50）',104),('斜坡中心位置（%，50 为中央）',105)]:
                self.AddStaticText(0,c4d.BFH_LEFT,name=label)
                self.AddEditText(pid,c4d.BFH_SCALEFIT,initw=180)
            self.GroupEnd()
            self.AddStaticText(0,c4d.BFH_LEFT,name='一端保持原位，另一端整体抬高；中间平滑连接，不再回落。')
            self.AddStaticText(0,c4d.BFH_LEFT,name='生成副本，保留原子大小、材质及键粗细；键长和键角随造型改变。')
            self.GroupBegin(106,c4d.BFH_CENTER,cols=2,rows=1)
            self.AddButton(107,c4d.BFH_LEFT,name='生成造型副本',initw=160)
            self.AddButton(108,c4d.BFH_LEFT,name='取消',initw=100)
            self.GroupEnd()
            return True

        def InitValues(self):
            self.options = None
            self.SetInt32(101,DEFAULTS['bend_axis']); self.SetInt32(102,DEFAULTS['lift_axis'])
            self.SetInt32(109,DEFAULTS['high_side'])
            for pid,key in ((103,'height_percent'),(104,'width_percent'),(105,'center_percent')):
                self.SetString(pid,str(DEFAULTS[key]))
            return True

        def Command(self,pid,message):
            if pid == 108: self.Close()
            elif pid == 107:
                try:
                    options = dict(bend_axis=self.GetInt32(101), lift_axis=self.GetInt32(102),
                                   height_percent=float(self.GetString(103)),
                                    width_percent=float(self.GetString(104)),center_percent=float(self.GetString(105)),
                                    high_side=self.GetInt32(109))
                    step_mapper([(0.,0.,0.),(1.,1.,1.)],options)
                    self.options = options
                    self.Close()
                except (ValueError,TypeError) as exc: c4d.gui.MessageDialog(str(exc))
            return True


def main():
    if c4d is None: raise RuntimeError('请在 Cinema 4D 脚本管理器中运行。')
    doc = c4d.documents.GetActiveDocument()
    if doc is None: return
    root = doc.GetActiveObject()
    while root is not None and root.GetDataInstance()[MARKER_ID] not in (MODEL_MARKER, SHAPED_MARKER, OLD_SHAPED_MARKER):
        root = root.GetUp()
    if root is None:
        c4d.gui.MessageDialog('请先选择插件生成的晶体根对象（MCV_...）或其中一个原子。')
        return
    if root.GetDataInstance()[MARKER_ID] in (SHAPED_MARKER, OLD_SHAPED_MARKER):
        c4d.gui.MessageDialog('这个对象已经是造型副本。请隐藏或撤销该副本，选择原始晶体 MCV_... 再运行，避免累加形变。')
        return
    dialog = StepDialog()
    dialog.Open(c4d.DLG_TYPE_MODAL,defaultw=680,defaulth=320)
    if dialog.options is None: return
    try:
        c4d.StopAllThreads()
        c4d.StatusSetText('准备 Z形台阶副本…')
        clone,groups,report = create_shaped_copy(root,dialog.options)
        commit_copy(doc,root,clone,groups)
        report['status'] = 'APPLIED'
        message = ('已生成：'+clone.GetName()+'\n原子数：'+str(report['atom_count'])+
                   '\n最大键长变化：{:.2f}%'.format(report['max_abs_bond_length_change_percent'])+
                   '\n球形和键粗细保留。Ctrl+Z 可恢复原始模型。')
        try:
            save_report(report)
        except OSError:
            message += '\n运行记录未能保存，但造型副本已生成。'
        print(json.dumps(report,ensure_ascii=False,indent=2))
        c4d.gui.MessageDialog(message)
    except Exception as exc:
        traceback.print_exc()
        report = dict(status='FAILED',error=str(exc),traceback=traceback.format_exc())
        try: save_report(report)
        except OSError: pass
        c4d.gui.MessageDialog('未完成造型：\n'+str(exc))
    finally:
        c4d.StatusClear()


if __name__ == '__main__':
    main()
