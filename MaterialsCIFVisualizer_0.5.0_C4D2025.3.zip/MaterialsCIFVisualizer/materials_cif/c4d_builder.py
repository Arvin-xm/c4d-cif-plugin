"""Cinema 4D scene builder for Materials CIF Visualizer.

This module is imported only inside Cinema 4D. The core CIF parser remains
independent so it can be tested with normal CPython.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Sequence, Tuple

import c4d
from c4d import utils

from .cif_parser import BuiltStructure, CartesianAtom
from .bonds import Bond
from .elements import ELEMENT_COLORS, VISUAL_RADII, DEFAULT_COLOR, DEFAULT_VISUAL_RADIUS


Vec3 = Tuple[float, float, float]
RIG_MARKER_ID = 1067894
RIG_MARKER = 'MaterialsCIFVisualizer.paper.040'


def _cv(v: Vec3) -> c4d.Vector:
    return c4d.Vector(float(v[0]), float(v[1]), float(v[2]))


def _sub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]-b[0], a[1]-b[1], a[2]-b[2])


def _add(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]+b[0], a[1]+b[1], a[2]+b[2])


def _mul(a: Vec3, s: float) -> Vec3:
    return (a[0]*s, a[1]*s, a[2]*s)


def _dot(a: Vec3, b: Vec3) -> float:
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def _cross(a: Vec3, b: Vec3) -> Vec3:
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _norm(a: Vec3) -> float:
    return math.sqrt(_dot(a, a))


def _unit(a: Vec3) -> Vec3:
    n = _norm(a)
    if n < 1e-12:
        return (0.0, 1.0, 0.0)
    return _mul(a, 1.0/n)


def _material(doc, name, rgb, renderer='native'):
    # Per-build sharing: editing a new palette must not recolor earlier models.
    if renderer == 'vray':
        from .vray_adapter import create_material
        mat = create_material(rgb)
    else:
        mat = c4d.BaseMaterial(c4d.Mmaterial)
        mat[c4d.MATERIAL_USE_COLOR] = True
        mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(*rgb)
        mat[c4d.MATERIAL_USE_REFLECTION] = False
    mat.SetName('MCV_' + name + ('_Vray' if renderer == 'vray' else ''))
    doc.InsertMaterial(mat)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, mat)
    return mat


def _assign_material(obj: c4d.BaseObject, mat: c4d.BaseMaterial) -> None:
    tag = c4d.TextureTag()
    tag.SetMaterial(mat)
    obj.InsertTag(tag)


def _smooth(obj, angle_limit=False):
    tag = c4d.BaseTag(c4d.Tphong)
    tag[c4d.PHONGTAG_PHONG_ANGLELIMIT] = angle_limit
    tag[c4d.PHONGTAG_PHONG_ANGLE] = math.radians(40.0)
    obj.InsertTag(tag)


def _display_color(obj, rgb):
    obj[c4d.ID_BASEOBJECT_USECOLOR] = c4d.ID_BASEOBJECT_USECOLOR_ALWAYS
    obj[c4d.ID_BASEOBJECT_COLOR] = _cv(rgb)


def _make_cylinder(name: str, p1: Vec3, p2: Vec3, radius: float,
                   segments: int = 24) -> Optional[c4d.BaseObject]:
    delta = _sub(p2, p1)
    length = _norm(delta)
    if length < 1e-9:
        return None
    yaxis = _unit(delta)
    helper = (1.0, 0.0, 0.0) if abs(yaxis[0]) < 0.85 else (0.0, 0.0, 1.0)
    xaxis = _unit(_cross(helper, yaxis))
    zaxis = _unit(_cross(xaxis, yaxis))
    mid = _mul(_add(p1, p2), 0.5)

    obj = c4d.BaseObject(c4d.Ocylinder)
    obj.SetName(name)
    obj[c4d.PRIM_CYLINDER_RADIUS] = radius
    obj[c4d.PRIM_CYLINDER_HEIGHT] = length
    if hasattr(c4d, "PRIM_CYLINDER_SEG"):
        obj[c4d.PRIM_CYLINDER_SEG] = segments
    if hasattr(c4d, "PRIM_CYLINDER_CAPS"):
        obj[c4d.PRIM_CYLINDER_CAPS] = True
    obj.SetMg(c4d.Matrix(_cv(mid), _cv(xaxis), _cv(yaxis), _cv(zaxis)))
    _smooth(obj, angle_limit=True)
    return obj


def _group(name: str, parent: c4d.BaseObject) -> c4d.BaseObject:
    g = c4d.BaseObject(c4d.Onull)
    g.SetName(name)
    g.InsertUnder(parent)
    return g


def build_scene(doc: c4d.documents.BaseDocument,
                built: BuiltStructure,
                bonds: Sequence[Bond],
                name: str,
                scene_scale: float = 20.0,
                atom_scale: float = 0.70,
                bond_radius_angstrom: float = 0.08,
                make_atoms: bool = True,
                make_bonds: bool = True,
                make_cell: bool = False, sphere_segments=64,
                instance_mode='render', element_styles=None,
                renderer='native') -> c4d.BaseObject:
    """Build the model and return the root null."""
    if instance_mode not in ('render', 'standard', 'off'):
        raise ValueError('Unknown atom instance mode.')
    if renderer not in ('native', 'vray'):
        raise ValueError('Unknown material renderer.')
    sphere_segments = max(16, min(128, int(sphere_segments)))
    styles = element_styles or {}
    if renderer == 'vray':
        from .vray_adapter import preflight
        preflight()
    doc.StartUndo()
    try:
        root = c4d.BaseObject(c4d.Onull)
        root.SetName("MCV_" + (name or "Structure"))
        doc.InsertObject(root)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, root)

        atoms_g = _group("ATOMS", root)
        bonds_g = _group("BONDS", root)
        cell_g = _group("UNIT_CELL", root)
        materials: Dict[str, c4d.BaseMaterial] = {}

        def style(element):
            custom = styles.get(element, {})
            return (custom.get('color', ELEMENT_COLORS.get(element, DEFAULT_COLOR)),
                    custom.get('radius', VISUAL_RADII.get(element, DEFAULT_VISUAL_RADIUS)))

        def material(element):
            if element not in materials:
                materials[element] = _material(doc, element, style(element)[0], renderer)
            return materials[element]

        if make_atoms:
            sources = {}
            for idx, atom in enumerate(built.atoms):
                rgb, visual_radius = style(atom.element)
                if instance_mode != 'off' and atom.element in sources:
                    sphere = c4d.BaseObject(c4d.Oinstance)
                    sphere[c4d.INSTANCEOBJECT_LINK] = sources[atom.element]
                    sphere[c4d.INSTANCEOBJECT_RENDERINSTANCE_MODE] = (
                        c4d.INSTANCEOBJECT_RENDERINSTANCE_MODE_SINGLEINSTANCE
                        if instance_mode == 'render' else c4d.INSTANCEOBJECT_RENDERINSTANCE_MODE_NONE)
                    sphere.SetName(f'{atom.element}_{idx:04d}_instance')
                else:
                    sphere = c4d.BaseObject(c4d.Osphere)
                    sphere.SetName(f'{atom.element}_{idx:04d}_source')
                    sphere[c4d.PRIM_SPHERE_RAD] = visual_radius * atom_scale * scene_scale
                    sphere[c4d.PRIM_SPHERE_SUB] = sphere_segments
                    sphere[c4d.PRIM_SPHERE_TYPE] = c4d.PRIM_SPHERE_TYPE_STANDARD
                    _smooth(sphere)
                    sources[atom.element] = sphere
                sphere.SetRelPos(_cv(_mul(atom.position, scene_scale)))
                sphere.InsertUnder(atoms_g)
                _assign_material(sphere, material(atom.element))
                _display_color(sphere, rgb)

        if make_bonds and bonds:
            rr = bond_radius_angstrom * scene_scale
            for k, bond in enumerate(bonds):
                p1 = _mul(built.atoms[bond.i].position, scene_scale)
                p2 = _mul(built.atoms[bond.j].position, scene_scale)
                a, b = built.atoms[bond.i].element, built.atoms[bond.j].element
                midpoint = _mul(_add(p1, p2), 0.5)
                # Same-element contacts need one cylinder; others meet exactly at midpoint.
                pieces = [(p1, p2, a)] if a == b else [(p1, midpoint, a), (midpoint, p2, b)]
                for half, (start, end, element) in enumerate(pieces):
                    cyl = _make_cylinder(f'Bond_{k:05d}_{half}_{element}', start, end, rr)
                    if cyl is not None:
                        cyl.InsertUnder(bonds_g)
                        _assign_material(cyl, material(element))
                        _display_color(cyl, style(element)[0])

        if make_cell:
            cell_mat = _material(doc, "UnitCell", (0.30, 0.34, 0.38), renderer)
            o = _mul(built.center_shift, scene_scale)
            a = _mul(built.cell_vectors[0], scene_scale)
            b = _mul(built.cell_vectors[1], scene_scale)
            c = _mul(built.cell_vectors[2], scene_scale)
            corners = [
                o, _add(o,a), _add(o,b), _add(o,c),
                _add(_add(o,a),b), _add(_add(o,a),c), _add(_add(o,b),c),
                _add(_add(_add(o,a),b),c),
            ]
            edges = [(0,1),(0,2),(0,3),(1,4),(1,5),(2,4),(2,6),(3,5),(3,6),(4,7),(5,7),(6,7)]
            rr = max(scene_scale * 0.025, 0.5)
            for k,(i,j) in enumerate(edges):
                cyl = _make_cylinder(f"CellEdge_{k:02d}", corners[i], corners[j], rr, 10)
                if cyl:
                    cyl.InsertUnder(cell_g)
                    _assign_material(cyl, cell_mat)

        # Hide empty organizational groups when their feature is disabled.
        if not make_atoms:
            atoms_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            atoms_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF
        if not make_bonds:
            bonds_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            bonds_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF
        if not make_cell:
            cell_g[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
            cell_g[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF

        c4d.EventAdd()
        return root
    finally:
        doc.EndUndo()


def _look_at(obj: c4d.BaseObject, target: c4d.Vector) -> None:
    direction = target - obj.GetAbsPos()
    obj.SetAbsRot(utils.VectorToHPB(direction))


def setup_paper_scene(doc: c4d.documents.BaseDocument,
                      built: BuiltStructure,
                      scene_scale: float = 20.0, renderer='native',
                      output_path=None, resolution=3000,
                      atom_margin_angstrom=2.0, include_cell=False) -> None:
    """Create a scientific camera/light rig and RGBA PNG output settings."""
    if not built.atoms:
        return
    if renderer == 'vray':
        from .vray_adapter import preflight, create_light, enable_renderer
        preflight(lights=True)
    elif renderer != 'native':
        raise ValueError('Unknown renderer.')
    doc.StartUndo()
    try:
        pts = [_mul(a.position, scene_scale) for a in built.atoms]
        if include_cell:
            from itertools import product
            for bits in product((0, 1), repeat=3):
                corner = built.center_shift
                for bit, vector in zip(bits, built.cell_vectors):
                    if bit:
                        corner = _add(corner, vector)
                pts.append(_mul(corner, scene_scale))
        xs, ys, zs = [p[0] for p in pts], [p[1] for p in pts], [p[2] for p in pts]
        extent = max(max(xs)-min(xs), max(ys)-min(ys), max(zs)-min(zs), 100.0)
        target = ((max(xs)+min(xs))/2, (max(ys)+min(ys))/2, (max(zs)+min(zs))/2)
        radius = max(_norm(_sub(p,target)) for p in pts) + atom_margin_angstrom * scene_scale

        rig = c4d.BaseObject(c4d.Onull)
        rig.SetName("MCV_PAPER_SCENE")
        rig.GetDataInstance()[RIG_MARKER_ID] = RIG_MARKER
        previous = doc.GetFirstObject()
        while previous is not None:
            following = previous.GetNext()
            if previous.GetDataInstance()[RIG_MARKER_ID] == RIG_MARKER:
                doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, previous)
                previous.Remove()
            previous = following
        doc.InsertObject(rig)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, rig)

        cam = c4d.BaseObject(c4d.Ocamera)
        cam.SetName("MCV_Camera_Orthographic")
        cam[c4d.CAMERA_PROJECTION] = c4d.Pparallel
        # Maxon: parallel Zoom=1 covers 1024 scene units. Bounding sphere fits
        # all orientations; a 15% margin includes the balls' visible radii.
        cam[c4d.CAMERA_ZOOM] = 1024.0 / max(2.0 * radius * 1.15, 1.0)
        cam.SetAbsPos(_cv(_add(target,(extent*0.95, -extent*1.35, extent*0.95))))
        _look_at(cam, _cv(target))
        cam.InsertUnder(rig)

        key = (create_light(extent * 0.65, 12.0, (1.0, 0.98, 0.96))
               if renderer == 'vray' else c4d.BaseObject(c4d.Olight))
        key.SetName("MCV_Key_Area")
        if renderer != 'vray':
            key[c4d.LIGHT_TYPE] = c4d.LIGHT_TYPE_AREA
            key[c4d.LIGHT_BRIGHTNESS] = 0.85
            key[c4d.LIGHT_COLOR] = c4d.Vector(1.0, 0.98, 0.96)
            key[c4d.LIGHT_SHADOWTYPE] = c4d.LIGHT_SHADOWTYPE_AREA
        key.SetAbsPos(_cv(_add(target,(-extent*0.7, -extent*0.6, extent*1.8))))
        _look_at(key, _cv(target))
        key.InsertUnder(rig)

        fill = (create_light(extent * 0.9, 5.0, (0.95, 0.98, 1.0))
                if renderer == 'vray' else c4d.BaseObject(c4d.Olight))
        fill.SetName("MCV_Fill_Area")
        if renderer != 'vray':
            fill[c4d.LIGHT_TYPE] = c4d.LIGHT_TYPE_AREA
            fill[c4d.LIGHT_BRIGHTNESS] = 0.35
            fill[c4d.LIGHT_COLOR] = c4d.Vector(0.95, 0.98, 1.0)
            fill[c4d.LIGHT_SHADOWTYPE] = c4d.LIGHT_SHADOWTYPE_NONE
        fill.SetAbsPos(_cv(_add(target,(extent*1.2, extent*0.6, extent*0.9))))
        _look_at(fill, _cv(target))
        fill.InsertUnder(rig)

        rd = doc.GetActiveRenderData()
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, rd)
        rd[c4d.RDATA_XRES] = resolution
        rd[c4d.RDATA_YRES] = resolution
        rd[c4d.RDATA_FILMASPECT] = 1.0
        rd[c4d.RDATA_PIXELASPECT] = 1.0
        rd[c4d.RDATA_FORMAT] = c4d.FILTER_PNG
        rd[c4d.RDATA_FORMATDEPTH] = c4d.RDATA_FORMATDEPTH_8
        rd[c4d.RDATA_ALPHACHANNEL] = True
        rd[c4d.RDATA_STRAIGHTALPHA] = True
        rd[c4d.RDATA_SEPARATEALPHA] = False
        if output_path:
            rd[c4d.RDATA_SAVEIMAGE] = True
            rd[c4d.RDATA_PATH] = output_path
        if renderer == 'vray':
            enable_renderer(doc, output_path)
        else:
            rd[c4d.RDATA_RENDERENGINE] = c4d.RDATA_RENDERENGINE_STANDARD

        # Set viewport/render camera when possible.
        bd = doc.GetActiveBaseDraw()
        if bd is not None:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, bd)
            bd.SetSceneCamera(cam)
        c4d.EventAdd()
    finally:
        doc.EndUndo()
