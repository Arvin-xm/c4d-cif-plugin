"""Independent distance oracle and edge cases for finite-supercell contacts."""
import math
from pathlib import Path
import random
import unittest

from materials_cif import parse_cif_file, build_supercell
from materials_cif.bonds import infer_bonds, default_cutoff
from materials_cif.cif_parser import CartesianAtom

ROOT = Path(__file__).resolve().parent.parent


def atom(element, point):
    return CartesianAtom(element, element, point)


def brute(atoms, tolerance, overrides=None, allowed=None):
    out = []
    for i, a in enumerate(atoms):
        for j in range(i+1, len(atoms)):
            b = atoms[j]
            pair = tuple(sorted((a.element, b.element)))
            if allowed is not None and pair not in allowed:
                continue
            lo, hi = (overrides or {}).get(pair, (0.35, default_cutoff(pair, tolerance)))
            d = math.dist(a.position, b.position)
            if max(lo, 0.35) <= d <= hi:
                out.append((i, j, d))
    return out


class Bonds040Tests(unittest.TestCase):
    def compare(self, atoms, tolerance=1.18, overrides=None, allowed=None):
        expected = brute(atoms, tolerance, overrides, allowed)
        actual = infer_bonds(atoms, tolerance, pair_overrides=overrides, allowed_pairs=allowed)
        self.assertEqual([(b.i,b.j) for b in actual], [(i,j) for i,j,_ in expected])
        for bond, (_,_,distance) in zip(actual, expected):
            self.assertAlmostEqual(bond.distance, distance, places=12)
        return actual

    def test_supplied_cifs_match_all_pairs(self):
        for name, expected in (('PdSe2', 29), ('MoS2', 28)):
            s = parse_cif_file(str(ROOT/'examples'/ (name+'.cif')))
            built = build_supercell(s, 1, 2, 2, 'AUTO')
            bonds = self.compare(built.atoms)
            self.assertEqual(len(bonds), expected)

    def test_random_mixed_atoms_and_negative_bins(self):
        rng = random.Random(405)
        atoms = [atom(rng.choice(('C','H','S')), tuple(rng.uniform(-6,6) for _ in range(3))) for _ in range(400)]
        self.compare(atoms)
        self.compare(atoms, overrides={('C','H'): (1.0,4.0)}, allowed={('C','H'),('S','S')})

    def test_inclusive_boundaries_and_exclusion(self):
        atoms = [atom('C', (0,0,0)), atom('H',(1,0,0)), atom('H',(2,0,0))]
        bonds = infer_bonds(atoms, pair_overrides={('H','C'):(1,2)}, allowed_pairs={('H','C')})
        self.assertEqual([(b.i,b.j) for b in bonds], [(0,1),(0,2)])
        self.assertEqual(infer_bonds(atoms, allowed_pairs=set()), [])
        self.assertEqual(infer_bonds(atoms, excluded_pairs={('C','H'),('H','H')}), [])

    def test_internal_cell_boundary_and_no_phantom_endpoints(self):
        atoms = [atom('C', (9.9,0,0)),atom('C',(10.1,0,0)),atom('C',(11,0,0))]
        bonds = self.compare(atoms)
        self.assertTrue(any((b.i,b.j)==(0,2) for b in bonds))
        self.assertTrue(all(0 <= b.i < b.j < len(atoms) for b in bonds))

    def test_no_zero_length_or_duplicate_contacts(self):
        atoms = [atom('C',(0,0,0)),atom('C',(0,0,0)),atom('C',(1,0,0))]
        bonds = infer_bonds(atoms, min_distance=0)
        self.assertEqual([(b.i,b.j) for b in bonds], [(0,2),(1,2)])

    def test_invalid_ranges_and_limits(self):
        atoms = [atom('C',(0,0,0)),atom('C',(1,0,0)),atom('C',(0,1,0))]
        for kwargs in ({'tolerance':float('nan')}, {'min_distance':-1}, {'max_distance':-1},
                       {'pair_overrides':{('C','C'):(2,1)}}, {'pair_overrides':{('C','C'):(1,float('inf'))}}):
            with self.assertRaises(ValueError):
                infer_bonds(atoms, **kwargs)
        with self.assertRaisesRegex(ValueError, 'More than'):
            infer_bonds(atoms, max_bonds=1)

    def test_global_max_distance(self):
        atoms = [atom('C',(0,0,0)),atom('C',(1,0,0)),atom('C',(2,0,0))]
        self.assertEqual([(b.i,b.j) for b in infer_bonds(atoms, max_distance=1)], [(0,1),(1,2)])

    def test_10000_atom_sparse_search_avoids_all_pairs(self):
        atoms = [atom('C',(i*1.4,0,0)) for i in range(10000)]
        stats = {}
        bonds = infer_bonds(atoms, stats=stats)
        self.assertEqual(len(bonds), 9999)
        self.assertLess(stats['distance_checks'], 40000)


if __name__ == '__main__':
    unittest.main()
