"""Native GeUserArea canvas using the installed C4D 2025.3 drawing API."""
import math
import c4d
from mcv_diagnostics import log_exception


class StructurePreview(c4d.gui.GeUserArea):
    def __init__(self):
        super().__init__()
        self.data = None
        self.message = '选择 CIF 后显示结构预览'
        self.yaw, self.pitch, self.zoom = 35.0, 40.0, 1.0
        self.labels = False
        self.last_draw_error = None

    def GetMinSize(self):
        return 400, 320

    def set_data(self, data):
        self.data = data
        self.message = ''
        self.Redraw()

    def clear(self, message='请选择有效 CIF'):
        self.data = None
        self.message = message
        self.Redraw()

    def view(self, kind):
        self.yaw, self.pitch = {'3d':(35,40),'top':(0,0),'front':(0,90),'side':(90,90)}[kind]
        self.zoom = 1.0
        self.Redraw()

    def zoom_by(self, factor):
        self.zoom = min(10.0,max(.2,self.zoom*factor))
        self.Redraw()

    def _pen(self, rgb):
        self.DrawSetPen(c4d.Vector(*rgb))

    def _sphere(self, item):
        x,y = item['center']
        radius = item['radius']
        color = item['color']
        self._pen(tuple(v*.52 for v in color))
        self.DrawEllipseFill([x,y],[radius,radius])
        if radius > 2:
            self._pen(color)
            self.DrawEllipseFill([x-radius*.10,y-radius*.10],[radius*.86,radius*.86])
            self._pen(tuple(min(1,v*.65+.35) for v in color))
            self.DrawEllipseFill([x-radius*.27,y-radius*.27],[radius*.43,radius*.43])

    def _segment(self, item):
        if item.get('hidden'):
            return
        x1,y1 = item['start']; x2,y2 = item['end']
        length = math.hypot(x2-x1,y2-y1)
        radius = item['radius']
        self._pen(item['color'])
        if length < .01:
            self.DrawEllipseFill([x1,y1],[radius,radius])
            return
        dx,dy = -(y2-y1)*radius/length, (x2-x1)*radius/length
        self.DrawPolyFill([x1+dx,y1+dy,x2+dx,y2+dy,x2-dx,y2-dy,x1-dx,y1-dy],True)

    def DrawMsg(self, x1, y1, x2, y2, msg):
        try:
            self.OffScreenOn()
            self.SetClippingRegion(x1,y1,x2-x1+1,y2-y1+1)
            self._pen((.075,.09,.115))
            self.DrawRectangle(x1,y1,x2,y2)
            width,height = self.GetWidth(),self.GetHeight()
            self.DrawSetTextCol(c4d.Vector(.85,.89,.95),c4d.Vector(.075,.09,.115))
            if self.data is None:
                self.DrawText(self.message,15,20)
                return
            primitives,scale = self.data.project(width,height,self.yaw,self.pitch,self.zoom)
            for item in primitives:
                if item['kind']=='atom':
                    self._sphere(item)
                else:
                    self._segment(item)
            if self.labels and len(self.data.built.atoms)<=200:
                for item in primitives:
                    if item['kind']=='atom':
                        self.DrawText(item['label'],int(item['center'][0]+item['radius']+2),int(item['center'][1]))
            self._pen((.85,.89,.95))
            self.DrawLine(15,height-20,75,height-20)
            self.DrawText('{:.3g} Å'.format(60/scale),15,height-43)
            self.DrawText('结构预览 · 左键旋转 · 滚轮缩放',15,8)
            self.last_draw_error = None
        except Exception as exc:
            if self.last_draw_error != str(exc):
                log_exception('PREVIEW_DRAW_FAILED')
            self.last_draw_error = str(exc)

    def InputEvent(self, msg):
        if msg[c4d.BFM_INPUT_DEVICE] != c4d.BFM_INPUT_MOUSE:
            return False
        channel = msg[c4d.BFM_INPUT_CHANNEL]
        if channel == c4d.BFM_INPUT_MOUSEWHEEL:
            value = msg[c4d.BFM_INPUT_VALUE]
            if value:
                self.zoom_by(1.15 if value>0 else 1/1.15)
            return True
        if channel != c4d.BFM_INPUT_MOUSELEFT:
            return False
        original = self.yaw,self.pitch
        self.MouseDragStart(c4d.BFM_INPUT_MOUSELEFT,msg[c4d.BFM_INPUT_X],msg[c4d.BFM_INPUT_Y],
                            c4d.MOUSEDRAGFLAGS_DONTHIDEMOUSE|c4d.MOUSEDRAGFLAGS_NOMOVE)
        try:
            while True:
                result,dx,dy,channels = self.MouseDrag()
                if result != c4d.MOUSEDRAGRESULT_CONTINUE:
                    break
                self.yaw = (self.yaw+dx*.5)%360
                self.pitch = max(-89.0,min(89.0,self.pitch+dy*.5))
                self.Redraw()
        finally:
            result = self.MouseDragEnd()
        if result == c4d.MOUSEDRAGRESULT_ESCAPE:
            self.yaw,self.pitch = original
            self.Redraw()
        return True
