"""Run deterministic checks on the two supplied CIF files, without C4D."""
import os
import copy
from materials_cif import parse_cif_file, parse_cif_text, parse_cif_block, load_cif_document, CIFError, structure_summary, build_supercell, infer_bonds


def run_selftest(root=None):
    root = root or os.path.dirname(__file__)
    lines = []
    for filename, elements, axis in (
        ('PdSe2.cif', {'Pd': 2, 'Se': 4}, 'A'),
        ('MoS2.cif', {'Mo': 2, 'S': 4}, None),
    ):
        structure = parse_cif_file(os.path.join(root, 'examples', filename))
        info = structure_summary(structure)
        if info['elements'] != elements or info['expanded_atoms'] != 6:
            raise ValueError('{}: unexpected atom counts {}'.format(filename, info))
        if info['detected_vacuum_axis'] != axis:
            raise ValueError('{}: unexpected vacuum axis'.format(filename))
        built = build_supercell(structure, 1, 2, 2, 'AUTO')
        if len(built.atoms) != 24:
            raise ValueError('{}: unexpected supercell size'.format(filename))
        bonds = infer_bonds(built.atoms, tolerance=1.18)
        if not bonds or any(b.distance <= 0 for b in bonds):
            raise ValueError('{}: invalid visual bonds'.format(filename))
        lines.append('{} PASS: {} / cell, 24 / supercell, {} bonds, vacuum={}'.format(
            filename, elements, len(bonds), axis))
    block = copy.deepcopy(load_cif_document(os.path.join(root,'examples','PdSe2.cif'))[0])
    block.loops = [(h,r) for h,r in block.loops if '_space_group_symop_operation_xyz' not in h]
    restored = parse_cif_block(block)
    if len(restored.expanded_sites()) != 6 or 'Gemmi table' not in restored.symmetry_source:
        raise ValueError('Missing-symmetry fallback failed')
    lines.append('Missing symmetry fallback PASS')
    for headers, rows in block.loops:
        if '_atom_site_occupancy' in headers:
            rows[0][headers.index('_atom_site_occupancy')] = '0.5'
    partial = parse_cif_block(block)
    try:
        build_supercell(partial)
    except CIFError:
        lines.append('Partial occupancy build protection PASS')
    else:
        raise ValueError('Partial occupancy was not blocked')
    text = ''
    for name in ('PdSe2.cif','MoS2.cif'):
        with open(os.path.join(root,'examples',name),encoding='utf-8') as stream:
            text += stream.read()+'\n'
    try:
        parse_cif_text(text)
    except CIFError as exc:
        if 'Multiple structures' not in str(exc):
            raise
        lines.append('Multiple data-block protection PASS')
    else:
        raise ValueError('Multiple structures were silently combined')
    return '\n'.join(lines)


if __name__ == '__main__':
    print(run_selftest())
