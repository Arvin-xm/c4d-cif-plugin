import math
from pathlib import Path
import unittest
from materials_cif import parse_cif_file,build_supercell
from materials_cif.preview import PreviewData
from materials_cif.view_math import view_frame,axis_directions,paper_layout,preview_coordinates
from materials_cif.display_geometry import dot,cross

ROOT=Path(__file__).resolve().parent.parent


class View070Tests(unittest.TestCase):
    def sample(self,dims=(2,2,2)):
        return build_supercell(parse_cif_file(str(ROOT/'examples/MoS2.cif')),*dims,'AUTO')

    def check_fit(self,layout):
        right,up,forward=layout['frame']; half=layout['field']/2
        for point in layout['points']:
            offset=tuple(p-t for p,t in zip(point,layout['target']))
            for axis in (right,up):
                self.assertLessEqual(abs(dot(offset,axis))+layout['radius'],half*(1-2*layout['padding'])+1e-7)
            self.assertGreater(dot(tuple(p-e for p,e in zip(point,layout['eye'])),forward),0)
        self.assertAlmostEqual(dot(cross(right,up),forward),1.)

    def test_xyz_directions_in_top_front_side_and_rotated_views(self):
        for yaw,pitch in ((0,0),(0,90),(90,90),(35,40),(-90,-35)):
            axes=axis_directions(self.sample(),'XYZ',yaw,pitch)
            self.assertEqual([a['label'] for a in axes],list('XYZ'))
            for a in axes:
                self.assertAlmostEqual(sum(v*v for v in a['projected']),1.)
                self.assertEqual(a['projected'],preview_coordinates(a['vector'],view_frame(yaw,pitch)))
        top=axis_directions(self.sample(),'XYZ',0,0)
        self.assertEqual(top[0]['projected'],(1.,0.,-0.))
        self.assertEqual(top[1]['projected'],(0.,1.,-0.))
        self.assertEqual(top[2]['projected'],(0.,0.,-1.))

    def test_abc_directions_keep_hexagonal_skew_angle(self):
        axes=axis_directions(self.sample(),'ABC',17,33)
        self.assertAlmostEqual(dot(axes[0]['vector'],axes[1]['vector']),-.5)
        self.assertEqual([a['label'] for a in axes],list('ABC'))

    def test_camera_fit_all_views_large_cells_and_cell_corners(self):
        for dims in ((1,1,1),(2,2,2),(1,40,40)):
            for yaw,pitch in ((35,40),(0,0),(0,90),(90,90),(65,-47)):
                self.check_fit(paper_layout(self.sample(dims),scene_scale=1000,atom_margin=15,
                                           include_cell=True,yaw=yaw,pitch=pitch))

    def test_camera_and_preview_share_exact_projected_shape(self):
        built=self.sample()
        data=PreviewData(built,[],make_bonds=False)
        primitives,scale=data.project(800,800,21,17)
        layout=paper_layout(built,scene_scale=20,yaw=21,pitch=17)
        atoms={p['index']:p for p in primitives if p['kind']=='atom'}
        for i in range(1,len(built.atoms)):
            difference=tuple(built.atoms[i].position[k]-built.atoms[0].position[k] for k in range(3))
            dx=dot(difference,layout['frame'][0])
            dy=dot(difference,layout['frame'][1])
            self.assertAlmostEqual((atoms[i]['center'][0]-atoms[0]['center'][0])/scale,dx)
            self.assertAlmostEqual(-(atoms[i]['center'][1]-atoms[0]['center'][1])/scale,dy)

    def test_preview_occlusion_depth_is_negative_camera_forward_distance(self):
        data=PreviewData(self.sample(),[],make_bonds=False)
        primitives,_=data.project(500,400,0,0)
        for p in primitives:
            self.assertAlmostEqual(p['depth'],-data.built.atoms[p['index']].position[2])
        self.assertEqual([p['depth'] for p in primitives],sorted(p['depth'] for p in primitives))

    def test_moved_rotated_scaled_and_sheared_roots_are_fitted(self):
        for columns in (((0,2.,0),(-3.,0,0),(0,0,4.)),((1.,0,0),(.8,2.,0),(.3,.2,1.))):
            layout=paper_layout(self.sample(),model_transform=((500.,-800.,200.),columns),yaw=65,pitch=-21)
            self.check_fit(layout)
            before=paper_layout(self.sample(),model_transform=((0.,0.,0.),columns),yaw=65,pitch=-21)
            self.assertAlmostEqual(layout['field'],before['field'])
            self.assertTrue(all(abs(a-b-c)<1e-7 for a,b,c in zip(layout['target'],before['target'],(500,-800,200))))

    def test_padding_changes_framing_without_changing_angle(self):
        first=paper_layout(self.sample(),padding=.05)
        second=paper_layout(self.sample(),padding=.25)
        self.assertEqual(first['frame'],second['frame'])
        self.assertEqual(first['target'],second['target'])
        self.assertGreater(second['field'],first['field'])

    def test_invalid_camera_or_transform_values_fail_explicitly(self):
        for kwargs in ({'padding':.5},{'scene_scale':0},{'yaw':math.nan},
                       {'model_transform':((0,0,0),((0,0,0),(0,0,0),(0,0,0)))}):
            with self.assertRaises(ValueError): paper_layout(self.sample(),**kwargs)


if __name__=='__main__': unittest.main()
