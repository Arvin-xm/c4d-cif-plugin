// Mandatory Cinema 4D plugin resource header.
enum
{
    IDS_MCV_NAME = 10000,
    _MCV_DUMMY_ELEMENT_
};
