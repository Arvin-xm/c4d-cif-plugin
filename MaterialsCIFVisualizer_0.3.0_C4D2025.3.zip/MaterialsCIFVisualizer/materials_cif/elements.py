"""Element metadata used by Materials CIF Visualizer.

Values are intentionally lightweight and dependency-free. Covalent radii are
approximate single-bond radii in angstrom and are used only for visual bond
inference, not for chemical analysis.
"""

# Approximate covalent radii (Å). Coverage focuses on common materials systems.
COVALENT_RADII = {
    "H": 0.31, "B": 0.84, "C": 0.76, "N": 0.71, "O": 0.66, "F": 0.57,
    "Al": 1.21, "Si": 1.11, "P": 1.07, "S": 1.05, "Cl": 1.02,
    "Ti": 1.60, "V": 1.53, "Cr": 1.39, "Mn": 1.39, "Fe": 1.32,
    "Co": 1.26, "Ni": 1.24, "Cu": 1.32, "Zn": 1.22,
    "Ga": 1.22, "Ge": 1.20, "As": 1.19, "Se": 1.20, "Br": 1.20,
    "Zr": 1.75, "Nb": 1.64, "Mo": 1.54, "Tc": 1.47, "Ru": 1.46,
    "Rh": 1.42, "Pd": 1.39, "Ag": 1.45, "Cd": 1.44,
    "In": 1.42, "Sn": 1.39, "Sb": 1.39, "Te": 1.38, "I": 1.39,
    "Hf": 1.75, "Ta": 1.70, "W": 1.62, "Re": 1.51, "Os": 1.44,
    "Ir": 1.41, "Pt": 1.36, "Au": 1.36, "Hg": 1.32,
    "Pb": 1.46, "Bi": 1.48,
}

# Visual sphere radii (Å-like relative values). These are deliberately more
# uniform than van der Waals radii for clean scientific schematics.
VISUAL_RADII = {
    "H": 0.35, "B": 0.62, "C": 0.62, "N": 0.60, "O": 0.58,
    "S": 0.82, "Se": 0.88, "Te": 0.96,
    "Mo": 0.95, "W": 0.98, "Pd": 0.92, "Pt": 0.92,
    "Ti": 0.93, "V": 0.91, "Cr": 0.90, "Fe": 0.88, "Co": 0.86,
    "Ni": 0.85, "Cu": 0.88, "Zn": 0.90,
}

# Neutral, publication-friendly RGB colors in 0..1. Users can replace these
# with their own V-Ray materials after import.
ELEMENT_COLORS = {
    "H": (0.95, 0.95, 0.95),
    "B": (0.95, 0.58, 0.48),
    "C": (0.22, 0.24, 0.28),
    "N": (0.25, 0.40, 0.88),
    "O": (0.85, 0.20, 0.18),
    "S": (0.95, 0.78, 0.18),
    "Se": (0.88, 0.40, 0.22),
    "Te": (0.63, 0.32, 0.68),
    "Mo": (0.24, 0.54, 0.76),
    "W": (0.22, 0.46, 0.60),
    "Pd": (0.64, 0.70, 0.76),
    "Pt": (0.68, 0.70, 0.72),
    "Ti": (0.50, 0.60, 0.67),
    "V": (0.43, 0.58, 0.62),
    "Cr": (0.50, 0.50, 0.58),
    "Fe": (0.74, 0.35, 0.20),
    "Co": (0.60, 0.42, 0.65),
    "Ni": (0.45, 0.62, 0.50),
    "Cu": (0.78, 0.45, 0.25),
    "Zn": (0.55, 0.60, 0.72),
}

DEFAULT_COVALENT_RADIUS = 0.85
DEFAULT_VISUAL_RADIUS = 0.78
DEFAULT_COLOR = (0.55, 0.62, 0.70)
