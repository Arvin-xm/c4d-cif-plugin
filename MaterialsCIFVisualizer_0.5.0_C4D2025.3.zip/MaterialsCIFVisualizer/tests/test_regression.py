import math
import os
import unittest
from materials_cif import parse_cif_file, build_supercell, structure_summary
from materials_cif.cif_parser import apply_symmetry_op, CIFError
from mcv_selftest import run_selftest

ROOT = os.path.dirname(os.path.dirname(__file__))


class RegressionTests(unittest.TestCase):
    def structure(self, name):
        return parse_cif_file(os.path.join(ROOT, 'examples', name + '.cif'))

    def check_sites(self, actual, expected):
        self.assertEqual(len(actual), len(expected))
        for element, point in expected:
            matches = [s for s in actual if s.element == element and
                       all(abs(a-b) < 1e-6 for a, b in zip(s.fract, point))]
            self.assertEqual(len(matches), 1, (element, point))

    def test_pdse2_expanded_fractional_coordinates(self):
        self.check_sites(self.structure('PdSe2').expanded_sites(), [
            ('Pd', (0, 0, .5)), ('Pd', (0, .5, 0)),
            ('Se', (.037085, .109335, .881234)),
            ('Se', (.962915, .890665, .118766)),
            ('Se', (.962915, .609335, .618766)),
            ('Se', (.037085, .390665, .381234)),
        ])

    def test_mos2_expanded_fractional_coordinates(self):
        self.check_sites(self.structure('MoS2').expanded_sites(), [
            ('Mo', (1/3, 2/3, .75)), ('Mo', (2/3, 1/3, .25)),
            ('S', (1/3, 2/3, .133082)), ('S', (2/3, 1/3, .866918)),
            ('S', (2/3, 1/3, .633082)), ('S', (1/3, 2/3, .366918)),
        ])

    def test_hexagonal_and_monoclinic_cell_geometry(self):
        for name, expected_volume in (('MoS2', 118.06518982), ('PdSe2', 670.499437)):
            s = self.structure(name)
            a, b, c = s.lattice_vectors()
            volume = a[0] * b[1] * c[2]
            # The supplied PdSe2 cell lengths are rounded; the declared volume
            # differs by 0.00011171 A^3 from their determinant.
            self.assertAlmostEqual(volume, expected_volume, delta=0.0002)
            for v, length in zip((a, b, c), (s.a, s.b, s.c)):
                self.assertAlmostEqual(math.sqrt(sum(x*x for x in v)), length, places=7)
        s = self.structure('MoS2')
        a, b, c = s.lattice_vectors()
        self.assertAlmostEqual(sum(x*y for x, y in zip(a, b))/(s.a*s.b), -.5)

    def test_centering_and_supercell_vectors(self):
        for name in ('MoS2', 'PdSe2'):
            s = self.structure(name)
            base = build_supercell(s, 1, 1, 1, 'AUTO')
            built = build_supercell(s, 2, 3, 1, 'AUTO')
            self.assertEqual(len(built.atoms), 36)
            for vector, original, n in zip(built.cell_vectors, base.cell_vectors, (2, 3, 1)):
                for a, b in zip(vector, original): self.assertAlmostEqual(a, b*n)
            for axis in range(3):
                values = [a.position[axis] for a in built.atoms]
                self.assertAlmostEqual(min(values) + max(values), 0.)

    def test_symmetry_expression_cannot_execute_python(self):
        with self.assertRaises(CIFError):
            apply_symmetry_op("__import__('os').system('echo unsafe'),y,z", (0, 0, 0))

    def test_packaged_selftest(self):
        result = run_selftest(ROOT)
        self.assertIn('PdSe2.cif PASS', result)
        self.assertIn('MoS2.cif PASS', result)


if __name__ == '__main__':
    unittest.main()
