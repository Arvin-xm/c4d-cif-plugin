"""Classic V-Ray API, checked against this installation's official .h resources.

No V-Ray binaries or headers are redistributed. IDs originate in res/c4d_symbols.h,
description/vray_material_vraymtl.h and description/vray_light_rectangle.h.
Runtime parameter checks reject unavailable versions instead of silent fallback.
"""
import c4d
from mcv_diagnostics import log

RENDERER = 1053272
MATERIAL = 1053286
RECTANGLE = 1053280
DIFFUSE = 2131196938
REFLECT = 2035585782
GLOSSINESS = 451657623
USE_ROUGHNESS = 1975159604
FRESNEL = 387677919
FRESNEL_IOR = 952417178
LIGHT_ENABLED = 704346727
LIGHT_COLOR = 856352012
LIGHT_INTENSITY = 730851887
LIGHT_UNITS = 950775895
LIGHT_U = 1120121198
LIGHT_V = 1720158087
LIGHT_INVISIBLE = 1035877262
LIGHT_DOUBLE_SIDED = 1466354749
LIGHT_SHADOWS = 1853815298
USE_VFB_OUTPUT = 1000401
OUTPUT_FILENAME = 1000403
OUTPUT_FORMAT = 1000404
PNG_BITS = 2035694711
OUTPUT_NO_ALPHA = 1187290011
OUTPUT_SEPARATE_ALPHA = 220461834


def available():
    return all(c4d.plugins.FindPlugin(pid, kind) is not None for pid, kind in (
        (RENDERER, c4d.PLUGINTYPE_VIDEOPOST),
        (MATERIAL, c4d.PLUGINTYPE_MATERIAL),
        (RECTANGLE, c4d.PLUGINTYPE_OBJECT)))


def _set(obj, pid, value):
    if obj[pid] is None:
        raise RuntimeError('V-Ray parameter {} is unavailable in this version.'.format(pid))
    obj[pid] = value


def create_material(rgb):
    if not available():
        raise RuntimeError('V-Ray renderer/material/rectangle light plugins are not all loaded.')
    mat = c4d.BaseMaterial(MATERIAL)
    if mat is None:
        raise RuntimeError('Cannot allocate a native V-Ray material.')
    _set(mat, DIFFUSE, c4d.Vector(*rgb))
    _set(mat, REFLECT, c4d.Vector(0.3, 0.3, 0.3))
    _set(mat, USE_ROUGHNESS, False)
    _set(mat, GLOSSINESS, 0.65)
    _set(mat, FRESNEL, True)
    _set(mat, FRESNEL_IOR, 1.45)
    return mat


def create_light(size, intensity, rgb):
    light = c4d.BaseObject(RECTANGLE)
    if light is None:
        raise RuntimeError('Cannot allocate a native V-Ray rectangle light.')
    for pid, value in (
        (LIGHT_ENABLED, True), (LIGHT_COLOR, c4d.Vector(*rgb)),
        (LIGHT_UNITS, 0), (LIGHT_INTENSITY, intensity),
        (LIGHT_U, size), (LIGHT_V, size), (LIGHT_INVISIBLE, True),
        (LIGHT_DOUBLE_SIDED, True), (LIGHT_SHADOWS, True)):
        _set(light, pid, value)
    return light


def preflight(lights=False):
    create_material((0.5, 0.5, 0.5))
    if lights:
        create_light(100.0, 1.0, (1.0, 1.0, 1.0))
        post = c4d.documents.BaseVideoPost(RENDERER)
        if post is None:
            raise RuntimeError('Cannot allocate V-Ray render settings.')
        for pid, value in ((OUTPUT_NO_ALPHA, False), (OUTPUT_SEPARATE_ALPHA, False),
                           (OUTPUT_FORMAT, 0), (PNG_BITS, 8), (USE_VFB_OUTPUT, False)):
            _set(post, pid, value)
    log('VRAY_API_OK', 'material={} rectangle={} renderer={}'.format(MATERIAL, RECTANGLE, RENDERER))


def enable_renderer(doc, output_path=None):
    rd = doc.GetActiveRenderData()
    post = rd.GetFirstVideoPost()
    while post is not None and post.GetType() != RENDERER:
        post = post.GetNext()
    if post is None:
        post = c4d.documents.BaseVideoPost(RENDERER)
        if post is None:
            raise RuntimeError('Cannot allocate V-Ray render settings.')
        rd.InsertVideoPostLast(post)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, post)
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, rd)
    rd[c4d.RDATA_RENDERENGINE] = RENDERER
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, post)
    for pid, value in ((OUTPUT_NO_ALPHA, False), (OUTPUT_SEPARATE_ALPHA, False),
                       (OUTPUT_FORMAT, 0), (PNG_BITS, 8), (USE_VFB_OUTPUT, bool(output_path))):
        _set(post, pid, value)
    if output_path:
        _set(post, OUTPUT_FILENAME, output_path)
    log('VRAY_RENDERER_ENABLED')
