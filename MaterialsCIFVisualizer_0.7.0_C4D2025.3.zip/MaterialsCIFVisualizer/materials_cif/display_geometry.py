"""Slab selection and explicit periodic neighbors, in Angstroms, without C4D."""
from dataclasses import dataclass, replace
from itertools import product
import math

from .bonds import Bond, bond_limits, infer_bonds


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def reciprocal(vectors):
    a, b, c = vectors
    volume = dot(a, cross(b, c))
    if not math.isfinite(volume) or abs(volume) < 1e-10:
        raise ValueError('晶胞体积无效，无法计算周期邻居。')
    return tuple(tuple(x/volume for x in v) for v in (cross(b,c),cross(c,a),cross(a,b)))


def slab_normal(built, axis='Z'):
    if axis == 'Z':
        return (0.0, 0.0, 1.0)
    if axis not in ('A', 'B', 'C'):
        raise ValueError('Unknown slab normal.')
    v = reciprocal(built.cell_vectors)['ABC'.index(axis)]
    size = math.sqrt(dot(v,v))
    return tuple(x/size for x in v)


def layers(atoms, normal, gap):
    """Cluster sorted atomic planes by gaps, not by element or cell index."""
    if not math.isfinite(gap) or gap <= 0:
        raise ValueError('层间分组阈值必须为正数 (Å)。')
    groups = []
    for height in sorted(dot(a.position, normal) for a in atoms):
        if not groups or height-groups[-1][-1] > gap+1e-8:
            groups.append([])
        groups[-1].append(height)
    return [(g[0],g[-1]) for g in groups]


@dataclass
class DisplayResult:
    built: object
    bonds: list
    selected_count: int
    image_count: int
    layer_count: int
    note: str


def display_structure(base, *, crop='off', normal='Z', center=0.0,
                      thickness=5.0, layer=1, layer_gap=2.5,
                      periodic_axes=(False,False,False), make_bonds=True,
                      bond_options=None, max_atoms=10000):
    """Crop original atom centers, then add bonded images within that slab.

    A/B/C refer to lattice directions, Z to the current aligned Cartesian frame.
    Reciprocal bounds cover skew cells and cutoffs spanning multiple cells.
    Images join originals only; never add image-image contacts or cut across a
    removed layer. Unit-cell edges still describe the original supercell.
    """
    if crop not in ('off','thickness','layer'):
        raise ValueError('Unknown crop mode.')
    if len(periodic_axes) != 3 or any(type(x) is not bool for x in periodic_axes):
        raise ValueError('Choose three periodic axis flags.')
    options = dict(bond_options or {})
    n = slab_normal(base,normal)
    groups = layers(base.atoms,n,layer_gap) if crop == 'layer' else []
    lo, hi = -math.inf, math.inf
    if crop == 'thickness':
        if not all(math.isfinite(v) for v in (center,thickness)) or thickness <= 0:
            raise ValueError('裁切中心须为有限数，厚度须大于零 (Å)。')
        lo, hi = center-thickness/2, center+thickness/2
    elif crop == 'layer':
        if type(layer) is not int or not 1 <= layer <= len(groups):
            raise ValueError('本结构识别到 {} 层，请选择 1–{}。'.format(len(groups),len(groups)))
        lo, hi = groups[layer-1]
    def inside(atom):
        return lo-1e-7 <= dot(atom.position,n) <= hi+1e-7
    anchors = [a for a in base.atoms if inside(a)]
    if not anchors:
        raise ValueError('裁切范围内没有原子，请调整中心、厚度或层号。')
    if len(anchors) > max_atoms:
        raise ValueError('显示原子超过 {} 上限。'.format(max_atoms))
    atoms = list(anchors)
    count = len(atoms)
    limits = bond_limits(base.atoms, **options) if make_bonds else {}
    if any(periodic_axes) and limits:
        cutoff = max(v[2] for v in limits.values())
        dual = reciprocal(base.cell_vectors)
        # Two fractional points in one supercell differ by less than one.
        spans = [math.ceil(1+cutoff*math.sqrt(dot(v,v))) if flag else 0
                 for v,flag in zip(dual,periodic_axes)]
        if math.prod(2*s+1 for s in spans) > 50000:
            raise ValueError('周期搜索范围过大，请缩短键长或减少周期方向。')
        amin = [min(a.position[k] for a in anchors)-cutoff-1e-7 for k in range(3)]
        amax = [max(a.position[k] for a in anchors)+cutoff+1e-7 for k in range(3)]
        bmin = [min(a.position[k] for a in base.atoms) for k in range(3)]
        bmax = [max(a.position[k] for a in base.atoms) for k in range(3)]
        examined = 0
        dims = [max(a.cell_index[k] for a in base.atoms)+1 for k in range(3)]
        for image in product(*(range(-s,s+1) for s in spans)):
            if image == (0,0,0):
                continue
            shift = tuple(sum(image[j]*base.cell_vectors[j][k] for j in range(3)) for k in range(3))
            if any(bmax[k]+shift[k] < amin[k] or bmin[k]+shift[k] > amax[k] for k in range(3)):
                continue
            examined += len(base.atoms)
            if examined > 1000000:
                raise ValueError('周期候选过多，请缩小超胞或缩短键长。')
            for atom in base.atoms:
                pos = tuple(atom.position[k]+shift[k] for k in range(3))
                if any(pos[k] < amin[k] or pos[k] > amax[k] for k in range(3)):
                    continue
                candidate = replace(atom,position=pos,periodic_image=image,
                    cell_index=tuple(atom.cell_index[k]+image[k]*dims[k] for k in range(3)),
                    label=atom.label+' [periodic {} {} {}]'.format(*image))
                if inside(candidate):
                    atoms.append(candidate)
                    if len(atoms) > 40000:
                        raise ValueError('周期候选原子超过 40,000，请缩小超胞或缩短键长。')
    bonds = infer_bonds(atoms,anchor_count=count,**options) if make_bonds else []
    used = set(range(count))
    for bond in bonds:
        used.update((bond.i,bond.j))
    indices = sorted(used)
    if len(indices) > max_atoms:
        raise ValueError('原子加周期邻居超过 {} 上限，请缩小超胞。'.format(max_atoms))
    mapping = {old:new for new,old in enumerate(indices)}
    final = replace(base,atoms=[atoms[i] for i in indices])
    bonds = [Bond(mapping[b.i],mapping[b.j],b.distance) for b in bonds]
    images = len(final.atoms)-count
    note = '保留原子：{} / {}；周期邻居：{}。'.format(count,len(base.atoms),images)
    if crop == 'layer':
        note += '\n层号：{} / {}；法向 {}，中心范围 {:.3f}–{:.3f} Å。'.format(layer,len(groups),normal,lo,hi)
    elif crop == 'thickness':
        note += '\n法向 {}，裁切范围 {:.3f}–{:.3f} Å。'.format(normal,lo,hi)
    if any(periodic_axes):
        note += '\n周期方向：{}；仅补充与保留原子相连的邻居。'.format('、'.join(a for a,f in zip('ABC',periodic_axes) if f))
        if not make_bonds:
            note += ' 距离键关闭，未补充邻居。'
    return DisplayResult(final,bonds,count,images,len(groups),note)
