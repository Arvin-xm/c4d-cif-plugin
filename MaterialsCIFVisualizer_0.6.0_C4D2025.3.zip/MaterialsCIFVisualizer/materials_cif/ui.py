"""Cinema 4D GeDialog UI for Materials CIF Visualizer."""
from __future__ import annotations

import os
import time
from itertools import combinations_with_replacement
from collections import Counter
import c4d
from mcv_diagnostics import log, log_exception, LOG_PATH

from . import parse_cif_block, load_cif_document, structure_summary, build_supercell, infer_bonds
from .validation import validation_report
from .bonds import default_cutoff, bond_report
from .elements import ELEMENT_COLORS, VISUAL_RADII, DEFAULT_COLOR, DEFAULT_VISUAL_RADIUS
from .c4d_builder import build_scene, setup_paper_scene, model_root
from .display_geometry import display_structure
from .preview import PreviewData
from .preview_area import StructurePreview


class MaterialsCIFDialog(c4d.gui.GeDialog):
    ID_PATH = 1001
    ID_BROWSE = 1002
    ID_SUMMARY = 1003
    ID_BLOCK = 1004
    ID_VALIDATION = 1005
    ID_NX = 1010
    ID_NY = 1011
    ID_NZ = 1012
    ID_ATOMS = 1020
    ID_BONDS = 1021
    ID_CELL = 1022
    ID_ATOM_SCALE = 1030
    ID_BOND_RADIUS = 1031
    ID_BOND_TOL = 1032
    ID_SCENE_SCALE = 1033
    ID_AXIS = 1040
    ID_BUILD = 1050
    ID_PAPER = 1051
    ID_RELOAD = 1052
    ID_SELFTEST = 1053
    ID_SEGMENTS = 1060
    ID_INSTANCE = 1061
    ID_ELEMENT = 1070
    ID_COLOR = 1071
    ID_RADIUS = 1072
    ID_PAIR = 1080
    ID_PAIR_SHOW = 1081
    ID_PAIR_AUTO = 1082
    ID_PAIR_MIN = 1083
    ID_PAIR_MAX = 1084
    ID_PRESET = 1085
    ID_BOND_REPORT = 1086
    ID_RENDERER = 1090
    ID_RESOLUTION = 1091
    ID_OUTPUT = 1092
    ID_OUTPUT_BROWSE = 1093
    ID_PREVIEW = 1100
    ID_PREVIEW_AUTO = 1101
    ID_PREVIEW_REFRESH = 1102
    ID_PREVIEW_STATS = 1103
    ID_VIEW_3D = 1110
    ID_VIEW_TOP = 1111
    ID_VIEW_FRONT = 1112
    ID_VIEW_SIDE = 1113
    ID_ZOOM_OUT = 1114
    ID_ZOOM_IN = 1115
    ID_ZOOM_FIT = 1116
    ID_LABELS = 1117
    ID_UPDATE = 1120
    ID_PERIODIC = 1130
    ID_PERIODIC_A = 1131
    ID_PERIODIC_B = 1132
    ID_PERIODIC_C = 1133
    ID_CROP = 1140
    ID_CROP_NORMAL = 1141
    ID_CROP_CENTER = 1142
    ID_CROP_THICKNESS = 1143
    ID_CROP_LAYER = 1144
    ID_LAYER_GAP = 1145

    def __init__(self):
        super().__init__()
        self.structure = None
        self.built = None
        self.last_path = ""
        self.blocks = []
        self.elements, self.pairs = [], []
        self.element_styles, self.pair_rules = {}, {}
        self.active_element = self.active_pair = None
        self.preview = StructurePreview()
        self.preview_data = None
        self._preview_due = None
        self._built_key = self._built_cache = None
        self._display_key = self._display_cache = None
        self._last_model = None

    def CreateLayout(self):
        log('LAYOUT_START')
        self.SetTitle('Materials CIF Visualizer 0.6.0')
        self.GroupBegin(2000, c4d.BFH_SCALEFIT, 1, 0, 'CIF Structure')
        self.GroupBegin(2001, c4d.BFH_SCALEFIT, 2, 1, '')
        self.AddEditText(self.ID_PATH, c4d.BFH_SCALEFIT)
        self.AddButton(self.ID_BROWSE, c4d.BFH_RIGHT, name='Browse…')
        self.GroupEnd()
        self.GroupBegin(2002, c4d.BFH_SCALEFIT, 2, 1, '')
        self.AddComboBox(self.ID_BLOCK, c4d.BFH_SCALEFIT)
        self.AddChild(self.ID_BLOCK, 0, 'Select a CIF first')
        self.AddButton(self.ID_VALIDATION, c4d.BFH_RIGHT, name='Validation report')
        self.GroupEnd()
        self.AddStaticText(self.ID_SUMMARY, c4d.BFH_SCALEFIT, name='No CIF loaded')
        self.GroupEnd()

        self.GroupBegin(3000, c4d.BFH_SCALEFIT|c4d.BFV_SCALEFIT, 2, 0, '')
        self.TabGroupBegin(2600, c4d.BFH_SCALEFIT|c4d.BFV_SCALEFIT)
        self.GroupBegin(2601, c4d.BFH_SCALEFIT, 1, 0, '建模')
        self.GroupBegin(2100, c4d.BFH_SCALEFIT, 6, 1, 'Supercell')
        for label, gadget, static in (('Nx', self.ID_NX, 2101), ('Ny', self.ID_NY, 2102), ('Nz', self.ID_NZ, 2103)):
            self.AddStaticText(static, c4d.BFH_LEFT, name=label)
            self.AddEditNumberArrows(gadget, c4d.BFH_SCALEFIT)
        self.GroupEnd()
        self.GroupBegin(2200, c4d.BFH_SCALEFIT, 3, 1, 'Geometry')
        for gadget, label in ((self.ID_ATOMS, '原子'), (self.ID_BONDS, '距离键'), (self.ID_CELL, '晶胞边框')):
            self.AddCheckbox(gadget, c4d.BFH_LEFT, 0, 0, label)
        self.GroupEnd()
        self.GroupBegin(2300, c4d.BFH_SCALEFIT, 2, 0, 'Style')
        for static, label, gadget in (
            (2301, '原子大小倍率', self.ID_ATOM_SCALE), (2302, '键半径 (Å)', self.ID_BOND_RADIUS),
            (2303, '自动键长倍率', self.ID_BOND_TOL), (2304, '场景单位 / Å', self.ID_SCENE_SCALE),
            (2305, '球体分段 (16–128)', self.ID_SEGMENTS)):
            self.AddStaticText(static, c4d.BFH_LEFT, name=label)
            self.AddEditNumberArrows(gadget, c4d.BFH_SCALEFIT)
        self.AddStaticText(2306, c4d.BFH_LEFT, name='原子实例')
        self.AddComboBox(self.ID_INSTANCE, c4d.BFH_SCALEFIT)
        for index, label in enumerate(('渲染实例：每种元素共享球体', '普通实例', '独立球体')):
            self.AddChild(self.ID_INSTANCE, index, label)
        self.AddStaticText(2401, c4d.BFH_LEFT, name='层法向 / 真空方向')
        self.AddComboBox(self.ID_AXIS, c4d.BFH_SCALEFIT)
        for index, label in enumerate(('自动（原子间隙检测）', 'A → Z', 'B → Z', 'C → Z', '原始笛卡尔坐标')):
            self.AddChild(self.ID_AXIS, index, label)
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(2602, c4d.BFH_SCALEFIT, 1, 0, '元素与键')
        self.GroupBegin(2700, c4d.BFH_SCALEFIT, 2, 0, '元素外观')
        self.AddStaticText(2701, c4d.BFH_LEFT, name='元素')
        self.AddComboBox(self.ID_ELEMENT, c4d.BFH_SCALEFIT)
        self.AddStaticText(2702, c4d.BFH_LEFT, name='颜色（原子与该端的半键）')
        self.AddColorField(self.ID_COLOR, c4d.BFH_SCALEFIT, 0, 20)
        self.AddStaticText(2703, c4d.BFH_LEFT, name='显示球半径 (Å)，另乘大小倍率')
        self.AddEditNumberArrows(self.ID_RADIUS, c4d.BFH_SCALEFIT)
        self.GroupEnd()
        self.GroupBegin(2800, c4d.BFH_SCALEFIT, 2, 0, '距离键规则')
        self.AddStaticText(2801, c4d.BFH_LEFT, name='显示组合')
        self.AddComboBox(self.ID_PRESET, c4d.BFH_SCALEFIT)
        for index, label in enumerate(('所有元素对', '仅异种元素', 'Mo–S only', 'Pd–Se + Se–Se')):
            self.AddChild(self.ID_PRESET, index, label)
        self.AddStaticText(2802, c4d.BFH_LEFT, name='元素对（可分别设置）')
        self.AddComboBox(self.ID_PAIR, c4d.BFH_SCALEFIT)
        self.AddCheckbox(self.ID_PAIR_SHOW, c4d.BFH_LEFT, 0, 0, '显示此元素对')
        self.AddCheckbox(self.ID_PAIR_AUTO, c4d.BFH_LEFT, 0, 0, '按共价半径估算范围')
        self.AddStaticText(2803, c4d.BFH_LEFT, name='最短距离 (Å)')
        self.AddEditNumberArrows(self.ID_PAIR_MIN, c4d.BFH_SCALEFIT)
        self.AddStaticText(2804, c4d.BFH_LEFT, name='最长距离 (Å)')
        self.AddEditNumberArrows(self.ID_PAIR_MAX, c4d.BFH_SCALEFIT)
        self.GroupEnd()
        self.AddStaticText(2805, c4d.BFH_SCALEFIT, name='距离键是可视化推断；显示半径不影响成键。')
        self.AddButton(self.ID_BOND_REPORT, c4d.BFH_SCALEFIT, name='查看当前键长统计')
        self.GroupEnd()

        self.GroupBegin(2604,c4d.BFH_SCALEFIT,1,0,'边界与裁切')
        self.AddCheckbox(self.ID_PERIODIC,c4d.BFH_LEFT,0,0,'补充周期边界邻居（按当前键长）')
        self.GroupBegin(3200,c4d.BFH_SCALEFIT,3,1,'周期方向')
        for gadget,label in ((self.ID_PERIODIC_A,'A'),(self.ID_PERIODIC_B,'B'),(self.ID_PERIODIC_C,'C')):
            self.AddCheckbox(gadget,c4d.BFH_LEFT,0,0,label)
        self.GroupEnd()
        self.GroupBegin(3201,c4d.BFH_SCALEFIT,2,0,'按原子中心裁切')
        self.AddStaticText(3210,c4d.BFH_LEFT,name='裁切方式')
        self.AddComboBox(self.ID_CROP,c4d.BFH_SCALEFIT)
        for i,label in enumerate(('不裁切','指定厚度','选择一层')):
            self.AddChild(self.ID_CROP,i,label)
        self.AddStaticText(3211,c4d.BFH_LEFT,name='裁切法向')
        self.AddComboBox(self.ID_CROP_NORMAL,c4d.BFH_SCALEFIT)
        for i,label in enumerate(('当前 Z 轴','A 晶面法向（垂直 B、C）','B 晶面法向（垂直 C、A）','C 晶面法向（垂直 A、B）')):
            self.AddChild(self.ID_CROP_NORMAL,i,label)
        for static,label,gadget in ((3212,'中心位置 (Å)',self.ID_CROP_CENTER),
                                   (3213,'厚度 (Å)',self.ID_CROP_THICKNESS),
                                   (3214,'层号（从负方向数起）',self.ID_CROP_LAYER),
                                   (3215,'分层间隙阈值 (Å)',self.ID_LAYER_GAP)):
            self.AddStaticText(static,c4d.BFH_LEFT,name=label)
            self.AddEditNumberArrows(gadget,c4d.BFH_SCALEFIT)
        self.GroupEnd()
        self.AddStaticText(3216,c4d.BFH_SCALEFIT,name='大于阈值的相邻原子面间隙分为不同层；请核对预览。')
        self.AddStaticText(3217,c4d.BFH_SCALEFIT,name='周期邻居只连接保留原子；裁切后不补回范围外的层。')
        self.AddStaticText(3218,c4d.BFH_SCALEFIT,name='晶胞边框保持原超胞尺寸；球体按中心筛选，不切开球面。')
        self.GroupEnd()

        self.GroupBegin(2603, c4d.BFH_SCALEFIT, 2, 0, '出图')
        self.AddStaticText(2901, c4d.BFH_LEFT, name='材质与灯光')
        self.AddComboBox(self.ID_RENDERER, c4d.BFH_SCALEFIT)
        for index, label in enumerate(('自动（已加载 V-Ray 时优先）', 'C4D 标准', 'V-Ray 原生')):
            self.AddChild(self.ID_RENDERER, index, label)
        self.AddStaticText(2902, c4d.BFH_LEFT, name='正方形 PNG 边长 (px)')
        self.AddEditNumberArrows(self.ID_RESOLUTION, c4d.BFH_SCALEFIT)
        self.AddStaticText(2903, c4d.BFH_LEFT, name='输出路径（可留空）')
        self.AddEditText(self.ID_OUTPUT, c4d.BFH_SCALEFIT)
        self.AddStaticText(2904, c4d.BFH_LEFT, name='PNG 包含透明通道；预设切换至所选渲染器。')
        self.AddButton(self.ID_OUTPUT_BROWSE, c4d.BFH_RIGHT, name='选择 PNG 保存位置…')
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(3100, c4d.BFH_SCALEFIT|c4d.BFV_SCALEFIT, 1, 0, '结构预览')
        self.AddUserArea(self.ID_PREVIEW, c4d.BFH_SCALEFIT|c4d.BFV_SCALEFIT, 440, 340)
        if not self.AttachUserArea(self.preview,self.ID_PREVIEW):
            raise RuntimeError('Cannot attach structure preview area.')
        self.GroupBegin(3101,c4d.BFH_SCALEFIT,7,1,'')
        for gadget,label in ((self.ID_VIEW_3D,'3D'),(self.ID_VIEW_TOP,'俯视'),(self.ID_VIEW_FRONT,'正视'),
                             (self.ID_VIEW_SIDE,'侧视'),(self.ID_ZOOM_OUT,'−'),(self.ID_ZOOM_IN,'＋'),(self.ID_ZOOM_FIT,'适配')):
            self.AddButton(gadget,c4d.BFH_SCALEFIT,name=label)
        self.GroupEnd()
        self.GroupBegin(3102,c4d.BFH_SCALEFIT,3,1,'')
        self.AddCheckbox(self.ID_PREVIEW_AUTO,c4d.BFH_LEFT,0,0,'自动刷新')
        self.AddCheckbox(self.ID_LABELS,c4d.BFH_LEFT,0,0,'原子标签（≤200）')
        self.AddButton(self.ID_PREVIEW_REFRESH,c4d.BFH_RIGHT,name='刷新预览')
        self.GroupEnd()
        self.AddMultiLineEditText(self.ID_PREVIEW_STATS,c4d.BFH_SCALEFIT,440,105,style=c4d.DR_MULTILINE_READONLY)
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(2500, c4d.BFH_SCALEFIT, 5, 1, '')
        self.AddButton(self.ID_RELOAD, c4d.BFH_LEFT, name='Reload CIF')
        self.AddButton(self.ID_BUILD, c4d.BFH_SCALEFIT, name='新建模型')
        self.AddButton(self.ID_UPDATE,c4d.BFH_SCALEFIT,name='更新已有模型')
        self.AddButton(self.ID_PAPER, c4d.BFH_RIGHT, name='应用出图预设')
        self.AddButton(self.ID_SELFTEST, c4d.BFH_RIGHT, name='Self-test')
        self.GroupEnd()
        log('LAYOUT_OK')
        return True

    def InitValues(self):
        self.SetInt32(self.ID_NX, 1, min=1, max=50, step=1)
        self.SetInt32(self.ID_NY, 1, min=1, max=50, step=1)
        self.SetInt32(self.ID_NZ, 1, min=1, max=50, step=1)
        self.SetBool(self.ID_ATOMS, True)
        self.SetBool(self.ID_BONDS, True)
        self.SetBool(self.ID_CELL, False)
        self.SetFloat(self.ID_ATOM_SCALE, 0.70, min=0.05, max=3.0, step=0.05)
        self.SetFloat(self.ID_BOND_RADIUS, 0.08, min=0.01, max=1.0, step=0.01)
        self.SetFloat(self.ID_BOND_TOL, 1.18, min=0.5, max=2.5, step=0.01)
        self.SetFloat(self.ID_SCENE_SCALE, 20.0, min=0.1, max=1000.0, step=1.0)
        self.SetInt32(self.ID_AXIS, 0)
        self.SetInt32(self.ID_BLOCK, 0)
        self.SetInt32(self.ID_SEGMENTS, 64, min=16, max=128, step=8)
        self.SetInt32(self.ID_INSTANCE, 0)
        self.SetInt32(self.ID_PRESET, 0)
        self.SetInt32(self.ID_RENDERER, 0)
        self.SetInt32(self.ID_RESOLUTION, 3000, min=256, max=8192, step=256)
        self.SetFloat(self.ID_RADIUS, 0.8, min=0.05, max=5.0, step=0.05)
        self.SetFloat(self.ID_PAIR_MIN, 0.35, min=0.35, max=20.0, step=0.05)
        self.SetFloat(self.ID_PAIR_MAX, 3.0, min=0.35, max=20.0, step=0.05)
        self.SetColorField(self.ID_COLOR, c4d.Vector(*DEFAULT_COLOR), 1.0, 1.0, 0)
        self.SetBool(self.ID_PREVIEW_AUTO, True)
        self.SetBool(self.ID_LABELS, False)
        self.SetBool(self.ID_PERIODIC,False)
        for gadget in (self.ID_PERIODIC_A,self.ID_PERIODIC_B,self.ID_PERIODIC_C):
            self.SetBool(gadget,True)
        self.SetInt32(self.ID_CROP,0)
        self.SetInt32(self.ID_CROP_NORMAL,0)
        self.SetFloat(self.ID_CROP_CENTER,0.0,min=-10000.0,max=10000.0,step=.1)
        self.SetFloat(self.ID_CROP_THICKNESS,5.0,min=.01,max=10000.0,step=.1)
        self.SetInt32(self.ID_CROP_LAYER,1,min=1,max=10000,step=1)
        self.SetFloat(self.ID_LAYER_GAP,2.5,min=.01,max=100.0,step=.1)
        self._enable_crop_controls()
        self.SetString(self.ID_PREVIEW_STATS,'选择 CIF，调整参数后预览自动更新。\n确认后点击“新建模型”或“更新已有模型”。')
        self.Enable(self.ID_BUILD, False)
        self.Enable(self.ID_PAPER, False)
        log('INIT_VALUES_OK')
        return True

    def _axis_value(self):
        return {0: "AUTO", 1: "A", 2: "B", 3: "C", 4: "NONE"}.get(self.GetInt32(self.ID_AXIS), "AUTO")

    def _load(self, path):
        self._clear_preview('正在读取 CIF…')
        try:
            log('CIF_LOAD_START', path)
            self.structure = None
            self.built = None
            self.blocks = load_cif_document(path)
            self.last_path = path
            self.SetString(self.ID_PATH, path)
            self.FreeChildren(self.ID_BLOCK)
            self.AddChild(self.ID_BLOCK, 0, "Choose a structure ({})".format(len(self.blocks)))
            for index, block in enumerate(self.blocks, 1):
                self.AddChild(self.ID_BLOCK, index, 'data_' + block.name)
            if len(self.blocks) > 1:
                self.SetInt32(self.ID_BLOCK, 0)
                self.SetString(self.ID_SUMMARY, 'Multiple structures: choose a data block above.')
                self.Enable(self.ID_BUILD, False)
                self.Enable(self.ID_PAPER, False)
                self.preview.clear('此文件包含多个结构，请选择数据块')
                log('BLOCK_SELECTION_REQUIRED', ', '.join(b.name for b in self.blocks))
                return False
            self.SetInt32(self.ID_BLOCK, 1)
            return self._select_block(1)
        except Exception as exc:
            self.structure = None
            self.built = None
            self.blocks = []
            self.FreeChildren(self.ID_BLOCK)
            self.AddChild(self.ID_BLOCK, 0, 'No usable structure')
            self.SetInt32(self.ID_BLOCK, 0)
            self.Enable(self.ID_BUILD, False)
            self.Enable(self.ID_PAPER, False)
            self.preview.clear('CIF 读取失败，请查看提示')
            self.SetString(self.ID_PREVIEW_STATS,'CIF 读取失败：'+str(exc))
            self.SetString(self.ID_SUMMARY, 'CIF load failed')
            c4d.gui.MessageDialog('CIF load failed:\n' + str(exc))
            log_exception('CIF_LOAD_FAILED')
            return False

    def _select_block(self, index):
        self._clear_preview('选择结构数据块后显示预览')
        self.structure = None
        self.built = None
        self.Enable(self.ID_BUILD, False)
        self.Enable(self.ID_PAPER, False)
        if not 1 <= index <= len(self.blocks):
            self.SetString(self.ID_SUMMARY, 'Choose a structure data block.')
            return False
        try:
            self.structure = parse_cif_block(self.blocks[index-1], self.last_path)
            info = structure_summary(self.structure)
            elem = ", ".join(f"{k}:{v}" for k,v in sorted(info['elements'].items()))
            cell = info['cell']
            vac = info['detected_vacuum_axis'] or "none"
            summary = (
                f"{info['name']} | SG: {info['space_group'] or '?'} | "
                f"atoms/cell: {info['expanded_atoms']} ({elem}) | "
                f"a,b,c = {cell[0]:.4g}, {cell[1]:.4g}, {cell[2]:.4g} Å | "
                f"α,β,γ = {cell[3]:.3g}, {cell[4]:.3g}, {cell[5]:.3g}° | auto vacuum: {vac} | "
                f"{'BLOCKED' if self.structure.errors else 'Checks passed'} | notes: {len(self.structure.warnings)}"
            )
            self._reset_style_controls()
            self.SetString(self.ID_SUMMARY, summary)
            self.Enable(self.ID_BUILD, not self.structure.errors)
            self.Enable(self.ID_PAPER, not self.structure.errors)
            log('VALIDATION', validation_report(self.structure))
            if self.structure.errors:
                c4d.gui.MessageDialog(validation_report(self.structure))
            self._schedule_preview()
            log('CIF_LOAD_OK', summary)
            return True
        except Exception as exc:
            self.structure = None
            self.built = None
            self.preview.clear('CIF 读取失败，请查看提示')
            self.SetString(self.ID_PREVIEW_STATS,'CIF 读取失败：'+str(exc))
            self.SetString(self.ID_SUMMARY, 'CIF load failed')
            c4d.gui.MessageDialog("CIF load failed:\n" + str(exc))
            log_exception('CIF_LOAD_FAILED')
            return False

    def _ensure_loaded(self):
        path = self.GetString(self.ID_PATH).strip()
        if not path or not os.path.isfile(path):
            c4d.gui.MessageDialog("Please select a valid CIF file first.")
            return False
        if self.structure is None or path != self.last_path:
            if path != self.last_path or not self.blocks:
                if not self._load(path):
                    return False
            elif not self._select_block(self.GetInt32(self.ID_BLOCK)):
                return False
        if self.structure.errors:
            c4d.gui.MessageDialog(validation_report(self.structure))
            return False
        return True

    def _reset_style_controls(self):
        self.elements = sorted({s.element for s in self.structure.sites})
        self.pairs = list(combinations_with_replacement(self.elements, 2))
        self.element_styles, self.pair_rules = {}, {}
        self.active_element = self.active_pair = None
        for gadget, entries in ((self.ID_ELEMENT, self.elements), (self.ID_PAIR, ['–'.join(p) for p in self.pairs])):
            self.FreeChildren(gadget)
            for index, label in enumerate(entries, 1):
                self.AddChild(gadget, index, label)
            self.SetInt32(gadget, 1)
        self.SetInt32(self.ID_PRESET, 0)
        self._show_element(1)
        self._show_pair(1)
        counts = Counter(s.element for s in self.structure.expanded_sites())
        hm = self.structure.space_group.replace('_', '').replace(' ', '').lower()
        preset = 0
        if set(counts) == {'Mo', 'S'} and counts['S'] == 2 * counts['Mo'] and hm == 'p63/mmc':
            preset = 2
        elif set(counts) == {'Pd', 'Se'} and counts['Se'] == 2 * counts['Pd']:
            preset = 3
        if preset:
            self.SetInt32(self.ID_PRESET, preset)
            self.Command(self.ID_PRESET, None)
            log('DISPLAY_PRESET', 'preset={} (editable distance visualization)'.format(preset))

    def _show_element(self, index):
        self.active_element = self.elements[index-1] if 1 <= index <= len(self.elements) else None
        if self.active_element:
            element = self.active_element
            style = self.element_styles.get(element, {})
            self.SetColorField(self.ID_COLOR, c4d.Vector(*style.get('color', ELEMENT_COLORS.get(element, DEFAULT_COLOR))), 1.0, 1.0, 0)
            self.SetFloat(self.ID_RADIUS, style.get('radius', VISUAL_RADII.get(element, DEFAULT_VISUAL_RADIUS)), min=0.05, max=5.0, step=0.05)

    def _store_element(self):
        if self.active_element:
            value = self.GetColorField(self.ID_COLOR)
            if value is None:
                raise ValueError('Cannot read element color.')
            color = value['color']
            self.element_styles[self.active_element] = {
                'color': (color.x, color.y, color.z), 'radius': self.GetFloat(self.ID_RADIUS)}

    def _current_styles(self):
        self._store_element()
        return self.element_styles

    def _show_pair(self, index):
        self.active_pair = self.pairs[index-1] if 1 <= index <= len(self.pairs) else None
        if self.active_pair:
            rule = self.pair_rules.get(self.active_pair, {})
            auto = rule.get('auto', True)
            self.SetBool(self.ID_PAIR_SHOW, rule.get('show', True))
            self.SetBool(self.ID_PAIR_AUTO, auto)
            lo, hi = ((0.35, default_cutoff(self.active_pair, self.GetFloat(self.ID_BOND_TOL))) if auto
                      else rule.get('range', (0.35, 3.0)))
            self.SetFloat(self.ID_PAIR_MIN, lo, min=0.35, max=20.0, step=0.05)
            self.SetFloat(self.ID_PAIR_MAX, hi, min=0.35, max=20.0, step=0.05)
            self.Enable(self.ID_PAIR_MIN, not auto)
            self.Enable(self.ID_PAIR_MAX, not auto)

    def _store_pair(self):
        if self.active_pair:
            self.pair_rules[self.active_pair] = {
                'show': self.GetBool(self.ID_PAIR_SHOW), 'auto': self.GetBool(self.ID_PAIR_AUTO),
                'range': (self.GetFloat(self.ID_PAIR_MIN), self.GetFloat(self.ID_PAIR_MAX))}

    def _bond_options(self):
        self._store_pair()
        allowed = [p for p in self.pairs if self.pair_rules.get(p, {}).get('show', True)]
        overrides = {p: r['range'] for p, r in self.pair_rules.items() if not r['auto']}
        return dict(tolerance=self.GetFloat(self.ID_BOND_TOL),allowed_pairs=allowed,pair_overrides=overrides)

    def _infer_current(self, built):
        stats = {}
        bonds = infer_bonds(built.atoms, stats=stats,**self._bond_options())
        log('BOND_SEARCH', str(stats))
        return bonds

    def _renderer(self):
        selected = self.GetInt32(self.ID_RENDERER)
        from .vray_adapter import available
        return 'vray' if selected == 2 or (selected == 0 and available()) else 'native'

    def _clear_preview(self, message):
        self.SetTimer(0)
        self._preview_due = None
        self._built_key = self._built_cache = None
        self._display_key = self._display_cache = None
        self.preview_data = None
        self.preview.clear(message)
        self.SetString(self.ID_PREVIEW_STATS,message)

    def _current_built(self):
        dims = tuple(self.GetInt32(i) for i in (self.ID_NX,self.ID_NY,self.ID_NZ))
        key = id(self.structure),dims,self._axis_value()
        if key != self._built_key:
            self._built_cache = build_supercell(self.structure,*dims,self._axis_value(),center=True)
            self._built_key = key
        return self._built_cache

    def _enable_crop_controls(self):
        mode = self.GetInt32(self.ID_CROP)
        self.Enable(self.ID_CROP_NORMAL,mode != 0)
        for gadget in (self.ID_CROP_CENTER,self.ID_CROP_THICKNESS):
            self.Enable(gadget,mode == 1)
        for gadget in (self.ID_CROP_LAYER,self.ID_LAYER_GAP):
            self.Enable(gadget,mode == 2)
        for gadget in (self.ID_PERIODIC_A,self.ID_PERIODIC_B,self.ID_PERIODIC_C):
            self.Enable(gadget,self.GetBool(self.ID_PERIODIC))

    def _current_display(self):
        base = self._current_built()
        options = self._bond_options()
        axes = tuple(self.GetBool(g) and self.GetBool(self.ID_PERIODIC)
                     for g in (self.ID_PERIODIC_A,self.ID_PERIODIC_B,self.ID_PERIODIC_C))
        params = dict(crop={0:'off',1:'thickness',2:'layer'}[self.GetInt32(self.ID_CROP)],
            normal={0:'Z',1:'A',2:'B',3:'C'}[self.GetInt32(self.ID_CROP_NORMAL)],
            center=self.GetFloat(self.ID_CROP_CENTER),thickness=self.GetFloat(self.ID_CROP_THICKNESS),
            layer=self.GetInt32(self.ID_CROP_LAYER),layer_gap=self.GetFloat(self.ID_LAYER_GAP),
            periodic_axes=axes,make_bonds=self.GetBool(self.ID_BONDS))
        key = (id(base),tuple(params.items()),options['tolerance'],
               tuple(options['allowed_pairs']),tuple(sorted(options['pair_overrides'].items())))
        if key != self._display_key:
            self._display_cache = display_structure(base,bond_options=options,**params)
            self._display_key = key
            log('DISPLAY_GEOMETRY',self._display_cache.note)
        return self._display_cache

    def _current_snapshot(self):
        result = self._current_display()
        return PreviewData(result.built,result.bonds,self._current_styles(),
            self.GetFloat(self.ID_ATOM_SCALE),self.GetFloat(self.ID_BOND_RADIUS),
            self.GetBool(self.ID_ATOMS),self.GetBool(self.ID_BONDS),self.GetBool(self.ID_CELL))

    def _refresh_preview(self, ensure=False):
        self.SetTimer(0)
        self._preview_due = None
        try:
            if ensure and not self._ensure_loaded():
                self._clear_preview('请选择可建模的结构')
                return False
            if self.structure is None or self.GetString(self.ID_PATH).strip()!=self.last_path:
                self._clear_preview('请选择 CIF 并点击加载')
                return False
            if self.structure.errors:
                self._clear_preview('结构检查未通过，请查看 Validation report')
                return False
            snapshot = self._current_snapshot()
            self.preview_data = snapshot
            self.preview.set_data(snapshot)
            self.SetString(self.ID_PREVIEW_STATS,snapshot.summary()+'\n'+bond_report(snapshot.built.atoms,snapshot.bonds)+
                '\n'+self._current_display().note+'\n坐标与距离单位：Å；预览不创建场景对象。')
            log('PREVIEW_OK','atoms={} bonds={}'.format(len(snapshot.built.atoms),len(snapshot.bonds)))
            return True
        except Exception as exc:
            self.preview_data = None
            self.preview.clear('预览无法更新，请查看下方说明')
            self.SetString(self.ID_PREVIEW_STATS,str(exc))
            log_exception('PREVIEW_FAILED')
            return False

    def _schedule_preview(self):
        if not self.GetBool(self.ID_PREVIEW_AUTO):
            # Do not keep an old model looking like the current controls.
            self.preview_data = None
            self.preview.clear('参数已改变，点击“刷新预览”查看当前模型')
            self.SetString(self.ID_PREVIEW_STATS,'自动刷新已关闭；参数改变后请刷新预览。')
            return
        self._preview_due = time.monotonic()+.5
        self.SetString(self.ID_PREVIEW_STATS,'参数已改变，正在更新预览…')
        self.SetTimer(500)

    def Timer(self, msg):
        if self._preview_due is not None and time.monotonic() >= self._preview_due:
            self._refresh_preview()

    def Command(self, cid, msg):
        try:
            result = self._command(cid,msg)
            if cid in (self.ID_NX,self.ID_NY,self.ID_NZ,self.ID_AXIS,self.ID_ATOMS,self.ID_BONDS,self.ID_CELL,
                       self.ID_PERIODIC,self.ID_PERIODIC_A,self.ID_PERIODIC_B,self.ID_PERIODIC_C,
                       self.ID_CROP,self.ID_CROP_NORMAL,self.ID_CROP_CENTER,self.ID_CROP_THICKNESS,self.ID_CROP_LAYER,self.ID_LAYER_GAP,
                       self.ID_ATOM_SCALE,self.ID_BOND_RADIUS,self.ID_BOND_TOL,self.ID_SCENE_SCALE,
                       self.ID_COLOR,self.ID_RADIUS,self.ID_PAIR_SHOW,self.ID_PAIR_AUTO,self.ID_PAIR_MIN,self.ID_PAIR_MAX,self.ID_PRESET):
                self._schedule_preview()
            return result
        except Exception as exc:
            log_exception('CONTROL_FAILED')
            self.SetString(self.ID_PREVIEW_STATS,str(exc))
            return True

    def _command(self, cid, msg):
        if cid in (self.ID_CROP,self.ID_PERIODIC):
            self._enable_crop_controls()
            return True
        if cid == self.ID_PREVIEW_REFRESH:
            self._refresh_preview(ensure=True)
            return True
        if cid == self.ID_PREVIEW_AUTO:
            if self.GetBool(self.ID_PREVIEW_AUTO):
                self._schedule_preview()
            else:
                self.SetTimer(0)
                self._preview_due = None
            return True
        if cid == self.ID_LABELS:
            self.preview.labels = self.GetBool(self.ID_LABELS)
            self.preview.Redraw()
            return True
        if cid in (self.ID_VIEW_3D,self.ID_VIEW_TOP,self.ID_VIEW_FRONT,self.ID_VIEW_SIDE):
            self.preview.view({self.ID_VIEW_3D:'3d',self.ID_VIEW_TOP:'top',self.ID_VIEW_FRONT:'front',self.ID_VIEW_SIDE:'side'}[cid])
            return True
        if cid in (self.ID_ZOOM_OUT,self.ID_ZOOM_IN,self.ID_ZOOM_FIT):
            if cid==self.ID_ZOOM_FIT:
                self.preview.zoom=1.0
                self.preview.Redraw()
            else:
                self.preview.zoom_by(.8 if cid==self.ID_ZOOM_OUT else 1.25)
            return True
        if cid == self.ID_PATH:
            self._clear_preview('路径已改变，点击 Reload CIF 加载新文件')
            return True
        if cid == self.ID_ELEMENT:
            self._store_element()
            self._show_element(self.GetInt32(self.ID_ELEMENT))
            return True
        if cid in (self.ID_COLOR, self.ID_RADIUS):
            self._store_element()
            return True
        if cid == self.ID_PAIR:
            self._store_pair()
            self._show_pair(self.GetInt32(self.ID_PAIR))
            return True
        if cid in (self.ID_PAIR_SHOW, self.ID_PAIR_AUTO, self.ID_PAIR_MIN, self.ID_PAIR_MAX):
            self._store_pair()
            if cid == self.ID_PAIR_AUTO:
                self._show_pair(self.GetInt32(self.ID_PAIR))
            return True
        if cid == self.ID_BOND_TOL:
            self._store_pair()
            self._show_pair(self.GetInt32(self.ID_PAIR))
            return True
        if cid == self.ID_PRESET:
            selected = self.GetInt32(self.ID_PRESET)
            wanted = {2: {('Mo', 'S')}, 3: {('Pd', 'Se'), ('Se', 'Se')}}.get(selected)
            if wanted and not wanted.issubset(set(self.pairs)):
                c4d.gui.MessageDialog('此结构不包含该组合需要的元素。')
                self.SetInt32(self.ID_PRESET, 0)
                return True
            self._store_pair()
            for pair in self.pairs:
                rule = self.pair_rules.setdefault(pair, {'auto': True, 'range': (0.35, default_cutoff(pair))})
                rule['show'] = (pair in wanted if wanted is not None else pair[0] != pair[1] if selected == 1 else True)
            self._show_pair(self.GetInt32(self.ID_PAIR))
            return True
        if cid == self.ID_BOND_REPORT:
            try:
                if self._ensure_loaded():
                    result = self._current_display()
                    report = bond_report(result.built.atoms,result.bonds)+'\n'+result.note
                    log('BOND_PREVIEW', report)
                    c4d.gui.MessageDialog(report)
            except Exception as exc:
                log_exception('BOND_PREVIEW_FAILED')
                c4d.gui.MessageDialog('键预览失败：' + str(exc))
            return True
        if cid == self.ID_OUTPUT_BROWSE:
            path = c4d.storage.SaveDialog(title='Save transparent PNG', force_suffix='png')
            if path:
                self.SetString(self.ID_OUTPUT, path)
            return True
        if cid == self.ID_BLOCK:
            if self.GetString(self.ID_PATH).strip() != self.last_path:
                self._load(self.GetString(self.ID_PATH).strip())
            else:
                self._select_block(self.GetInt32(self.ID_BLOCK))
            return True
        if cid == self.ID_VALIDATION:
            c4d.gui.MessageDialog(validation_report(self.structure) if self.structure else 'Select a valid structure data block first.')
            return True
        if cid == self.ID_SELFTEST:
            try:
                from mcv_selftest import run_selftest
                result = run_selftest(os.path.dirname(os.path.dirname(__file__)))
                log('SELFTEST_OK', result)
                c4d.gui.MessageDialog(result + '\n\nLog: ' + LOG_PATH)
            except Exception as exc:
                log_exception('SELFTEST_FAILED')
                c4d.gui.MessageDialog('Self-test failed:\n' + str(exc) + '\nLog: ' + LOG_PATH)
            return True

        if cid == self.ID_BROWSE:
            path = c4d.storage.LoadDialog(title="Select .cif or .cif.gz", flags=c4d.FILESELECT_LOAD)
            if path:
                self._load(path)
            return True

        if cid == self.ID_RELOAD:
            path = self.GetString(self.ID_PATH).strip()
            if path:
                self._load(path)
            return True

        if cid in (self.ID_BUILD,self.ID_UPDATE):
            if not self._ensure_loaded():
                return True
            try:
                nx, ny, nz = self.GetInt32(self.ID_NX), self.GetInt32(self.ID_NY), self.GetInt32(self.ID_NZ)
                projected_atoms = len(self.structure.expanded_sites()) * nx * ny * nz
                if projected_atoms > 10000:
                    c4d.gui.MessageDialog(
                        f"This build would create about {projected_atoms} atoms.\n"
                        "Please reduce the supercell size (V1 safety limit: 10,000 atoms)."
                    )
                    return True
                log('BUILD_START', 'cells={}x{}x{}'.format(nx, ny, nz))
                snapshot = self._current_snapshot()
                built,bonds = snapshot.built,snapshot.bonds
                doc = c4d.documents.GetActiveDocument()
                target = None
                if cid == self.ID_UPDATE:
                    selected = doc.GetActiveObject()
                    if selected is not None:
                        target = model_root(doc,selected)
                    else:
                        try:
                            target = model_root(doc,self._last_model)
                        except (RuntimeError,ReferenceError):
                            target = None
                    if target is None:
                        c4d.gui.MessageDialog('请选择 0.6.0 生成的模型或其子对象。\n旧版模型请先用“新建模型”生成一次。')
                        return True
                self._last_model = build_scene(
                    doc, built, bonds, self.structure.name,
                    scene_scale=self.GetFloat(self.ID_SCENE_SCALE),
                    atom_scale=self.GetFloat(self.ID_ATOM_SCALE),
                    bond_radius_angstrom=self.GetFloat(self.ID_BOND_RADIUS),
                    make_atoms=self.GetBool(self.ID_ATOMS),
                    make_bonds=self.GetBool(self.ID_BONDS),
                    make_cell=self.GetBool(self.ID_CELL),
                    sphere_segments=self.GetInt32(self.ID_SEGMENTS),
                    instance_mode={0: 'render', 1: 'standard', 2: 'off'}[self.GetInt32(self.ID_INSTANCE)],
                    element_styles=snapshot.styles, renderer=self._renderer(),target=target,
                )
                self.built = built
                self.preview_data = snapshot
                self.preview.set_data(snapshot)
                log('UPDATE_OK' if cid == self.ID_UPDATE else 'BUILD_OK', 'atoms={} bonds={} segments={} instance={} renderer={}'.format(
                    len(built.atoms), len(bonds), self.GetInt32(self.ID_SEGMENTS),
                    self.GetInt32(self.ID_INSTANCE), self._renderer()))
                log('BOND_REPORT', bond_report(built.atoms, bonds))
                c4d.gui.MessageDialog(
                    f"Built {len(self.built.atoms)} atoms and {len(bonds)} visual bonds.\n"
                    f"Out-of-plane axis: {self.built.vacuum_axis or 'raw/none'}\n"+self._current_display().note
                )
            except Exception as exc:
                c4d.gui.MessageDialog("Build failed:\n" + str(exc) + "\n\nSee Console for traceback.")
                log_exception('BUILD_FAILED')
            return True

        if cid == self.ID_PAPER:
            try:
                if not self._ensure_loaded():
                    return True
                dims = [self.GetInt32(i) for i in (self.ID_NX, self.ID_NY, self.ID_NZ)]
                if len(self.structure.expanded_sites()) * dims[0] * dims[1] * dims[2] > 10000:
                    c4d.gui.MessageDialog('Reduce the supercell size (10,000 atom limit).')
                    return True
                # Use current controls; a previously built model may use another CIF/size.
                self.built = self._current_display().built
                log('PAPER_START')
                styles = self._current_styles()
                ball_margin = max(styles.get(e, {}).get('radius', VISUAL_RADII.get(e, DEFAULT_VISUAL_RADIUS))
                                  for e in self.elements) * self.GetFloat(self.ID_ATOM_SCALE)
                setup_paper_scene(c4d.documents.GetActiveDocument(), self.built,
                                  scene_scale=self.GetFloat(self.ID_SCENE_SCALE),
                                  renderer=self._renderer(),
                                  output_path=self.GetString(self.ID_OUTPUT).strip() or None,
                                  resolution=self.GetInt32(self.ID_RESOLUTION),
                                  atom_margin_angstrom=ball_margin,
                                  include_cell=self.GetBool(self.ID_CELL))
                log('PAPER_OK')
                c4d.gui.MessageDialog(
                    "相机与灯光已创建，PNG 透明通道已开启。\n"
                    "渲染器：" + self._renderer() + "\n"
                    "模型按出图页所选材质生成；改动设置后请点击“更新已有模型”。\n"
                    "请在画面管理器渲染或保存 VFB 图像（包含 alpha），背景棋盘格表示透明。"
                )
            except Exception as exc:
                c4d.gui.MessageDialog("Paper Scene failed:\n" + str(exc))
                log_exception('PAPER_FAILED')
            return True

        return True
