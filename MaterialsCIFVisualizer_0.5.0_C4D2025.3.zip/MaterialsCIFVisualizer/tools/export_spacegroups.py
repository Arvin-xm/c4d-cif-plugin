import hashlib
import json
import pathlib
import shutil
import sys
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
import gemmi

DEST = ROOT
entries = []
for group in gemmi.spacegroup_table():
    ext = group.ext.strip('\x00')
    aliases = {group.hm, group.xhm(), group.short_name()}
    if ext:
        aliases.add(group.short_name().split(':')[0] + ':' + ext)
    entries.append(dict(number=group.number, hm=group.hm, xhm=group.xhm(),
                        hall=group.hall, ext=ext, qualifier=group.qualifier,
                        aliases=sorted(aliases), operations=[op.triplet() for op in group.operations()]))
data = dict(generator='Gemmi 0.7.5', source='https://github.com/project-gemmi/gemmi/tree/v0.7.5',
            license='MPL-2.0', settings=entries)
path = DEST / 'materials_cif' / 'spacegroups.json'
path.write_text(json.dumps(data, ensure_ascii=True, separators=(',', ':')), encoding='utf-8')
licences = [p for p in (ROOT / 'gemmi_dev').rglob('LICENSE*') if p.is_file()]
if licences:
    licence = licences[0].read_bytes()
else:
    with urllib.request.urlopen('https://raw.githubusercontent.com/project-gemmi/gemmi/v0.7.5/LICENSE.txt', timeout=20) as response:
        licence = response.read()
(DEST / 'third_party').mkdir(exist_ok=True)
(DEST / 'third_party' / 'Gemmi-LICENSE.txt').write_bytes(licence)
(DEST / 'third_party' / 'NOTICE.txt').write_text(
    'spacegroups.json is generated from Gemmi 0.7.5 spacegroup_table() and operations().\n'
    'Gemmi authors: Global Phasing Ltd and other contributors. Licensed MPL-2.0.\n'
    'Source: https://github.com/project-gemmi/gemmi/tree/v0.7.5\n'
    'Underlying table provenance is described at https://gemmi.readthedocs.io/en/stable/symmetry.html\n'
    'Generation script: tools/export_spacegroups.py (included).\n'
    'The plugin uses exported text data only. No Gemmi binary is loaded by Cinema 4D.\n', encoding='utf-8')
(DEST / 'tools').mkdir(exist_ok=True)
