#!/usr/bin/env python3
"""Small standalone validator for CIFs before opening Cinema 4D."""
import json
import sys
from materials_cif import parse_cif_file, structure_summary

if len(sys.argv) != 2:
    raise SystemExit("Usage: python validate_cif.py structure.cif")

s = parse_cif_file(sys.argv[1])
print(json.dumps(structure_summary(s), indent=2, ensure_ascii=False))
