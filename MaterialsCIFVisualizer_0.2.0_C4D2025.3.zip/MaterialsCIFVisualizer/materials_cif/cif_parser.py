"""Dependency-free CIF parser and crystal structure utilities.

This module intentionally avoids NumPy, pymatgen, ASE, and gemmi so that it can
run inside Cinema 4D's bundled Python interpreter without extra installation.
It supports the common CIF constructs needed by materials workflows:

- scalar tags
- loop_ tables
- quoted values
- semicolon multiline values
- atom sites in fractional coordinates
- common symmetry-operation tags
- non-orthogonal cells
- symmetry expansion with duplicate removal
- supercell construction
- 2D/vacuum-axis alignment

It is not a full IUCr CIF validator. For unusual CIF dialects, adding a gemmi
adapter later is recommended.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import ast
import math
import re
import shlex


Vec3 = Tuple[float, float, float]


@dataclass
class AtomSite:
    element: str
    label: str
    fract: Vec3
    occupancy: float = 1.0
    raw_type_symbol: str = ""


@dataclass
class CrystalStructure:
    name: str
    a: float
    b: float
    c: float
    alpha: float
    beta: float
    gamma: float
    sites: List[AtomSite] = field(default_factory=list)
    symmetry_ops: List[str] = field(default_factory=lambda: ["x,y,z"])
    space_group: str = ""
    source_path: str = ""

    def lattice_vectors(self) -> Tuple[Vec3, Vec3, Vec3]:
        return lattice_vectors(self.a, self.b, self.c, self.alpha, self.beta, self.gamma)

    def expanded_sites(self, tol: float = 1e-6) -> List[AtomSite]:
        out: List[AtomSite] = []
        seen = set()
        ops = self.symmetry_ops or ["x,y,z"]
        for site in self.sites:
            for op in ops:
                f = apply_symmetry_op(op, site.fract)
                f = tuple(_wrap01(v) for v in f)
                key = (site.element,) + tuple(int(round(v / tol)) for v in f)
                if key in seen:
                    continue
                seen.add(key)
                out.append(AtomSite(
                    element=site.element,
                    label=site.label,
                    fract=f,
                    occupancy=site.occupancy,
                    raw_type_symbol=site.raw_type_symbol,
                ))
        return out


@dataclass
class CartesianAtom:
    element: str
    label: str
    position: Vec3
    occupancy: float = 1.0
    raw_type_symbol: str = ""
    cell_index: Tuple[int, int, int] = (0, 0, 0)


@dataclass
class BuiltStructure:
    atoms: List[CartesianAtom]
    cell_vectors: Tuple[Vec3, Vec3, Vec3]
    source_cell_vectors: Tuple[Vec3, Vec3, Vec3]
    vacuum_axis: Optional[str]
    center_shift: Vec3


class CIFError(ValueError):
    pass


def _strip_inline_comment(line: str) -> str:
    # CIF comments begin with # outside quotes. shlex already handles comments,
    # so this helper is only used for detecting blank lines.
    return line


def _tokenize_cif(text: str) -> List[str]:
    """Tokenize common CIF syntax, including semicolon multiline fields."""
    tokens: List[str] = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith(";"):
            block = [line[1:]]
            i += 1
            while i < len(lines) and not lines[i].startswith(";"):
                block.append(lines[i])
                i += 1
            if i >= len(lines):
                raise CIFError("Unterminated semicolon multiline CIF value")
            tokens.append("\n".join(block))
            i += 1
            continue
        lexer = shlex.shlex(line, posix=True)
        lexer.whitespace_split = True
        lexer.commenters = "#"
        try:
            tokens.extend(list(lexer))
        except ValueError as exc:
            raise CIFError(f"Cannot tokenize CIF line {i+1}: {exc}") from exc
        i += 1
    return tokens


def _parse_tokens(tokens: Sequence[str]) -> Tuple[str, Dict[str, str], List[Tuple[List[str], List[List[str]]]]]:
    data_name = ""
    scalars: Dict[str, str] = {}
    loops: List[Tuple[List[str], List[List[str]]]] = []
    i = 0
    n = len(tokens)
    while i < n:
        t = tokens[i]
        low = t.lower()
        if low.startswith("data_"):
            data_name = t[5:] or data_name
            i += 1
            continue
        if low == "loop_":
            i += 1
            headers: List[str] = []
            while i < n and tokens[i].startswith("_"):
                headers.append(tokens[i])
                i += 1
            if not headers:
                raise CIFError("loop_ without headers")
            values: List[str] = []
            while i < n:
                nxt = tokens[i]
                nlow = nxt.lower()
                if nxt.startswith("_") or nlow == "loop_" or nlow.startswith("data_") or nlow in ("stop_", "save_"):
                    break
                values.append(nxt)
                i += 1
            if len(values) % len(headers) != 0:
                raise CIFError(
                    f"Loop with {len(headers)} columns has {len(values)} values; not divisible"
                )
            rows = [values[j:j+len(headers)] for j in range(0, len(values), len(headers))]
            loops.append((headers, rows))
            continue
        if t.startswith("_"):
            if i + 1 >= n:
                raise CIFError(f"Missing value for CIF tag {t}")
            scalars[t] = tokens[i + 1]
            i += 2
            continue
        i += 1
    return data_name, scalars, loops


def _float_cif(value: str, default: Optional[float] = None) -> float:
    if value in ("?", ".", ""):
        if default is None:
            raise CIFError(f"Missing numeric CIF value: {value!r}")
        return default
    # Remove standard uncertainty suffix: 3.1922(4)
    clean = re.sub(r"\((?:\d+)\)$", "", value.strip())
    try:
        return float(clean)
    except ValueError as exc:
        if default is not None:
            return default
        raise CIFError(f"Invalid numeric CIF value: {value!r}") from exc


def normalize_element(symbol_or_label: str) -> str:
    """Convert 'Mo4+', 'S2-', 'Se1', 'Pd0' -> canonical element symbols."""
    s = (symbol_or_label or "").strip()
    m = re.match(r"^([A-Z][a-z]?)", s)
    if not m:
        m = re.search(r"([A-Z][a-z]?)", s)
    if not m:
        raise CIFError(f"Cannot infer element from {symbol_or_label!r}")
    return m.group(1)


def _find_loop(loops, required_any: Iterable[str]) -> Optional[Tuple[List[str], List[List[str]]]]:
    req = {x.lower() for x in required_any}
    for headers, rows in loops:
        h = {x.lower() for x in headers}
        if h & req:
            return headers, rows
    return None


def _tag_index(headers: Sequence[str], *candidates: str) -> Optional[int]:
    lower = [h.lower() for h in headers]
    for c in candidates:
        c = c.lower()
        if c in lower:
            return lower.index(c)
    return None


def parse_cif_text(text: str, source_path: str = "") -> CrystalStructure:
    tokens = _tokenize_cif(text)
    data_name, scalars, loops = _parse_tokens(tokens)
    sl = {k.lower(): v for k, v in scalars.items()}

    def scalar(*names: str, default: str = "") -> str:
        for name in names:
            if name.lower() in sl:
                return sl[name.lower()]
        return default

    a = _float_cif(scalar("_cell_length_a"))
    b = _float_cif(scalar("_cell_length_b"))
    c = _float_cif(scalar("_cell_length_c"))
    alpha = _float_cif(scalar("_cell_angle_alpha"), 90.0)
    beta = _float_cif(scalar("_cell_angle_beta"), 90.0)
    gamma = _float_cif(scalar("_cell_angle_gamma"), 90.0)
    space_group = scalar(
        "_space_group_name_h-m_alt",
        "_symmetry_space_group_name_h-m",
        "_space_group_name_h-m",
        default="",
    )

    symmetry_ops: List[str] = []
    sym_tags = {
        "_space_group_symop_operation_xyz",
        "_symmetry_equiv_pos_as_xyz",
        "_space_group_symop.operation_xyz",
    }
    for headers, rows in loops:
        idx = _tag_index(headers, *sym_tags)
        if idx is not None:
            symmetry_ops.extend(row[idx] for row in rows)
    if not symmetry_ops:
        symmetry_ops = ["x,y,z"]

    sites: List[AtomSite] = []
    atom_loop = None
    for headers, rows in loops:
        if (_tag_index(headers, "_atom_site_fract_x") is not None and
            _tag_index(headers, "_atom_site_fract_y") is not None and
            _tag_index(headers, "_atom_site_fract_z") is not None):
            atom_loop = (headers, rows)
            break
    if atom_loop is None:
        raise CIFError("No fractional atom-site loop found in CIF")

    headers, rows = atom_loop
    ix = _tag_index(headers, "_atom_site_fract_x")
    iy = _tag_index(headers, "_atom_site_fract_y")
    iz = _tag_index(headers, "_atom_site_fract_z")
    itype = _tag_index(headers, "_atom_site_type_symbol")
    ilabel = _tag_index(headers, "_atom_site_label")
    iocc = _tag_index(headers, "_atom_site_occupancy")
    assert ix is not None and iy is not None and iz is not None

    for row in rows:
        raw = row[itype] if itype is not None else (row[ilabel] if ilabel is not None else "X")
        label = row[ilabel] if ilabel is not None else raw
        element = normalize_element(raw if raw not in ("?", ".") else label)
        occupancy = _float_cif(row[iocc], 1.0) if iocc is not None else 1.0
        sites.append(AtomSite(
            element=element,
            label=label,
            fract=(_float_cif(row[ix]), _float_cif(row[iy]), _float_cif(row[iz])),
            occupancy=occupancy,
            raw_type_symbol=raw,
        ))

    return CrystalStructure(
        name=data_name or scalar("_chemical_formula_structural", "_chemical_name_common", default="structure"),
        a=a, b=b, c=c, alpha=alpha, beta=beta, gamma=gamma,
        sites=sites, symmetry_ops=symmetry_ops, space_group=space_group,
        source_path=source_path,
    )


def parse_cif_file(path: str) -> CrystalStructure:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return parse_cif_text(f.read(), source_path=path)


# ---------- symmetry ----------
_ALLOWED_BINOPS = {ast.Add, ast.Sub, ast.Mult, ast.Div}
_ALLOWED_UNARY = {ast.UAdd, ast.USub}


def _safe_expr_eval(expr: str, vars_: Dict[str, float]) -> float:
    node = ast.parse(expr.strip(), mode="eval")

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return float(n.value)
        if isinstance(n, ast.Name) and n.id in vars_:
            return float(vars_[n.id])
        if isinstance(n, ast.BinOp) and type(n.op) in _ALLOWED_BINOPS:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Add): return a + b
            if isinstance(n.op, ast.Sub): return a - b
            if isinstance(n.op, ast.Mult): return a * b
            if isinstance(n.op, ast.Div): return a / b
        if isinstance(n, ast.UnaryOp) and type(n.op) in _ALLOWED_UNARY:
            v = ev(n.operand)
            return v if isinstance(n.op, ast.UAdd) else -v
        raise CIFError(f"Unsupported symmetry expression: {expr!r}")

    return float(ev(node))


def apply_symmetry_op(op: str, fract: Vec3) -> Vec3:
    parts = [p.strip() for p in op.strip().strip("'").strip('"').split(",")]
    if len(parts) != 3:
        raise CIFError(f"Symmetry operation must have 3 components: {op!r}")
    vars_ = {"x": fract[0], "y": fract[1], "z": fract[2]}
    return tuple(_safe_expr_eval(p, vars_) for p in parts)  # type: ignore[return-value]


def _wrap01(v: float) -> float:
    w = v % 1.0
    if abs(w - 1.0) < 1e-12 or abs(w) < 1e-12:
        return 0.0
    return w


# ---------- geometry ----------
def lattice_vectors(a: float, b: float, c: float,
                    alpha_deg: float, beta_deg: float, gamma_deg: float
                    ) -> Tuple[Vec3, Vec3, Vec3]:
    """Return crystallographic a,b,c vectors in a Cartesian right-handed frame."""
    alpha, beta, gamma = map(math.radians, (alpha_deg, beta_deg, gamma_deg))
    sg = math.sin(gamma)
    if abs(sg) < 1e-12:
        raise CIFError("Invalid cell: sin(gamma) is zero")
    av = (a, 0.0, 0.0)
    bv = (b * math.cos(gamma), b * sg, 0.0)
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / sg
    cz2 = c * c - cx * cx - cy * cy
    if cz2 < -1e-8:
        raise CIFError("Invalid cell geometry: negative c_z^2")
    cv = (cx, cy, math.sqrt(max(0.0, cz2)))
    return av, bv, cv


def _vadd(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]+b[0], a[1]+b[1], a[2]+b[2])


def _vsub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]-b[0], a[1]-b[1], a[2]-b[2])


def _vscale(a: Vec3, s: float) -> Vec3:
    return (a[0]*s, a[1]*s, a[2]*s)


def _vdot(a: Vec3, b: Vec3) -> float:
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def _vcross(a: Vec3, b: Vec3) -> Vec3:
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _vnorm(a: Vec3) -> float:
    return math.sqrt(_vdot(a, a))


def _vunit(a: Vec3) -> Vec3:
    n = _vnorm(a)
    if n < 1e-12:
        raise CIFError("Cannot normalize zero vector")
    return _vscale(a, 1.0/n)


def fract_to_cart(fract: Vec3, lattice: Tuple[Vec3, Vec3, Vec3]) -> Vec3:
    a, b, c = lattice
    return (
        fract[0]*a[0] + fract[1]*b[0] + fract[2]*c[0],
        fract[0]*a[1] + fract[1]*b[1] + fract[2]*c[1],
        fract[0]*a[2] + fract[1]*b[2] + fract[2]*c[2],
    )


def _largest_circular_gap(values: Sequence[float]) -> Tuple[float, float]:
    """Return (gap_fraction, midpoint) for values on a periodic [0,1) circle."""
    vals = sorted({_wrap01(v) for v in values})
    if not vals:
        return 1.0, 0.5
    if len(vals) == 1:
        return 1.0, _wrap01(vals[0] + 0.5)
    best_gap = -1.0
    best_mid = 0.0
    for i, left in enumerate(vals):
        right = vals[(i + 1) % len(vals)] + (1.0 if i == len(vals) - 1 else 0.0)
        gap = right - left
        if gap > best_gap:
            best_gap = gap
            best_mid = _wrap01(left + gap / 2.0)
    return best_gap, best_mid


def detect_vacuum_axis_from_structure(structure: CrystalStructure,
                                      min_gap_fraction: float = 0.45,
                                      min_gap_angstrom: float = 5.0) -> Optional[str]:
    """Detect a likely vacuum axis from empty periodic space, not just cell length.

    This avoids classifying layered bulk cells (e.g. ordinary 2H-MoS2) as vacuum
    merely because c is longer than a and b. A direction is considered vacuum-like
    only when the expanded atom positions leave a large circular gap both as a
    fraction of the unit cell and in absolute angstrom.
    """
    expanded = structure.expanded_sites()
    lengths = {"A": structure.a, "B": structure.b, "C": structure.c}
    best = None
    for idx, axis in enumerate(("A", "B", "C")):
        gap, _ = _largest_circular_gap([s.fract[idx] for s in expanded])
        physical = gap * lengths[axis]
        if gap >= min_gap_fraction and physical >= min_gap_angstrom:
            score = physical
            if best is None or score > best[0]:
                best = (score, axis)
    return best[1] if best else None


def detect_vacuum_axis(lattice: Tuple[Vec3, Vec3, Vec3], ratio_threshold: float = 1.6) -> Optional[str]:
    """Legacy length-only heuristic retained for API compatibility.

    Prefer detect_vacuum_axis_from_structure() when atom positions are available.
    """
    lengths = [("A", _vnorm(lattice[0])), ("B", _vnorm(lattice[1])), ("C", _vnorm(lattice[2]))]
    lengths.sort(key=lambda x: x[1], reverse=True)
    if lengths[0][1] / max(lengths[1][1], 1e-12) >= ratio_threshold:
        return lengths[0][0]
    return None


def alignment_basis(lattice: Tuple[Vec3, Vec3, Vec3], vacuum_axis: Optional[str]) -> Tuple[Vec3, Vec3, Vec3]:
    """Return basis x,y,z where z follows chosen vacuum axis.

    The remaining crystallographic direction is projected into the plane to
    define x, then y is chosen to preserve a right-handed frame.
    """
    if vacuum_axis is None:
        return (1.0,0.0,0.0), (0.0,1.0,0.0), (0.0,0.0,1.0)
    idx = {"A": 0, "B": 1, "C": 2}[vacuum_axis.upper()]
    others = [i for i in range(3) if i != idx]
    zhat = _vunit(lattice[idx])
    candidate = lattice[others[0]]
    xproj = _vsub(candidate, _vscale(zhat, _vdot(candidate, zhat)))
    if _vnorm(xproj) < 1e-10:
        candidate = lattice[others[1]]
        xproj = _vsub(candidate, _vscale(zhat, _vdot(candidate, zhat)))
    xhat = _vunit(xproj)
    yhat = _vunit(_vcross(zhat, xhat))
    return xhat, yhat, zhat


def transform_vec(v: Vec3, basis: Tuple[Vec3, Vec3, Vec3]) -> Vec3:
    xhat, yhat, zhat = basis
    return (_vdot(v, xhat), _vdot(v, yhat), _vdot(v, zhat))


def build_supercell(structure: CrystalStructure,
                    nx: int = 1, ny: int = 1, nz: int = 1,
                    vacuum_axis: str = "AUTO",
                    center: bool = True) -> BuiltStructure:
    if min(nx, ny, nz) < 1:
        raise ValueError("Supercell dimensions must be >= 1")
    lattice = structure.lattice_vectors()
    if vacuum_axis.upper() == "AUTO":
        axis = detect_vacuum_axis_from_structure(structure)
    elif vacuum_axis.upper() in ("A", "B", "C"):
        axis = vacuum_axis.upper()
    elif vacuum_axis.upper() in ("NONE", "RAW", "OFF"):
        axis = None
    else:
        raise ValueError("vacuum_axis must be AUTO, A, B, C, or NONE")
    basis = alignment_basis(lattice, axis)

    expanded = structure.expanded_sites()
    # When a vacuum direction is selected, shift the periodic origin into the
    # largest empty gap. This keeps a 2D slab together instead of splitting it
    # across opposite sides of the unit cell (common in CIF exports).
    frac_shift = [0.0, 0.0, 0.0]
    if axis is not None and expanded:
        aidx = {"A": 0, "B": 1, "C": 2}[axis]
        _, gap_mid = _largest_circular_gap([s.fract[aidx] for s in expanded])
        frac_shift[aidx] = (-gap_mid) % 1.0

    atoms: List[CartesianAtom] = []
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                for site in expanded:
                    sf = (
                        _wrap01(site.fract[0] + frac_shift[0]),
                        _wrap01(site.fract[1] + frac_shift[1]),
                        _wrap01(site.fract[2] + frac_shift[2]),
                    )
                    f = (sf[0] + ix, sf[1] + iy, sf[2] + iz)
                    p = fract_to_cart(f, lattice)
                    p = transform_vec(p, basis)
                    atoms.append(CartesianAtom(
                        element=site.element,
                        label=site.label,
                        position=p,
                        occupancy=site.occupancy,
                        raw_type_symbol=site.raw_type_symbol,
                        cell_index=(ix, iy, iz),
                    ))

    sc_lattice_raw = (_vscale(lattice[0], nx), _vscale(lattice[1], ny), _vscale(lattice[2], nz))
    sc_lattice = tuple(transform_vec(v, basis) for v in sc_lattice_raw)  # type: ignore[assignment]

    shift = (0.0, 0.0, 0.0)
    if center and atoms:
        xs = [a.position[0] for a in atoms]
        ys = [a.position[1] for a in atoms]
        zs = [a.position[2] for a in atoms]
        shift = (-(min(xs)+max(xs))/2, -(min(ys)+max(ys))/2, -(min(zs)+max(zs))/2)
        for atom in atoms:
            atom.position = _vadd(atom.position, shift)

    return BuiltStructure(
        atoms=atoms,
        cell_vectors=sc_lattice, source_cell_vectors=lattice,
        vacuum_axis=axis, center_shift=shift,
    )


def structure_summary(structure: CrystalStructure) -> Dict[str, object]:
    expanded = structure.expanded_sites()
    counts: Dict[str, int] = {}
    for s in expanded:
        counts[s.element] = counts.get(s.element, 0) + 1
    lattice = structure.lattice_vectors()
    return {
        "name": structure.name,
        "space_group": structure.space_group,
        "cell": (structure.a, structure.b, structure.c, structure.alpha, structure.beta, structure.gamma),
        "asymmetric_sites": len(structure.sites),
        "expanded_atoms": len(expanded),
        "elements": counts,
        "symmetry_ops": len(structure.symmetry_ops),
        "detected_vacuum_axis": detect_vacuum_axis_from_structure(structure),
    }
