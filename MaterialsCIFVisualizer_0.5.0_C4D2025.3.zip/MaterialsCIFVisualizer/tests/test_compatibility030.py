import gzip
import os
from pathlib import Path
import tempfile
import unittest

from materials_cif import parse_cif_file, parse_cif_text, build_supercell
from materials_cif.cif_document import CIFError, read_blocks
from materials_cif.cif_parser import apply_symmetry_op
from materials_cif.symmetry import resolve, validate_ops, table, compile_op
from materials_cif.validation import close_pairs


def cif(name='test', sg='P 1', rows='C C1 .1 .2 .3 1', extra='', coords='fract', cell=(10,10,10,90,90,90)):
    fields = ('length_a','length_b','length_c','angle_alpha','angle_beta','angle_gamma')
    return ('data_' + name + '\n' + ''.join('_cell_{} {}\n'.format(k,v) for k,v in zip(fields,cell)) +
            ("_space_group_name_H-M_alt '{}'\n".format(sg) if sg else '') + extra + '\nloop_\n' +
            '_atom_site_type_symbol\n_atom_site_label\n' +
            ''.join('_atom_site_{}_{}\n'.format(coords,k) for k in 'xyz') +
            '_atom_site_occupancy\n' + rows + '\n')


class Compatibility030Tests(unittest.TestCase):
    def test_missing_symmetry_supplied(self):
        s = parse_cif_text(cif(sg='P -1'))
        self.assertEqual(len(s.expanded_sites()), 2)
        self.assertIn('Gemmi table', s.symmetry_source)
        self.assertFalse(s.errors)

    def test_ambiguous_origin_is_rejected(self):
        with self.assertRaisesRegex(CIFError, 'Ambiguous'):
            parse_cif_text(cif(sg='F d -3 m'))

    def test_explicit_origin_is_accepted(self):
        ops, source, notes = resolve([], hm='F d -3 m:2')
        self.assertEqual(len(ops), 192)
        self.assertIn(':2', source)

    def test_number_only_setting_is_not_guessed(self):
        with self.assertRaisesRegex(CIFError, 'Ambiguous'):
            parse_cif_text(cif(sg='', extra='_space_group_IT_number 14'))

    def test_no_symmetry_is_rejected(self):
        with self.assertRaisesRegex(CIFError, 'No usable'):
            parse_cif_text(cif(sg=''))

    def test_name_number_disagreement(self):
        with self.assertRaisesRegex(CIFError, 'conflicts'):
            parse_cif_text(cif(extra='_space_group_IT_number 2'))

    def test_incomplete_explicit_operations(self):
        with self.assertRaisesRegex(CIFError, 'conflict'):
            parse_cif_text(cif(sg='P -1', extra="_space_group_symop_operation_xyz 'x,y,z'"))

    def test_operation_closure_is_checked(self):
        with self.assertRaisesRegex(CIFError, 'closed group'):
            validate_ops(('x,y,z', '-y,x,z'))

    def test_nonlinear_or_singular_operations_rejected(self):
        for operation in ('x*x,y,z','0,y,z','x+1/0,y,z','__import__("os"),y,z'):
            with self.subTest(operation=operation), self.assertRaises(CIFError):
                apply_symmetry_op(operation, (.1,.2,.3))

    def test_multi_block_requires_selection_and_keeps_cell(self):
        text = cif(name='one') + cif(name='two', rows='O O1 .2 .3 .4 1', cell=(20,20,20,90,90,90))
        with self.assertRaisesRegex(CIFError, 'Multiple'):
            parse_cif_text(text)
        one = parse_cif_text(text, block_name='one')
        two = parse_cif_text(text, block_name='two')
        self.assertEqual((one.a,one.sites[0].element), (10,'C'))
        self.assertEqual((two.a,two.sites[0].element), (20,'O'))

    def test_metadata_only_blocks_are_not_selected(self):
        s = parse_cif_text('data_metadata\n_a 42\n' + cif())
        self.assertEqual(s.a, 10)

    def test_quoted_reserved_words_are_values(self):
        text = cif(rows="C 'data_other' .1 .2 .3 1", extra="_chemical_name_common '_cell_length_a'")
        s = parse_cif_text(text)
        self.assertEqual(s.sites[0].label, 'data_other')

    def test_semicolon_text_does_not_create_blocks(self):
        text = cif(extra='_publ_section_comment\n;hello\ndata_phantom\n;')
        self.assertEqual(len(read_blocks(text)), 1)

    def test_duplicate_tags_and_blocks_rejected(self):
        for text in (cif(extra='_cell_length_a 11'), cif()+cif()):
            with self.assertRaisesRegex(CIFError, 'Duplicate|duplicate'):
                parse_cif_text(text)

    def test_missing_value_is_not_next_tag(self):
        with self.assertRaisesRegex(CIFError, 'Missing value'):
            parse_cif_text(cif().replace('_cell_length_a 10','_cell_length_a'))

    def test_numeric_uncertainty_and_exponent(self):
        s = parse_cif_text(cif(rows='C C1 1.0(2)e-1 .2 .3 1'))
        self.assertAlmostEqual(s.sites[0].fract[0], .1)

    def test_invalid_cells_and_nan_rejected(self):
        for old, new in (('_cell_length_a 10','_cell_length_a -1'),
                         ('_cell_angle_gamma 90','_cell_angle_gamma 0'),
                         ('_cell_angle_alpha 90','_cell_angle_alpha ?'),
                         ('.1 .2 .3','NaN .2 .3')):
            with self.subTest(new=new), self.assertRaises(CIFError):
                parse_cif_text(cif().replace(old,new))

    def test_cartesian_conversion_nonorthogonal(self):
        from materials_cif.cif_parser import lattice_vectors, fract_to_cart
        cell=(6,7,8,80,95,110)
        xyz=fract_to_cart((.1,.2,.3),lattice_vectors(*cell))
        s=parse_cif_text(cif(coords='Cartn', cell=cell, rows='C C1 {} {} {} 1'.format(*xyz)))
        for actual, expected in zip(s.sites[0].fract,(.1,.2,.3)):
            self.assertAlmostEqual(actual,expected)

    def test_dot_tag_aliases(self):
        text=cif().replace('_cell_', '_cell.').replace('_space_group_', '_space_group.').replace('_atom_site_', '_atom_site.')
        self.assertEqual(len(parse_cif_text(text).sites),1)

    def test_unrelated_dotted_metadata_tags_stay_distinct(self):
        s=parse_cif_text(cif(extra='_diffrn_radiation.wavelength_id 1\n_diffrn_radiation_wavelength.id 2'))
        self.assertEqual(len(s.sites),1)

    def test_rounded_special_position_is_not_multiplied(self):
        s=parse_cif_text(cif(sg='P -3 m 1',cell=(4.15,4.15,6.86,90,90,120),rows='I I1 .3333 .6667 .75763 1'))
        self.assertEqual(len(s.expanded_sites()),2)
        self.assertTrue(any('Rounded special' in n for n in s.warnings))

    def test_custom_cartesian_transform_rejected(self):
        with self.assertRaisesRegex(CIFError,'Custom Cartesian'):
            parse_cif_text(cif(coords='Cartn',extra='_atom_sites_Cartn_tran_matrix_11 1'))

    def test_partial_occupancy_blocks_build(self):
        s=parse_cif_text(cif(rows='C C1 .1 .2 .3 0.5'))
        self.assertTrue(any('Partial occupancy' in e for e in s.errors))
        with self.assertRaises(CIFError): build_supercell(s)

    def test_zero_occupancy_excluded(self):
        s=parse_cif_text(cif(rows='C C1 .1 .2 .3 1\nO O1 .1 .2 .3 0'))
        self.assertEqual(len(s.sites),1)
        self.assertFalse(s.errors)

    def test_invalid_occupancy_rejected(self):
        for occupancy in ('-1','1.5','?','nan'):
            with self.subTest(occupancy=occupancy), self.assertRaises(CIFError):
                parse_cif_text(cif(rows='C C1 .1 .2 .3 '+occupancy))

    def test_disorder_blocks_build(self):
        text=cif().replace('_atom_site_occupancy\n','_atom_site_occupancy\n_atom_site_disorder_group\n').replace('C C1 .1 .2 .3 1','C C1 .1 .2 .3 1 1')
        self.assertTrue(any('Disorder' in e for e in parse_cif_text(text).errors))

    def test_overlaps_across_periodic_boundary_detected(self):
        s=parse_cif_text(cif(rows='C C1 .001 .2 .3 1\nO O1 .999 .2 .3 1'))
        self.assertTrue(any('closer' in e for e in s.errors))
        with self.assertRaises(CIFError): build_supercell(s)

    def test_duplicate_asymmetric_sites_are_not_silently_removed(self):
        s=parse_cif_text(cif(rows='C C1 .1 .2 .3 1\nC C2 .1 .2 .3 1'))
        self.assertEqual(len(s.expanded_sites()),2)
        self.assertTrue(any('closer' in e for e in s.errors))

    def test_formula_mismatch_blocks_build(self):
        s=parse_cif_text(cif(extra="_chemical_formula_sum 'C2 O'\n_cell_formula_units_Z 1"))
        self.assertTrue(s.errors)

    def test_exporter_full_cell_formula_gives_visible_note(self):
        s=parse_cif_text(cif(extra="_chemical_formula_sum 'C'\n_cell_formula_units_Z 2"))
        self.assertFalse(s.errors)
        self.assertTrue(any('Formula/Z' in e for e in s.warnings))

    def test_multiplicity_mismatch_blocks_build(self):
        text=cif().replace('_atom_site_occupancy\n','_atom_site_occupancy\n_atom_site_symmetry_multiplicity\n').replace('C C1 .1 .2 .3 1','C C1 .1 .2 .3 1 2')
        self.assertTrue(any('Multiplicity' in e for e in parse_cif_text(text).errors))

    def test_volume_and_lattice_metric_mismatch(self):
        self.assertTrue(parse_cif_text(cif(extra='_cell_volume 2000')).errors)
        s=parse_cif_text(cif(sg='P 4',cell=(10,12,10,90,90,90)))
        self.assertTrue(any('rotations' in e for e in s.errors))

    def test_magnetic_biological_and_cif2_rejected(self):
        for text in (cif(extra='_atom_site_moment_crystalaxis_x 1'),
                     cif(extra='_atom_site_label_asym_id A'),
                     '#\\#CIF_2.0\n'+cif()):
            with self.assertRaises(CIFError): parse_cif_text(text)

    def test_gzip_and_bom(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'test.cif.gz'
            with gzip.open(path,'wb') as out: out.write(('\ufeff'+cif()).encode('utf-8'))
            self.assertEqual(parse_cif_file(str(path)).a,10)

    def test_unknown_element_rejected(self):
        with self.assertRaisesRegex(CIFError,'Unknown element'):
            parse_cif_text(cif(rows='Xx Xx1 .1 .2 .3 1'))

    def test_all_exported_settings_resolve_without_guessing(self):
        self.assertEqual({e['number'] for e in table()},set(range(1,231)))
        for entry in table():
            with self.subTest(setting=entry['xhm']):
                ops, source, notes = resolve([],hm=entry['xhm'],hall=entry['hall'],number=entry['number'])
                self.assertEqual({compile_op(op) for op in ops},{compile_op(op) for op in entry['operations']})


if __name__=='__main__': unittest.main()
