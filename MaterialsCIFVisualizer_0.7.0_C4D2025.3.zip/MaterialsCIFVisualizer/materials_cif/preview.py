"""Structure preview data and orthographic projection, independent of C4D.

Input coordinates/radii are Angstroms. No atom sampling or extra bond inference:
the same BuiltStructure and Bond list feed the final scene builder.
"""
from collections import Counter
from dataclasses import dataclass, field
import copy
import math
from .view_math import view_frame,preview_coordinates

from .elements import ELEMENT_COLORS, VISUAL_RADII, DEFAULT_COLOR, DEFAULT_VISUAL_RADIUS


def cell_edges(built):
    origin = built.center_shift
    a, b, c = built.cell_vectors
    def add(*vectors):
        return tuple(sum(v[k] for v in vectors) for k in range(3))
    points = [origin, add(origin,a), add(origin,b), add(origin,c),
              add(origin,a,b),add(origin,a,c),add(origin,b,c),add(origin,a,b,c)]
    indices = [(0,1),(0,2),(0,3),(1,4),(1,5),(2,4),(2,6),(3,5),(3,6),(4,7),(5,7),(6,7)]
    return [(points[i],points[j]) for i,j in indices]


@dataclass
class PreviewData:
    built: object
    bonds: list
    styles: dict = field(default_factory=dict)
    atom_scale: float = 0.70
    bond_radius: float = 0.08
    make_atoms: bool = True
    make_bonds: bool = True
    make_cell: bool = False

    def __post_init__(self):
        self.styles = copy.deepcopy(self.styles)
        self.bonds = list(self.bonds)

    def color(self, element):
        return self.styles.get(element, {}).get('color', ELEMENT_COLORS.get(element, DEFAULT_COLOR))

    def radius(self, element):
        return self.styles.get(element, {}).get('radius', VISUAL_RADII.get(element, DEFAULT_VISUAL_RADIUS)) * self.atom_scale

    def summary(self):
        counts = Counter(a.element for a in self.built.atoms)
        return '{} atoms | {} bonds\n{}'.format(len(self.built.atoms), len(self.bonds),
            ', '.join('{}: {}'.format(e,n) for e,n in sorted(counts.items())))

    def project(self, width, height, yaw=35.0, pitch=40.0, zoom=1.0):
        """Painter primitives: balls, colored half bonds and optional cell edges.

        Depth order approximates occlusion; this is a structural schematic, not
        a renderer. Each returned primitive retains its atom/bond index.
        """
        width, height = max(80,width), max(80,height)
        frame = view_frame(yaw,pitch)
        def rotate(p):
            return preview_coordinates(p,frame)
        points = [rotate(a.position) for a in self.built.atoms]
        edges = cell_edges(self.built) if self.make_cell else []
        rotated_edges = [(rotate(a),rotate(b)) for a,b in edges]
        bounds = list(points) + [p for edge in rotated_edges for p in edge]
        if not bounds:
            return [], 1.0
        margin = max((self.radius(a.element) for a in self.built.atoms), default=0.5)
        xmin, xmax = min(p[0] for p in bounds)-margin, max(p[0] for p in bounds)+margin
        ymin, ymax = min(p[1] for p in bounds)-margin, max(p[1] for p in bounds)+margin
        scale = min((width-40)/max(xmax-xmin,0.1),(height-60)/max(ymax-ymin,0.1)) * zoom
        center = ((xmin+xmax)/2,(ymin+ymax)/2)
        def screen(p):
            return (width/2+(p[0]-center[0])*scale, height/2-(p[1]-center[1])*scale)
        primitives = []
        if self.make_atoms:
            for i, (atom,p) in enumerate(zip(self.built.atoms,points)):
                primitives.append({'kind':'atom','index':i,'center':screen(p),'depth':p[2],
                    'radius':max(.5,self.radius(atom.element)*scale),'color':self.color(atom.element),
                    'periodic':atom.periodic_image != (0,0,0),
                    'label':'{} #{}'.format(atom.label,i)})
        if self.make_bonds:
            for k, bond in enumerate(self.bonds):
                p, q = points[bond.i], points[bond.j]
                a, b = self.built.atoms[bond.i].element, self.built.atoms[bond.j].element
                midpoint = tuple((x+y)/2 for x,y in zip(p,q))
                pieces = [(p,q,a)] if a==b else [(p,midpoint,a),(midpoint,q,b)]
                for start,end,element in pieces:
                    hidden = False
                    # Cylinders inside balls are invisible in the real model.
                    # Trim those portions in 3D rather than painting to centers.
                    if self.make_atoms:
                        length = math.dist(p,q)
                        low,high = self.radius(a),length-self.radius(b)
                        begin = 0.0 if start is p else length/2
                        finish = length if end is q else length/2
                        begin,finish = max(begin,low),min(finish,high)
                        hidden = finish <= begin or length < 1e-12
                        if not hidden:
                            direction = tuple((y-x)/length for x,y in zip(p,q))
                            start = tuple(x+t*begin for x,t in zip(p,direction))
                            end = tuple(x+t*finish for x,t in zip(p,direction))
                    primitives.append({'kind':'bond','index':k,'start':screen(start),'end':screen(end),
                        'depth':(start[2]+end[2])/2,'radius':max(.6,self.bond_radius*scale),'color':self.color(element),
                        'hidden':hidden})
        for start,end in rotated_edges:
            primitives.append({'kind':'cell','start':screen(start),'end':screen(end),
                'depth':(start[2]+end[2])/2,'radius':.7,'color':(.46,.55,.65)})
        primitives.sort(key=lambda p:p['depth'])
        return primitives, scale
