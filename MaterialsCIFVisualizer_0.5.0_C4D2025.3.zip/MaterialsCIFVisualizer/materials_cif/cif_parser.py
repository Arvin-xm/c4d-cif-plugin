"""Dependency-free CIF parser and crystal structure utilities.

The runtime uses the standard library and a bundled Gemmi-derived symmetry table.
No external Python package is loaded inside Cinema 4D.
It supports the common CIF constructs needed by materials workflows:

- scalar tags
- loop_ tables
- quoted values
- semicolon multiline values
- atom sites in fractional coordinates
- common symmetry-operation tags
- non-orthogonal cells
- symmetry expansion with duplicate removal
- supercell construction
- 2D/vacuum-axis alignment

It is not a full IUCr CIF validator. For unusual CIF dialects, adding a gemmi
adapter later is recommended.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import math
import re
from .cif_document import CIFError, read_blocks, read_file, select_block, structure_blocks
from .symmetry import compile_op, resolve


Vec3 = Tuple[float, float, float]


@dataclass
class AtomSite:
    element: str
    label: str
    fract: Vec3
    occupancy: float = 1.0
    raw_type_symbol: str = ""
    multiplicity: Optional[int] = None
    disorder: str = ""


@dataclass
class CrystalStructure:
    name: str
    a: float
    b: float
    c: float
    alpha: float
    beta: float
    gamma: float
    sites: List[AtomSite] = field(default_factory=list)
    symmetry_ops: List[str] = field(default_factory=lambda: ["x,y,z"])
    space_group: str = ""
    source_path: str = ""
    symmetry_source: str = ""
    formula_sum: str = ""
    formula_units_z: Optional[float] = None
    declared_volume: Optional[float] = None
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def lattice_vectors(self) -> Tuple[Vec3, Vec3, Vec3]:
        return lattice_vectors(self.a, self.b, self.c, self.alpha, self.beta, self.gamma)

    def expanded_sites(self, tol: float = 1e-6) -> List[AtomSite]:
        out = []
        for site in self.sites:
            out.extend(expand_site(site, self.symmetry_ops, tol, self.lattice_vectors()))
            if len(out) > 10000:
                raise CIFError("Expanded unit cell exceeds the 10,000 atom limit.")
        return out


@dataclass
class CartesianAtom:
    element: str
    label: str
    position: Vec3
    occupancy: float = 1.0
    raw_type_symbol: str = ""
    cell_index: Tuple[int, int, int] = (0, 0, 0)


@dataclass
class BuiltStructure:
    atoms: List[CartesianAtom]
    cell_vectors: Tuple[Vec3, Vec3, Vec3]
    source_cell_vectors: Tuple[Vec3, Vec3, Vec3]
    vacuum_axis: Optional[str]
    center_shift: Vec3


ELEMENTS = set("H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og".split())


def _float_cif(value, default=None):
    if value in ("?", ".", ""):
        if default is not None:
            return default
        raise CIFError("Missing numeric CIF value: {!r}".format(value))
    clean = re.sub(r"\(\d+\)(?=([eE][+-]?\d+)?$)", "", value.strip())
    try:
        result = float(clean)
    except ValueError as exc:
        raise CIFError("Invalid numeric CIF value: {!r}".format(value)) from exc
    if not math.isfinite(result):
        raise CIFError("Non-finite numeric CIF value: {!r}".format(value))
    return result


def normalize_element(value):
    text = (value or '').strip()
    match = re.match(r"^([A-Z][a-z]?)(?=$|[0-9+_:\-])", text)
    if not match:
        raise CIFError("Cannot determine an element from {!r}. Supply _atom_site_type_symbol.".format(value))
    element = match.group(1)
    if element in ('D', 'T'):
        return 'H'
    if element not in ELEMENTS:
        raise CIFError("Unknown element {!r}.".format(element))
    return element


def _tag_index(headers, *candidates):
    for candidate in candidates:
        if candidate.lower() in headers:
            return headers.index(candidate.lower())
    return None


def parse_cif_block(block, source_path=''):
    sl = block.scalars
    all_tags = set(sl) | {tag for headers, rows in block.loops for tag in headers}
    if any(t.startswith(('_space_group_symop_magn', '_atom_site_moment', '_space_group_ssg')) for t in all_tags):
        raise CIFError('Magnetic/modulated CIF requires a dedicated importer. Export an ordinary 3D nuclear structure first.')
    if any(t in all_tags for t in ('_atom_site_label_asym_id', '_atom_site_auth_asym_id', '_atom_site_pdbx_pdb_model_num')):
        raise CIFError('Macromolecular mmCIF is not supported by this materials importer.')

    def scalar(*names, default=''):
        for name in names:
            if name in sl and sl[name] not in ('?', '.'):
                return sl[name]
        return default

    cell = [_float_cif(scalar('_cell_length_' + axis)) for axis in 'abc']
    angles = [_float_cif(scalar('_cell_angle_' + axis)) for axis in ('alpha', 'beta', 'gamma')]
    lattice = lattice_vectors(*cell, *angles)
    hm = scalar('_space_group_name_h-m_alt', '_symmetry_space_group_name_h-m', '_space_group_name_h-m')
    hall = scalar('_space_group_name_hall', '_symmetry_space_group_name_hall')
    raw_number = scalar('_space_group_it_number', '_symmetry_int_tables_number')
    number = _float_cif(raw_number) if raw_number else None
    if number is not None:
        if not number.is_integer() or not 1 <= number <= 230:
            raise CIFError('Space-group IT number must be an integer from 1 to 230.')
        number = int(number)
    setting = scalar('_space_group_it_coordinate_system_code')
    sym_tags = ('_space_group_symop_operation_xyz', '_symmetry_equiv_pos_as_xyz')
    operations = [sl[t] for t in sym_tags if t in sl]
    for headers, rows in block.loops:
        index = _tag_index(headers, *sym_tags)
        if index is not None:
            operations.extend(row[index] for row in rows)
    operations, symmetry_source, warnings = resolve(operations, hm, hall, number, setting)

    atom_tables = block.atom_tables()
    if len(atom_tables) != 1:
        raise CIFError('Expected one atom coordinate table in the selected data block.')
    headers, rows = atom_tables[0]
    if len(rows) > 10000:
        raise CIFError('Atom table exceeds the 10,000 site limit.')
    fractional = all('_atom_site_fract_' + axis in headers for axis in 'xyz')
    cartesian = all('_atom_site_cartn_' + axis in headers for axis in 'xyz')
    if any('_atom_site_fract_' + axis in headers for axis in 'xyz') and not fractional:
        raise CIFError('Incomplete fractional coordinate columns.')
    if not fractional and not cartesian:
        raise CIFError('Expected complete fractional or Cartesian x, y, z coordinates.')
    if not fractional:
        if any(t.startswith(('_atom_sites_cartn_tran', '_atom_sites_fract_tran')) for t in all_tags):
            raise CIFError('Custom Cartesian transformation found. Export fractional coordinates first.')
        warnings.append('Cartesian coordinates converted using the conventional crystallographic cell axes.')
    prefix = '_atom_site_fract_' if fractional else '_atom_site_cartn_'
    coords = [_tag_index(headers, prefix+axis) for axis in 'xyz']
    itype = _tag_index(headers, '_atom_site_type_symbol')
    ilabel = _tag_index(headers, '_atom_site_label')
    iocc = _tag_index(headers, '_atom_site_occupancy')
    imult = _tag_index(headers, '_atom_site_symmetry_multiplicity', '_atom_site_site_symmetry_multiplicity')
    idisorder = [_tag_index(headers, t) for t in ('_atom_site_disorder_group', '_atom_site_disorder_assembly')]
    sites = []
    skipped = 0
    for row_number, row in enumerate(rows, 1):
        raw = row[itype] if itype is not None else (row[ilabel] if ilabel is not None else '')
        label = row[ilabel] if ilabel is not None else raw + str(row_number)
        element = normalize_element(raw if raw not in ('?', '.') else label)
        occupancy = _float_cif(row[iocc]) if iocc is not None else 1.0
        if not 0 <= occupancy <= 1:
            raise CIFError('Occupancy must be between 0 and 1: ' + label)
        if occupancy == 0:
            skipped += 1
            continue
        position = tuple(_float_cif(row[i]) for i in coords)
        if max(abs(v) for v in position) > 1e6:
            raise CIFError('Coordinate is outside the supported numeric range: ' + label)
        if not fractional:
            position = cart_to_fract(position, lattice)
        multiplicity = None
        if imult is not None and row[imult] not in ('?', '.'):
            multiplicity = _float_cif(row[imult])
            if not multiplicity.is_integer() or multiplicity < 1:
                raise CIFError('Invalid symmetry multiplicity: ' + label)
            multiplicity = int(multiplicity)
        disorder = ','.join(row[i] for i in idisorder if i is not None and row[i] not in ('.', '?', '0', ''))
        sites.append(AtomSite(element, label, position, occupancy, raw, multiplicity, disorder))
        if re.match(r'^[DT](?=$|[0-9+_:\-])', raw):
            warnings.append('Hydrogen isotope {} is displayed as H; isotope identity is not visualized.'.format(raw))
    if skipped:
        warnings.append('{} zero-occupancy rows were excluded.'.format(skipped))
    if not sites:
        raise CIFError('No occupied atom sites in the selected block.')
    z_text = scalar('_cell_formula_units_z')
    volume_text = scalar('_cell_volume')
    structure = CrystalStructure(
        name=block.name, a=cell[0], b=cell[1], c=cell[2],
        alpha=angles[0], beta=angles[1], gamma=angles[2], sites=sites,
        symmetry_ops=operations, space_group=hm or hall or ('IT '+str(number) if number else ''),
        source_path=source_path, symmetry_source=symmetry_source,
        formula_sum=scalar('_chemical_formula_sum'),
        formula_units_z=_float_cif(z_text) if z_text else None,
        declared_volume=_float_cif(volume_text) if volume_text else None,
        warnings=list(dict.fromkeys(warnings)))
    from .validation import validate_structure
    validate_structure(structure)
    return structure


def load_cif_document(path):
    blocks = structure_blocks(read_file(path))
    if not blocks:
        raise CIFError('No structure coordinate table was found in this CIF.')
    return blocks


def parse_cif_text(text, source_path='', block_name=None):
    return parse_cif_block(select_block(read_blocks(text), block_name), source_path)


def parse_cif_file(path, block_name=None):
    return parse_cif_block(select_block(read_file(path), block_name), str(path))


def cart_to_fract(position, lattice):
    a, b, c = lattice
    z = position[2]/c[2]
    y = (position[1]-z*c[1])/b[1]
    x = (position[0]-y*b[0]-z*c[0])/a[0]
    return (x, y, z)


def expand_site(site, operations, tol=1e-6, lattice=None, merge_notes=None):
    result, seen = [], set()
    modulus = int(round(1/tol))
    for operation in operations:
        point = tuple(_wrap01(v) for v in apply_symmetry_op(operation, site.fract))
        key = point if lattice is not None else tuple(int(round(v/tol)) % modulus for v in point)
        if key not in seen:
            seen.add(key)
            # A printed special position such as 0.3333 is not exactly 1/3.
            # Merge only images of THIS asymmetric site, never separate rows.
            # A small Cartesian tolerance avoids multiplying nearly identical
            # atoms solely because a publisher rounded the fractional values.
            if lattice is not None:
                duplicate = False
                for prior in result:
                    delta = tuple((a-b+.5) % 1-.5 for a,b in zip(point,prior.fract))
                    distance = _vnorm(fract_to_cart(delta,lattice))
                    if distance < 0.002:
                        duplicate = True
                        if distance > 1e-7 and merge_notes is not None:
                            merge_notes.append('Rounded special position {}: symmetry images within 0.002 A were merged; representative coordinates retained.'.format(site.label))
                        break
                if duplicate:
                    continue
            result.append(AtomSite(site.element, site.label, point, site.occupancy, site.raw_type_symbol))
    return result


# ---------- symmetry ----------
def apply_symmetry_op(op: str, fract: Vec3) -> Vec3:
    matrix, translation = compile_op(op)
    return tuple(sum(matrix[i][j]*fract[j] for j in range(3))+float(translation[i]) for i in range(3))


def _wrap01(v: float) -> float:
    w = v % 1.0
    if abs(w - 1.0) < 1e-12 or abs(w) < 1e-12:
        return 0.0
    return w


# ---------- geometry ----------
def lattice_vectors(a: float, b: float, c: float,
                    alpha_deg: float, beta_deg: float, gamma_deg: float
                    ) -> Tuple[Vec3, Vec3, Vec3]:
    """Return crystallographic a,b,c vectors in a Cartesian right-handed frame."""
    values = (a, b, c, alpha_deg, beta_deg, gamma_deg)
    if not all(math.isfinite(v) for v in values) or min(a, b, c) <= 0:
        raise CIFError("Cell lengths must be finite and positive.")
    if not all(0 < angle < 180 for angle in (alpha_deg, beta_deg, gamma_deg)):
        raise CIFError("Cell angles must be strictly between 0 and 180 degrees.")
    alpha, beta, gamma = map(math.radians, (alpha_deg, beta_deg, gamma_deg))
    sg = math.sin(gamma)
    if abs(sg) < 1e-12:
        raise CIFError("Invalid cell: sin(gamma) is zero")
    av = (a, 0.0, 0.0)
    bv = (b * math.cos(gamma), b * sg, 0.0)
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / sg
    cz2 = c * c - cx * cx - cy * cy
    if cz2 <= c*c*1e-12:
        raise CIFError("Invalid/degenerate cell geometry")
    cv = (cx, cy, math.sqrt(max(0.0, cz2)))
    return av, bv, cv


def _vadd(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]+b[0], a[1]+b[1], a[2]+b[2])


def _vsub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0]-b[0], a[1]-b[1], a[2]-b[2])


def _vscale(a: Vec3, s: float) -> Vec3:
    return (a[0]*s, a[1]*s, a[2]*s)


def _vdot(a: Vec3, b: Vec3) -> float:
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def _vcross(a: Vec3, b: Vec3) -> Vec3:
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _vnorm(a: Vec3) -> float:
    return math.sqrt(_vdot(a, a))


def _vunit(a: Vec3) -> Vec3:
    n = _vnorm(a)
    if n < 1e-12:
        raise CIFError("Cannot normalize zero vector")
    return _vscale(a, 1.0/n)


def fract_to_cart(fract: Vec3, lattice: Tuple[Vec3, Vec3, Vec3]) -> Vec3:
    a, b, c = lattice
    return (
        fract[0]*a[0] + fract[1]*b[0] + fract[2]*c[0],
        fract[0]*a[1] + fract[1]*b[1] + fract[2]*c[1],
        fract[0]*a[2] + fract[1]*b[2] + fract[2]*c[2],
    )


def _largest_circular_gap(values: Sequence[float]) -> Tuple[float, float]:
    """Return (gap_fraction, midpoint) for values on a periodic [0,1) circle."""
    vals = sorted({_wrap01(v) for v in values})
    if not vals:
        return 1.0, 0.5
    if len(vals) == 1:
        return 1.0, _wrap01(vals[0] + 0.5)
    best_gap = -1.0
    best_mid = 0.0
    for i, left in enumerate(vals):
        right = vals[(i + 1) % len(vals)] + (1.0 if i == len(vals) - 1 else 0.0)
        gap = right - left
        if gap > best_gap:
            best_gap = gap
            best_mid = _wrap01(left + gap / 2.0)
    return best_gap, best_mid


def detect_vacuum_axis_from_structure(structure: CrystalStructure,
                                      min_gap_fraction: float = 0.45,
                                      min_gap_angstrom: float = 5.0) -> Optional[str]:
    """Detect a likely vacuum axis from empty periodic space, not just cell length.

    This avoids classifying layered bulk cells (e.g. ordinary 2H-MoS2) as vacuum
    merely because c is longer than a and b. A direction is considered vacuum-like
    only when the expanded atom positions leave a large circular gap both as a
    fraction of the unit cell and in absolute angstrom.
    """
    expanded = structure.expanded_sites()
    lengths = {"A": structure.a, "B": structure.b, "C": structure.c}
    best = None
    for idx, axis in enumerate(("A", "B", "C")):
        gap, _ = _largest_circular_gap([s.fract[idx] for s in expanded])
        physical = gap * lengths[axis]
        if gap >= min_gap_fraction and physical >= min_gap_angstrom:
            score = physical
            if best is None or score > best[0]:
                best = (score, axis)
    return best[1] if best else None


def detect_vacuum_axis(lattice: Tuple[Vec3, Vec3, Vec3], ratio_threshold: float = 1.6) -> Optional[str]:
    """Legacy length-only heuristic retained for API compatibility.

    Prefer detect_vacuum_axis_from_structure() when atom positions are available.
    """
    lengths = [("A", _vnorm(lattice[0])), ("B", _vnorm(lattice[1])), ("C", _vnorm(lattice[2]))]
    lengths.sort(key=lambda x: x[1], reverse=True)
    if lengths[0][1] / max(lengths[1][1], 1e-12) >= ratio_threshold:
        return lengths[0][0]
    return None


def alignment_basis(lattice: Tuple[Vec3, Vec3, Vec3], vacuum_axis: Optional[str]) -> Tuple[Vec3, Vec3, Vec3]:
    """Return basis x,y,z where z follows chosen vacuum axis.

    The remaining crystallographic direction is projected into the plane to
    define x, then y is chosen to preserve a right-handed frame.
    """
    if vacuum_axis is None:
        return (1.0,0.0,0.0), (0.0,1.0,0.0), (0.0,0.0,1.0)
    idx = {"A": 0, "B": 1, "C": 2}[vacuum_axis.upper()]
    others = [i for i in range(3) if i != idx]
    zhat = _vunit(lattice[idx])
    candidate = lattice[others[0]]
    xproj = _vsub(candidate, _vscale(zhat, _vdot(candidate, zhat)))
    if _vnorm(xproj) < 1e-10:
        candidate = lattice[others[1]]
        xproj = _vsub(candidate, _vscale(zhat, _vdot(candidate, zhat)))
    xhat = _vunit(xproj)
    yhat = _vunit(_vcross(zhat, xhat))
    return xhat, yhat, zhat


def transform_vec(v: Vec3, basis: Tuple[Vec3, Vec3, Vec3]) -> Vec3:
    xhat, yhat, zhat = basis
    return (_vdot(v, xhat), _vdot(v, yhat), _vdot(v, zhat))


def build_supercell(structure: CrystalStructure,
                    nx: int = 1, ny: int = 1, nz: int = 1,
                    vacuum_axis: str = "AUTO",
                    center: bool = True) -> BuiltStructure:
    if structure.errors:
        raise CIFError("Structure validation failed:\n" + "\n".join(structure.errors))
    if any(type(n) is not int for n in (nx, ny, nz)):
        raise CIFError("Supercell dimensions must be integers.")
    if min(nx, ny, nz) < 1:
        raise ValueError("Supercell dimensions must be >= 1")
    if len(structure.expanded_sites()) * nx * ny * nz > 10000:
        raise CIFError("Supercell exceeds the 10,000 atom limit.")
    lattice = structure.lattice_vectors()
    if vacuum_axis.upper() == "AUTO":
        axis = detect_vacuum_axis_from_structure(structure)
    elif vacuum_axis.upper() in ("A", "B", "C"):
        axis = vacuum_axis.upper()
    elif vacuum_axis.upper() in ("NONE", "RAW", "OFF"):
        axis = None
    else:
        raise ValueError("vacuum_axis must be AUTO, A, B, C, or NONE")
    basis = alignment_basis(lattice, axis)

    expanded = structure.expanded_sites()
    # When a vacuum direction is selected, shift the periodic origin into the
    # largest empty gap. This keeps a 2D slab together instead of splitting it
    # across opposite sides of the unit cell (common in CIF exports).
    frac_shift = [0.0, 0.0, 0.0]
    if axis is not None and expanded:
        aidx = {"A": 0, "B": 1, "C": 2}[axis]
        _, gap_mid = _largest_circular_gap([s.fract[aidx] for s in expanded])
        frac_shift[aidx] = (-gap_mid) % 1.0

    atoms: List[CartesianAtom] = []
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                for site in expanded:
                    sf = (
                        _wrap01(site.fract[0] + frac_shift[0]),
                        _wrap01(site.fract[1] + frac_shift[1]),
                        _wrap01(site.fract[2] + frac_shift[2]),
                    )
                    f = (sf[0] + ix, sf[1] + iy, sf[2] + iz)
                    p = fract_to_cart(f, lattice)
                    p = transform_vec(p, basis)
                    atoms.append(CartesianAtom(
                        element=site.element,
                        label=site.label,
                        position=p,
                        occupancy=site.occupancy,
                        raw_type_symbol=site.raw_type_symbol,
                        cell_index=(ix, iy, iz),
                    ))

    sc_lattice_raw = (_vscale(lattice[0], nx), _vscale(lattice[1], ny), _vscale(lattice[2], nz))
    sc_lattice = tuple(transform_vec(v, basis) for v in sc_lattice_raw)  # type: ignore[assignment]

    shift = (0.0, 0.0, 0.0)
    if center and atoms:
        xs = [a.position[0] for a in atoms]
        ys = [a.position[1] for a in atoms]
        zs = [a.position[2] for a in atoms]
        shift = (-(min(xs)+max(xs))/2, -(min(ys)+max(ys))/2, -(min(zs)+max(zs))/2)
        for atom in atoms:
            atom.position = _vadd(atom.position, shift)

    return BuiltStructure(
        atoms=atoms,
        cell_vectors=sc_lattice, source_cell_vectors=lattice,
        vacuum_axis=axis, center_shift=shift,
    )


def structure_summary(structure: CrystalStructure) -> Dict[str, object]:
    expanded = structure.expanded_sites()
    counts: Dict[str, int] = {}
    for s in expanded:
        counts[s.element] = counts.get(s.element, 0) + 1
    lattice = structure.lattice_vectors()
    return {
        "name": structure.name,
        "warnings": structure.warnings,
        "errors": structure.errors,
        "symmetry_source": structure.symmetry_source,
        "space_group": structure.space_group,
        "cell": (structure.a, structure.b, structure.c, structure.alpha, structure.beta, structure.gamma),
        "asymmetric_sites": len(structure.sites),
        "expanded_atoms": len(expanded),
        "elements": counts,
        "symmetry_ops": len(structure.symmetry_ops),
        "detected_vacuum_axis": detect_vacuum_axis_from_structure(structure),
    }
